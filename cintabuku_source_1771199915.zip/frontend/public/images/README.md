# Panduan Gambar Hero Section

Silakan letakkan file gambar Anda di folder ini (`public/images`).

Disarankan menggunakan format `.webp` untuk performa terbaik.

## Daftar File yang Dibutuhkan (Contoh):
1.  **Cover Buku Utama**: `hero-book.webp`
2.  **Foto Ulama**: `scholar.webp`
3.  **Cover Audiobook**: `hero-audio.webp`

Setelah file ada di sini, update kode di `src/components/HeroSection.tsx` menjadi:
```tsx
<img src="/images/hero-book.webp" ... />
```
```tsx
<img src="/images/scholar.webp" ... />
```
```tsx
<img src="/images/hero-audio.webp" ... />
```
