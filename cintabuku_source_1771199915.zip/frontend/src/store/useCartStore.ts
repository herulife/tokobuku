import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { CartItem, Book } from '@/types';
import { apiClient } from '@/lib/api-client';
import { useAuthStore } from './useAuthStore';

interface CartState {
    items: CartItem[];
    isLoading: boolean;
    addItem: (book: Book, quantity?: number) => Promise<void>;
    removeItem: (bookId: string) => Promise<void>;
    updateQuantity: (bookId: string, quantity: number) => Promise<void>;
    clearCart: () => Promise<void>;
    syncCart: () => Promise<void>;
    totalItems: () => number;
    totalPrice: () => number;
}

export const useCartStore = create<CartState>()(
    persist(
        (set, get) => ({
            items: [],
            isLoading: false,

            syncCart: async () => {
                const isAuth = useAuthStore.getState().isAuthenticated;
                if (!isAuth) return;

                set({ isLoading: true });
                try {
                    const res: any = await apiClient.get('/cart');
                    // Transform backend response to CartItem[]
                    // Backend returns: { status: 'success', data: { cart: { items: [...] } } }
                    const backendItems = res.data.cart?.items?.map((item: any) => ({
                        bookId: item.bookId,
                        quantity: item.quantity,
                        book: item.book
                    })) || [];

                    set({ items: backendItems });
                } catch (error) {
                    console.error('Failed to sync cart:', error);
                } finally {
                    set({ isLoading: false });
                }
            },

            addItem: async (book, quantity = 1) => {
                const isAuth = useAuthStore.getState().isAuthenticated;
                const currentItems = get().items;
                const existingItem = currentItems.find(item => item.bookId === book.id);

                // Optimistic Update
                if (existingItem) {
                    set({
                        items: currentItems.map(item =>
                            item.bookId === book.id
                                ? { ...item, quantity: item.quantity + quantity }
                                : item
                        )
                    });
                } else {
                    set({ items: [...currentItems, { bookId: book.id, quantity, book }] });
                }

                if (isAuth) {
                    try {
                        await apiClient.post('/cart/items', { bookId: book.id, quantity });
                        // Optionally re-sync to be sure
                        await get().syncCart();
                    } catch (error) {
                        console.error('Add to cart API failed:', error);
                        // Revert on failure? For now, keep optimistic or maybe fetch sync
                        await get().syncCart();
                    }
                }
            },

            removeItem: async (bookId) => {
                const isAuth = useAuthStore.getState().isAuthenticated;
                set({ items: get().items.filter(item => item.bookId !== bookId) });

                if (isAuth) {
                    try {
                        await apiClient.delete(`/cart/items/${bookId}`);
                    } catch (error) {
                        console.error('Remove cart item API failed:', error);
                        await get().syncCart();
                    }
                }
            },

            updateQuantity: async (bookId, quantity) => {
                if (quantity <= 0) {
                    await get().removeItem(bookId);
                    return;
                }

                const isAuth = useAuthStore.getState().isAuthenticated;

                set({
                    items: get().items.map(item =>
                        item.bookId === bookId ? { ...item, quantity } : item
                    )
                });

                if (isAuth) {
                    try {
                        await apiClient.put(`/cart/items/${bookId}`, { quantity });
                    } catch (error) {
                        console.error('Update quantity API failed:', error);
                        await get().syncCart();
                    }
                }
            },

            clearCart: async () => {
                const isAuth = useAuthStore.getState().isAuthenticated;
                set({ items: [] });

                if (isAuth) {
                    try {
                        await apiClient.delete('/cart');
                    } catch (error) {
                        console.error('Clear cart API failed:', error);
                    }
                }
            },

            totalItems: () => get().items.reduce((total, item) => total + item.quantity, 0),

            totalPrice: () => get().items.reduce((total, item) => {
                const price = item.book.discountPrice || item.book.price;
                return total + (price * item.quantity);
            }, 0),
        }),
        {
            name: 'cart-storage',
            partialize: (state) => ({ items: state.items }), // Only persist items
            skipHydration: true, // We might want to handle hydration manually or just let it be
        }
    )
);

