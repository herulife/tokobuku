import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import { apiClient } from '@/lib/api-client';
import { cookieStorage } from '@/lib/cookie-storage';

interface User {
    id: string;
    name: string;
    email: string;
    role: string;
    avatar?: string;
}

interface AuthState {
    user: User | null;
    isAuthenticated: boolean;
    login: (credentials: any) => Promise<void>;
    register: (data: any) => Promise<void>;
    logout: () => Promise<void>;
    checkAuth: () => Promise<void>;
    _hasHydrated: boolean;
    setHasHydrated: (state: boolean) => void;
}

export const useAuthStore = create<AuthState>()(
    persist(
        (set) => ({
            user: null,
            isAuthenticated: false,
            _hasHydrated: false,
            setHasHydrated: (state: boolean) => {
                set({
                    _hasHydrated: state
                });
            },

            login: async (credentials) => {
                const res: any = await apiClient.post('/auth/login', credentials);
                set({ user: res.data.user, isAuthenticated: true });
                // Sync stores
                const { useCartStore } = await import('./useCartStore');
                const { useWishlistStore } = await import('./useWishlistStore');
                useCartStore.getState().syncCart();
                useWishlistStore.getState().syncWishlist();
            },

            register: async (data) => {
                const res: any = await apiClient.post('/auth/register', data);
                set({ user: res.data.user, isAuthenticated: true });
                // Sync stores
                const { useCartStore } = await import('./useCartStore');
                const { useWishlistStore } = await import('./useWishlistStore');
                useCartStore.getState().syncCart();
                useWishlistStore.getState().syncWishlist();
            },

            logout: async () => {
                try {
                    await apiClient.post('/auth/logout');
                } catch (error) {
                    console.error('Logout failed', error);
                }
                set({ user: null, isAuthenticated: false });
                const { useCartStore } = await import('./useCartStore');
                const { useWishlistStore } = await import('./useWishlistStore');
                useCartStore.getState().clearCart(); // Clear local cart on logout? Or keep it? Usually clear to avoid data leak.
                useWishlistStore.setState({ items: [] });
            },

            checkAuth: async () => {
                try {
                    const res: any = await apiClient.get('/auth/me');
                    set({ user: res.data.user, isAuthenticated: true });
                    // Sync stores
                    const { useCartStore } = await import('./useCartStore');
                    const { useWishlistStore } = await import('./useWishlistStore');
                    useCartStore.getState().syncCart();
                    useWishlistStore.getState().syncWishlist();
                } catch (error) {
                    set({ user: null, isAuthenticated: false });
                }
            },
        }),
        {
            name: 'auth-storage',
            storage: createJSONStorage(() => cookieStorage),
            partialize: (state) => ({ user: state.user, isAuthenticated: state.isAuthenticated }),
            onRehydrateStorage: () => (state) => {
                state?.setHasHydrated(true);
            },
        }
    )
);
