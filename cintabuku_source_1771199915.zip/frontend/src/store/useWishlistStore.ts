import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { Book } from '@/types';
import { apiClient } from '@/lib/api-client';
import { useAuthStore } from './useAuthStore';

interface WishlistState {
    items: Book[];
    isLoading: boolean;
    addToWishlist: (book: Book) => Promise<void>;
    removeFromWishlist: (bookId: string) => Promise<void>;
    syncWishlist: () => Promise<void>;
    isInWishlist: (bookId: string) => boolean;
}

export const useWishlistStore = create<WishlistState>()(
    persist(
        (set, get) => ({
            items: [],
            isLoading: false,

            syncWishlist: async () => {
                const isAuth = useAuthStore.getState().isAuthenticated;
                if (!isAuth) return;

                set({ isLoading: true });
                try {
                    const res: any = await apiClient.get('/wishlist');
                    // Backend returns: { status: 'success', data: { wishlist: [{ bookId, book, ... }] } }
                    const backendItems = res.data.wishlist.map((item: any) => item.book);
                    set({ items: backendItems });
                } catch (error) {
                    console.error('Failed to sync wishlist:', error);
                } finally {
                    set({ isLoading: false });
                }
            },

            addToWishlist: async (book) => {
                const isAuth = useAuthStore.getState().isAuthenticated;
                const currentItems = get().items;

                // Avoid duplicates
                if (currentItems.some(i => i.id === book.id)) return;

                // Optimistic
                set({ items: [...currentItems, book] });

                if (isAuth) {
                    try {
                        await apiClient.post('/wishlist', { bookId: book.id });
                    } catch (error) {
                        console.error('Add to wishlist failed:', error);
                        await get().syncWishlist();
                    }
                }
            },

            removeFromWishlist: async (bookId) => {
                const isAuth = useAuthStore.getState().isAuthenticated;
                set({ items: get().items.filter(item => item.id !== bookId) });

                if (isAuth) {
                    try {
                        await apiClient.delete(`/wishlist/${bookId}`);
                    } catch (error) {
                        console.error('Remove from wishlist failed:', error);
                        await get().syncWishlist();
                    }
                }
            },

            isInWishlist: (bookId) => {
                return get().items.some(item => item.id === bookId);
            }
        }),
        {
            name: 'wishlist-storage',
            partialize: (state) => ({ items: state.items }),
        }
    )
);
