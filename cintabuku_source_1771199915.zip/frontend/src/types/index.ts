export interface Book {
    id: string;
    title: string;
    slug: string;
    author: string;
    publisher?: string;
    isbn?: string;
    description?: string;
    price: number;
    discountPrice?: number | null;
    stock: number;
    coverImage: string;
    samplePdf?: string;
    categoryId: string;
    category: {
        id: string;
        name: string;
        slug: string;
    };
    isPreorder: boolean;
    preorderDate?: string;
    rating?: number;
    totalRating?: number;
    sold?: number;
}

export interface User {
    id: string;
    name: string;
    email: string;
    role: 'USER' | 'ADMIN';
    avatar?: string;
}

export interface CartItem {
    bookId: string;
    quantity: number;
    book: Book;
}
