'use client';

import Image from 'next/image';
import { Button } from '@/components/ui/button';
import { ArrowRight, Play } from 'lucide-react';
import Link from 'next/link';

export default function HeroSection() {
    return (
        <section className="relative min-h-[85vh] flex items-center justify-center overflow-hidden">
            {/* Background Image */}
            <div className="absolute inset-0 z-0">
                <Image
                    src="/images/bookstore-hero.png"
                    alt="Bookstore Interior"
                    fill
                    className="object-cover"
                    priority
                />
                {/* Overlay Gradient */}
                <div className="absolute inset-0 bg-gradient-to-r from-black/70 via-black/50 to-transparent" />
            </div>

            <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10 w-full">
                <div className="max-w-2xl text-white space-y-8 animate-in slide-in-from-bottom-10 fade-in duration-1000">

                    <div className="inline-flex items-center space-x-2 border border-white/30 rounded-full px-4 py-1.5 bg-white/10 backdrop-blur-md">
                        <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                        <span className="text-xs font-medium tracking-wider uppercase text-emerald-100">Selamat Datang di Koalisi Cinta Buku</span>
                    </div>

                    <h1 className="font-serif text-5xl sm:text-6xl lg:text-7xl font-bold leading-tight tracking-tight">
                        Temukan Dunia <br />
                        <span className="text-emerald-400 italic">Ilmu & Inspirasi</span>
                    </h1>

                    <p className="text-lg sm:text-xl text-slate-200 leading-relaxed max-w-lg font-light">
                        Jelajahi koleksi buku kurasi terbaik untuk menemani perjalanan ilmu dan parenting Anda. Membaca adalah jendela dunia pertama.
                    </p>

                    <div className="flex flex-wrap gap-4 pt-4">
                        <Button className="bg-emerald-600 hover:bg-emerald-700 text-white rounded-full px-8 py-6 text-lg border-none shadow-lg shadow-emerald-900/40 transition-all hover:-translate-y-1">
                            Mulai Belanja
                            <ArrowRight className="ml-2 w-5 h-5" />
                        </Button>
                        <Button variant="outline" className="rounded-full px-8 py-6 text-lg text-white border-white/40 hover:bg-white/10 hover:border-white backdrop-blur-sm transition-all group">
                            <span className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center mr-3 group-hover:bg-white/30 transition-all">
                                <Play className="w-3 h-3 fill-current ml-0.5" />
                            </span>
                            Tentang Kami
                        </Button>
                    </div>

                    <div className="pt-8 flex items-center gap-8 text-sm text-slate-300 font-medium">
                        <div className="flex flex-col">
                            <span className="text-2xl font-bold text-white">12k+</span>
                            <span>Buku Terjual</span>
                        </div>
                        <div className="w-px h-8 bg-white/20"></div>
                        <div className="flex flex-col">
                            <span className="text-2xl font-bold text-white">4.9</span>
                            <span>Rating Toko</span>
                        </div>
                        <div className="w-px h-8 bg-white/20"></div>
                        <div className="flex flex-col">
                            <span className="text-2xl font-bold text-white">100%</span>
                            <span>Original</span>
                        </div>
                    </div>
                </div>
            </div>

            <style jsx>{`
                .font-serif {
                    font-family: var(--font-playfair), serif;
                }
            `}</style>
        </section>
    );
}
