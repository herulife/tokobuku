'use client';

import { useCartStore } from '@/store/useCartStore';
import { Button } from '@/components/ui/button';
import { ShoppingCart } from 'lucide-react';
import { toast } from 'sonner';
import { useState } from 'react';

interface Book {
    id: string;
    title: string;
    author: string;
    price: number;
    coverImage: string;
    slug: string;
    stock: number;
    discountPrice?: number | null;
}

interface AddToCartButtonProps {
    book: Book;
    variant?: 'default' | 'outline' | 'ghost' | 'link' | 'secondary' | 'destructive' | 'gradient' | 'full';
    size?: 'default' | 'sm' | 'lg' | 'icon';
    className?: string;
    showText?: boolean;
    text?: string;
}

export default function AddToCartButton({
    book,
    variant = 'default',
    size = 'default',
    className = '',
    showText = true,
    text = 'Keranjang'
}: AddToCartButtonProps) {
    const addItem = useCartStore((state) => state.addItem);
    const [loading, setLoading] = useState(false);

    const handleAddToCart = async (e: React.MouseEvent) => {
        e.preventDefault();
        e.stopPropagation();

        if (book.stock <= 0) {
            toast.error('Maaf, stok buku habis');
            return;
        }

        setLoading(true);
        try {
            await addItem(book as any);
            toast.success('Berhasil masuk keranjang');
        } catch (error) {
            toast.error('Gagal menambahkan ke keranjang');
        } finally {
            setLoading(false);
        }
    };

    const handleDirectBuy = async (e: React.MouseEvent) => {
        e.preventDefault();
        e.stopPropagation();
        if (book.stock <= 0) return;

        setLoading(true);
        try {
            await addItem(book as any);
            window.location.href = '/checkout';
        } catch (error) {
            toast.error('Gagal memproses pembelian');
            setLoading(false);
        }
    };

    const handleWhatsAppBuy = (e: React.MouseEvent) => {
        e.preventDefault();
        e.stopPropagation();

        const phoneNumber = '6281234567890'; // Default admin number
        const message = `Halo Admin, saya mau pesan buku "${book.title}". Apakah stok masih ada?`;
        const url = `https://wa.me/${phoneNumber}?text=${encodeURIComponent(message)}`;

        window.open(url, '_blank');
    };

    if (variant === 'full') {
        return (
            <div className={`flex flex-col gap-4 w-full ${className}`}>
                <Button
                    variant="default"
                    size="lg"
                    className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold h-12 rounded-lg shadow-emerald-200 shadow-lg text-base transition-all duration-300 hover:scale-[1.02]"
                    disabled={book.stock <= 0 || loading}
                    onClick={handleAddToCart}
                >
                    <ShoppingCart className="mr-2 h-5 w-5" />
                    Keranjang
                </Button>

                <div className="grid grid-cols-2 gap-4">
                    <Button
                        variant="outline"
                        size="lg"
                        className="w-full border-emerald-600 text-emerald-600 hover:bg-emerald-50 h-10 rounded-lg border-opacity-30 font-semibold text-sm transition-all duration-300 hover:border-opacity-100"
                        disabled={book.stock <= 0 || loading}
                        onClick={handleDirectBuy}
                    >
                        Beli Langsung
                    </Button>
                    <Button
                        variant="secondary"
                        size="lg"
                        className="w-full bg-emerald-50 text-emerald-700 hover:bg-emerald-100 border border-emerald-100 h-10 rounded-lg font-semibold text-sm transition-all duration-300"
                        onClick={handleWhatsAppBuy}
                    >
                        Pesan via WA
                    </Button>
                </div>
            </div>
        );
    }

    return (
        <Button
            variant={variant}
            size={size}
            className={className}
            disabled={book.stock <= 0 || loading}
            onClick={handleAddToCart}
        >
            <ShoppingCart className={`${showText ? 'mr-2' : ''} h-5 w-5`} />
            {showText && text}
        </Button>
    );
}
