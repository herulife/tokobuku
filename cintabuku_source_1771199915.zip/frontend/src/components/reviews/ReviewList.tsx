'use client';

import { useState, useEffect } from 'react';
import { useAuthStore } from '@/store/useAuthStore';
import { apiClient } from '@/lib/api-client';
import { Button } from '@/components/ui/button';
import { Star, Trash2 } from 'lucide-react';
import { toast } from 'sonner';
import { formatDate } from '@/lib/utils';


interface Review {
    id: string;
    rating: number;
    comment: string;
    createdAt: string;
    user: {
        id: string;
        name: string;
        avatar: string | null;
    };
    userId: string;
}

export function ReviewList({ bookId }: { bookId: string }) {
    const [reviews, setReviews] = useState<Review[]>([]);
    const [loading, setLoading] = useState(true);
    const { user } = useAuthStore();
    // Re-fetch trigger
    const [refresh, setRefresh] = useState(0);

    useEffect(() => {
        const fetchReviews = async () => {
            try {
                const res: any = await apiClient.get(`/books/${bookId}/reviews`);
                setReviews(res.data.reviews);
            } catch (error) {
                console.error("Failed to fetch reviews", error);
            } finally {
                setLoading(false);
            }
        };
        fetchReviews();
    }, [bookId, refresh]);

    const handleReviewAdded = () => {
        setRefresh(prev => prev + 1);
    };

    const handleDelete = async (reviewId: string) => {
        if (!confirm('Hapus ulasan ini?')) return;
        try {
            await apiClient.delete(`/reviews/${reviewId}`);
            setReviews(prev => prev.filter(r => r.id !== reviewId));
            toast.success('Ulasan dihapus');
        } catch (error) {
            toast.error('Gagal menghapus ulasan');
        }
    };

    const displayedReviews = reviews.filter(r => r.rating >= 4);

    return (
        <div className="space-y-8 mt-12">
            <div className="flex items-baseline space-x-4">
                <h3 className="text-2xl font-bold text-slate-900">Ulasan Pembaca ({displayedReviews.length})</h3>
                <span className="text-sm text-slate-500 italic">*Menampilkan ulasan terbaik</span>
            </div>

            <ReviewForm bookId={bookId} onReviewAdded={handleReviewAdded} />

            <div className="space-y-6">
                {displayedReviews.map((review) => (
                    <div key={review.id} className="bg-white p-6 rounded-xl border border-slate-100 shadow-sm flex gap-4">
                        <div className="flex-shrink-0">
                            <div className="w-10 h-10 rounded-full bg-slate-200 overflow-hidden relative">
                                {review.user.avatar ? (
                                    <img
                                        src={review.user.avatar}
                                        alt={review.user.name}
                                        className="object-cover w-full h-full"
                                    />
                                ) : (
                                    <span className="flex items-center justify-center h-full text-slate-500 text-xs font-bold">
                                        {review.user.name.substring(0, 2).toUpperCase()}
                                    </span>
                                )}
                            </div>
                        </div>
                        <div className="flex-1">
                            <div className="flex justify-between items-start">
                                <div>
                                    <h4 className="font-bold text-slate-900">{review.user.name}</h4>
                                    <p className="text-xs text-slate-500">{formatDate(review.createdAt)}</p>
                                </div>
                                <div className="flex text-yellow-500">
                                    {[1, 2, 3, 4, 5].map((s) => (
                                        <Star key={s} size={14} className={s <= review.rating ? 'fill-current' : 'text-slate-300'} />
                                    ))}
                                </div>
                            </div>
                            <p className="mt-2 text-slate-600 text-sm leading-relaxed">
                                {review.comment}
                            </p>
                        </div>
                        {(user?.id === review.userId || user?.role === 'ADMIN' || user?.role === 'SUPER_ADMIN') && (
                            <button onClick={() => handleDelete(review.id)} className="text-red-400 hover:text-red-600">
                                <Trash2 size={16} />
                            </button>
                        )}
                    </div>
                ))}
                {displayedReviews.length === 0 && !loading && (
                    <p className="text-slate-500 text-center py-8 bg-slate-50 rounded-lg">Belum ada ulasan terbaik untuk buku ini.</p>
                )}
            </div>
        </div>
    );
}

function ReviewForm({ bookId, onReviewAdded }: { bookId: string, onReviewAdded: () => void }) {
    const { isAuthenticated } = useAuthStore();
    const [rating, setRating] = useState(5);
    const [comment, setComment] = useState('');
    const [loading, setLoading] = useState(false);
    const [hoverRating, setHoverRating] = useState(0);

    if (!isAuthenticated) {
        return (
            <div className="bg-emerald-50 p-4 rounded-lg text-emerald-800 text-sm mb-6">
                Silakan login untuk memberikan ulasan.
            </div>
        );
    }

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setLoading(true);
        try {
            await apiClient.post(`/books/${bookId}/reviews`, { rating, comment });
            toast.success('Ulasan berhasil dikirim');
            setComment('');
            setRating(5);
            onReviewAdded();
        } catch (error: any) {
            toast.error(error.message || 'Gagal mengirim ulasan');
        } finally {
            setLoading(false);
        }
    };

    return (
        <form onSubmit={handleSubmit} className="bg-slate-50 p-6 rounded-xl border border-slate-200 mb-8">
            <h4 className="font-bold text-slate-900 mb-4">Tulis Ulasan Anda</h4>
            <div className="space-y-4">
                <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Rating</label>
                    <div className="flex space-x-1">
                        {[1, 2, 3, 4, 5].map((star) => (
                            <button
                                key={star}
                                type="button"
                                onClick={() => setRating(star)}
                                onMouseEnter={() => setHoverRating(star)}
                                onMouseLeave={() => setHoverRating(0)}
                                className="focus:outline-none"
                            >
                                <Star
                                    size={24}
                                    className={`${(hoverRating || rating) >= star ? 'text-yellow-500 fill-current' : 'text-slate-300'} transition-colors`}
                                />
                            </button>
                        ))}
                    </div>
                </div>
                <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Komentar</label>
                    <textarea
                        value={comment}
                        onChange={(e) => setComment(e.target.value)}
                        className="w-full rounded-md border border-slate-300 p-3 h-24 text-sm focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                        placeholder="Bagaimana pendapat Anda tentang buku ini?"
                        required
                    />
                </div>
                <div className="flex justify-end">
                    <Button type="submit" disabled={loading} className="bg-emerald-600 hover:bg-emerald-700 text-white">
                        {loading ? 'Mengirim...' : 'Kirim Ulasan'}
                    </Button>
                </div>
            </div>
        </form>
    );
}
