'use client';

import { useState, useRef, useEffect } from 'react';
import { Share2, Link as LinkIcon, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';

interface ShareButtonsProps {
    url: string;
    title: string;
    description?: string;
}

const FacebookIcon = ({ className }: { className?: string }) => (
    <svg role="img" viewBox="0 0 24 24" fill="currentColor" className={className} xmlns="http://www.w3.org/2000/svg"><path d="M9.101 23.691v-7.98H6.627v-3.667h2.474v-1.58c0-4.085 1.848-5.978 5.858-5.978.401 0 .955.042 1.468.103a8.68 8.68 0 0 1 1.141.195v3.325a8.623 8.623 0 0 0-.653-.036c-2.148 0-2.791 1.657-2.791 3.593v1.66h4.143l-1.002 3.667h-3.141v7.98h-5.026z" /></svg>
);

const TwitterIcon = ({ className }: { className?: string }) => (
    <svg role="img" viewBox="0 0 24 24" fill="currentColor" className={className} xmlns="http://www.w3.org/2000/svg"><path d="M18.901 1.153h3.68l-8.04 9.19L24 22.846h-7.406l-5.8-7.584-6.638 7.584H.474l8.6-9.83L0 1.154h7.594l5.243 6.932ZM17.61 20.644h2.039L6.486 3.24H4.298Z" /></svg>
);

const WhatsAppIcon = ({ className }: { className?: string }) => (
    <svg role="img" viewBox="0 0 24 24" fill="currentColor" className={className} xmlns="http://www.w3.org/2000/svg"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.008-.57-.008-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 0 1-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 0 1-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 0 1 2.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0 0 12.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 0 0 5.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 0 0-3.48-8.413Z" /></svg>
);

export default function ShareButtons({ url, title, description = '' }: ShareButtonsProps) {
    const [isOpen, setIsOpen] = useState(false);
    const modalRef = useRef<HTMLDivElement>(null);

    const encodedUrl = encodeURIComponent(url);
    const encodedTitle = encodeURIComponent(title);

    const shareLinks = {
        facebook: `https://www.facebook.com/sharer/sharer.php?u=${encodedUrl}`,
        twitter: `https://twitter.com/intent/tweet?url=${encodedUrl}&text=${encodedTitle}`,
        linkedin: `https://www.linkedin.com/sharing/share-offsite/?url=${encodedUrl}`,
        whatsapp: `https://wa.me/?text=${encodedTitle}%20${encodedUrl}`
    };

    const handleShare = (platform: keyof typeof shareLinks) => {
        window.open(shareLinks[platform], '_blank', 'width=600,height=400');
        setIsOpen(false);
    };

    const copyToClipboard = async () => {
        try {
            await navigator.clipboard.writeText(url);
            toast.success('Link berhasil disalin!');
            setIsOpen(false);
        } catch (err) {
            toast.error('Gagal menyalin link');
        }
    };

    // Close modal when clicking outside
    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (modalRef.current && !modalRef.current.contains(event.target as Node)) {
                setIsOpen(false);
            }
        };

        if (isOpen) {
            document.addEventListener('mousedown', handleClickOutside);
        }

        return () => {
            document.removeEventListener('mousedown', handleClickOutside);
        };
    }, [isOpen]);

    return (
        <>
            <button
                onClick={() => setIsOpen(true)}
                className="flex items-center space-x-2 text-slate-500 hover:text-slate-900 transition-colors group"
            >
                <Share2 size={18} className="text-slate-400 group-hover:text-slate-900 transition-colors" />
                <span className="font-medium text-sm text-slate-600 group-hover:text-slate-900">Bagikan</span>
            </button>

            {isOpen && (
                <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm animate-in fade-in duration-200">
                    <div
                        ref={modalRef}
                        className="bg-white rounded-2xl shadow-2xl w-full max-w-sm overflow-hidden animate-in zoom-in-95 duration-200 relative"
                    >
                        <button
                            onClick={() => setIsOpen(false)}
                            className="absolute top-4 right-4 p-2 rounded-full hover:bg-slate-100 transition-colors text-slate-400 hover:text-slate-600"
                        >
                            <X size={20} />
                        </button>

                        <div className="p-8">
                            <h3 className="text-lg font-bold text-center text-slate-900 mb-8">Bagikan</h3>

                            <div className="flex justify-center items-start gap-6">
                                {/* Copy Link */}
                                <div className="flex flex-col items-center gap-3 group cursor-pointer w-16" onClick={copyToClipboard}>
                                    <div className="w-12 h-12 rounded-full bg-slate-100 text-slate-900 flex items-center justify-center group-hover:bg-slate-200 transition-colors">
                                        <LinkIcon size={20} />
                                    </div>
                                    <span className="text-[10px] font-medium text-slate-600 text-center leading-tight">Salin Link</span>
                                </div>

                                {/* Facebook */}
                                <div className="flex flex-col items-center gap-3 group cursor-pointer w-16" onClick={() => handleShare('facebook')}>
                                    <div className="w-12 h-12 rounded-full bg-slate-100 text-slate-900 flex items-center justify-center group-hover:bg-slate-200 transition-colors">
                                        <FacebookIcon className="h-5 w-5" />
                                    </div>
                                    <span className="text-[10px] font-medium text-slate-600 text-center leading-tight">Facebook</span>
                                </div>

                                {/* Twitter / X */}
                                <div className="flex flex-col items-center gap-3 group cursor-pointer w-16" onClick={() => handleShare('twitter')}>
                                    <div className="w-12 h-12 rounded-full bg-slate-100 text-slate-900 flex items-center justify-center group-hover:bg-slate-200 transition-colors">
                                        <TwitterIcon className="h-4 w-4" />
                                    </div>
                                    <span className="text-[10px] font-medium text-slate-600 text-center leading-tight">Twitter</span>
                                </div>

                                {/* WhatsApp */}
                                <div className="flex flex-col items-center gap-3 group cursor-pointer w-16" onClick={() => handleShare('whatsapp')}>
                                    <div className="w-12 h-12 rounded-full bg-slate-100 text-slate-900 flex items-center justify-center group-hover:bg-slate-200 transition-colors">
                                        <WhatsAppIcon className="h-5 w-5" />
                                    </div>
                                    <span className="text-[10px] font-medium text-slate-600 text-center leading-tight">WhatsApp</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            )}
        </>
    );
}
