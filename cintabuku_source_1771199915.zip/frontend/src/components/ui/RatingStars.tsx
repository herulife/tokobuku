import { Star, StarHalf } from "lucide-react";

interface RatingStarsProps {
    rating: number;
    maxStars?: number;
    size?: number;
}

const RatingStars = ({ rating, maxStars = 5, size = 16 }: RatingStarsProps) => {
    const stars = [];

    for (let i = 1; i <= maxStars; i++) {
        if (rating >= i) {
            stars.push(<Star key={i} size={size} className="text-yellow-400 fill-current" />);
        } else if (rating >= i - 0.5) {
            stars.push(<StarHalf key={i} size={size} className="text-yellow-400 fill-current" />);
        } else {
            stars.push(<Star key={i} size={size} className="text-gray-300" />);
        }
    }

    return <div className="flex space-x-0.5">{stars}</div>;
};

export default RatingStars;
