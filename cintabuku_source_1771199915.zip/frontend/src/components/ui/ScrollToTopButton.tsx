'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faChevronUp } from '@fortawesome/free-solid-svg-icons';

export default function ScrollToTopButton() {
    const [isVisible, setIsVisible] = useState(false);

    useEffect(() => {
        const toggleVisibility = () => {
            if (window.scrollY > 300) {
                setIsVisible(true);
            } else {
                setIsVisible(false);
            }
        };

        window.addEventListener('scroll', toggleVisibility);

        return () => window.removeEventListener('scroll', toggleVisibility);
    }, []);

    const scrollToTop = () => {
        window.scrollTo({
            top: 0,
            behavior: 'smooth',
        });
    };

    if (!isVisible) {
        return null; // Don't render anything if not visible
    }

    return (
        <div className="fixed bottom-8 right-8 z-50">
            <Button
                onClick={scrollToTop}
                variant="ghost"
                size="icon"
                className="rounded-full bg-slate-200 text-slate-600 hover:bg-slate-300 h-10 w-10 shadow-sm transition-all duration-300 animate-in fade-in zoom-in"
                aria-label="Scroll to top"
            >
                <FontAwesomeIcon icon={faChevronUp} className="h-5 w-5" />
            </Button>
        </div>
    );
}
