'use client';

import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { ArrowLeft } from 'lucide-react';

interface BackButtonProps {
    className?: string;
    text?: string;
    variant?: 'default' | 'outline' | 'ghost' | 'link';
}

export default function BackButton({
    className = "",
    text = "Kembali",
    variant = "outline"
}: BackButtonProps) {
    const router = useRouter();

    return (
        <Button
            variant={variant}
            className={`hover:bg-transparent hover:text-emerald-700 text-slate-500 transition-colors ${className}`}
            onClick={() => router.back()}
        >
            <ArrowLeft className="mr-2 h-4 w-4" />
            {text}
        </Button>
    );
}
