'use client';

import { BookOpen, Heart, ShoppingBag, Truck, BadgeCheck, ShieldCheck } from 'lucide-react';

export default function FeaturesSection() {
    return (
        <section className="py-20 px-4 sm:px-6 lg:px-8 bg-white relative overflow-hidden">
            {/* Background Decoration */}
            <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(#e5e7eb_1px,transparent_1px)] [background-size:16px_16px] opacity-30"></div>

            <div className="max-w-7xl mx-auto relative z-10">
                {/* Section Header */}
                <div className="text-center mb-16">
                    <span className="text-emerald-600 font-semibold tracking-wider text-xs uppercase bg-emerald-50 px-3 py-1 rounded-full">Kenapa Kami?</span>
                    <h2 className="text-3xl md:text-4xl font-serif font-bold text-stone-800 mt-4">Lebih Dari Sekadar Toko Buku</h2>
                    <p className="text-stone-500 mt-4 max-w-2xl mx-auto">Kami menyediakan pengalaman belanja buku yang nyaman, aman, dan penuh berkah untuk keluarga Anda.</p>
                </div>

                {/* Dashboard Preview (Rak Buku) */}
                <div className="bg-[#FDFBF7] rounded-3xl border border-stone-200 p-8 md:p-12 shadow-xl mb-20 relative overflow-hidden">
                    {/* Glass Overlay effect */}
                    <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-100/50 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2"></div>

                    <div className="flex flex-col md:flex-row items-center justify-between gap-8 relative z-10">
                        <div className="flex items-center gap-6">
                            <div className="w-16 h-16 bg-emerald-900 rounded-2xl flex items-center justify-center shadow-lg shadow-emerald-900/20">
                                <BookOpen className="w-8 h-8 text-[#FDFBF7]" />
                            </div>
                            <div>
                                <h3 className="text-2xl font-bold text-stone-800">Rak Buku Digital</h3>
                                <p className="text-stone-500 text-sm mt-1">Kelola wishlist, keranjang, dan koleksi Anda dengan mudah.</p>
                            </div>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 w-full md:w-auto">
                            {/* Stat 1 */}
                            <div className="bg-white p-5 rounded-2xl border border-stone-100 shadow-sm flex flex-col items-center text-center gap-2 hover:-translate-y-1 transition-transform">
                                <div className="p-2 bg-rose-50 rounded-full text-rose-500">
                                    <Heart className="w-5 h-5 fill-current" />
                                </div>
                                <div>
                                    <span className="block text-2xl font-bold text-stone-800">12</span>
                                    <span className="text-xs text-stone-400 font-medium uppercase tracking-wide">Wishlist</span>
                                </div>
                            </div>

                            {/* Stat 2 */}
                            <div className="bg-white p-5 rounded-2xl border border-stone-100 shadow-sm flex flex-col items-center text-center gap-2 hover:-translate-y-1 transition-transform">
                                <div className="p-2 bg-amber-50 rounded-full text-amber-500">
                                    <ShoppingBag className="w-5 h-5 fill-current" />
                                </div>
                                <div>
                                    <span className="block text-2xl font-bold text-stone-800">3</span>
                                    <span className="text-xs text-stone-400 font-medium uppercase tracking-wide">Keranjang</span>
                                </div>
                            </div>

                            {/* Stat 3 */}
                            <div className="bg-white p-5 rounded-2xl border border-stone-100 shadow-sm flex flex-col items-center text-center gap-2 hover:-translate-y-1 transition-transform">
                                <div className="p-2 bg-emerald-50 rounded-full text-emerald-600">
                                    <BadgeCheck className="w-5 h-5 fill-current" />
                                </div>
                                <div>
                                    <span className="block text-2xl font-bold text-stone-800">24</span>
                                    <span className="text-xs text-stone-400 font-medium uppercase tracking-wide">Koleksi</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Feature Grid */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                    {[
                        { icon: Truck, title: "Gratis Ongkir", desc: "Minimal belanja Rp100rb ke seluruh Jabodetabek." },
                        { icon: ShieldCheck, title: "Jaminan Original", desc: "100% buku asli langsung dari penerbit terpercaya." },
                        { icon: BookOpen, title: "Preview Isi Buku", desc: "Baca beberapa halaman sebelum memutuskan membeli." }
                    ].map((feature, i) => (
                        <div key={i} className="flex items-start gap-4 p-6 rounded-2xl bg-stone-50 hover:bg-[#FDFBF7] border border-transparent hover:border-emerald-100 transition-colors group">
                            <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center text-stone-400 group-hover:text-emerald-600 group-hover:shadow-md transition-all">
                                <feature.icon className="w-6 h-6" />
                            </div>
                            <div>
                                <h4 className="font-bold text-stone-800 mb-1 group-hover:text-emerald-900 transition-colors">{feature.title}</h4>
                                <p className="text-sm text-stone-500 leading-relaxed">{feature.desc}</p>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </section>
    );
}
