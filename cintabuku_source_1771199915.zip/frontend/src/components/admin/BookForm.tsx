'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useForm } from 'react-hook-form';
import { apiClient } from '@/lib/api-client';
import { toast } from 'sonner';
import { getImageUrl } from '@/lib/image-utils';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Loader2, Save, ArrowLeft } from 'lucide-react';
import Link from 'next/link';
import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
} from "@/components/ui/select";

interface BookFormData {
    title: string;
    author: string;
    description: string;
    price: number;
    stock: number;
    weight: number; // Berat buku dalam gram
    coverImage?: string;
    isbn: string;
    publisher: string;
    publishedDate: string;
    pages: number;
    language: string;
    categoryId: string; // Assuming we select ID
}

interface BookFormProps {
    initialData?: any;
    isEdit?: boolean;
}

export function BookForm({ initialData, isEdit = false }: BookFormProps) {
    const router = useRouter();
    const [loading, setLoading] = useState(false);
    const [categories, setCategories] = useState<any[]>([]);

    useEffect(() => {
        const fetchCategories = async () => {
            try {
                const res: any = await apiClient.get('/categories');
                setCategories(res.data.categories);
            } catch (error) {
                console.error('Failed to fetch categories', error);
                toast.error('Gagal memuat kategori');
            }
        };
        fetchCategories();
    }, []);

    const [preview, setPreview] = useState<string | null>(initialData?.coverImage || null);
    const [selectedFile, setSelectedFile] = useState<File | null>(null);

    const { register, handleSubmit, setValue, formState: { errors } } = useForm<BookFormData>({
        defaultValues: initialData || {
            title: '',
            author: '',
            description: '',
            price: 0,
            stock: 0,
            weight: 300, // Default 300 gram
            coverImage: initialData?.coverImage ? getImageUrl(initialData.coverImage) : '',
            isbn: '',
            publisher: '',
            publishedDate: new Date().toISOString().split('T')[0],
            pages: 0,
            language: 'Indonesia',
            categoryId: ''
        }
    });

    // Update preview if initialData changes
    useEffect(() => {
        if (initialData?.coverImage) {
            setPreview(getImageUrl(initialData.coverImage));
        }
    }, [initialData]);

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            setSelectedFile(file);
            const reader = new FileReader();
            reader.onloadend = () => {
                setPreview(reader.result as string);
            };
            reader.readAsDataURL(file);
        }
    };

    const onSubmit = async (data: BookFormData) => {
        setLoading(true);
        try {
            const formData = new FormData();
            formData.append('title', data.title);
            formData.append('author', data.author);
            formData.append('isbn', data.isbn);
            formData.append('price', String(data.price));
            formData.append('stock', String(data.stock));
            formData.append('weight', String(data.weight));
            formData.append('description', data.description);
            formData.append('publisher', data.publisher);
            formData.append('publishedDate', data.publishedDate);
            formData.append('pages', String(data.pages));
            formData.append('language', data.language);
            formData.append('categoryId', data.categoryId);

            // Handle file upload
            if (selectedFile) {
                formData.append('coverImage', selectedFile);
            } else if (initialData?.coverImage) {
                // Keep existing image if no new file selected (handled by backend not updating if field missing? 
                // OR we can send the string URL back, but backend middleware expects file.
                // If we don't send 'coverImage' field, backend 'req.file' is undefined.
                // We should ensure backend only updates coverImage if req.file exists.
                formData.append('coverImage', initialData.coverImage);
            }

            const config = {
                headers: {
                    'Content-Type': 'multipart/form-data',
                },
            };

            if (isEdit && initialData?.id) {
                await apiClient.put(`/books/${initialData.id}`, formData, config);
                toast.success('Buku berhasil diperbarui');
            } else {
                await apiClient.post('/books', formData, config);
                toast.success('Buku berhasil ditambahkan');
            }
            router.push('/admin/books');
            router.refresh();
        } catch (error: any) {
            toast.error(error.message || 'Gagal menyimpan buku');
            console.error(error);
        } finally {
            setLoading(false);
        }
    };

    return (
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-6 max-w-2xl bg-white p-8 rounded-xl border border-slate-100 shadow-sm">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="md:col-span-2">
                    <label className="block text-sm font-medium text-slate-700 mb-1">Judul Buku</label>
                    <Input {...register('title', { required: 'Judul wajib diisi' })} placeholder="Contoh: Laskar Pelangi" />
                    {errors.title && <span className="text-red-500 text-xs">{errors.title.message}</span>}
                </div>

                <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Penulis</label>
                    <Input {...register('author', { required: 'Penulis wajib diisi' })} placeholder="Nama Penulis" />
                    {errors.author && <span className="text-red-500 text-xs">{errors.author.message}</span>}
                </div>

                <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">ISBN</label>
                    <Input {...register('isbn', { required: 'ISBN wajib diisi' })} placeholder="123-456-789" />
                    {errors.isbn && <span className="text-red-500 text-xs">{errors.isbn.message}</span>}
                </div>

                <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Harga (Rp)</label>
                    <Input type="number" {...register('price', { required: true, min: 0 })} placeholder="0" />
                </div>

                <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Stok</label>
                    <Input type="number" {...register('stock', { required: true, min: 0 })} placeholder="0" />
                </div>

                <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Berat (gram)</label>
                    <Input type="number" {...register('weight', { required: true, min: 1 })} placeholder="300" />
                    <p className="text-xs text-slate-500 mt-1">Berat buku untuk hitung ongkir</p>
                </div>

                <div className="md:col-span-2">
                    <label className="block text-sm font-medium text-slate-700 mb-1">Gambar Sampul</label>
                    <div className="flex items-start space-x-4">
                        <div className="flex-1">
                            <Input
                                type="file"
                                accept="image/*"
                                onChange={handleFileChange}
                                className="cursor-pointer file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-emerald-50 file:text-emerald-700 hover:file:bg-emerald-100"
                            />
                            <p className="text-xs text-slate-500 mt-1">Format: JPG, PNG, WebP. Maks 5MB. Otomatis convert ke WebP.</p>
                        </div>
                        {preview && (
                            <div className="relative w-24 h-36 rounded-lg overflow-hidden border border-slate-200 shadow-sm shrink-0">
                                {/* eslint-disable-next-line @next/next/no-img-element */}
                                <img src={preview} alt="Preview" className="w-full h-full object-cover" />
                            </div>
                        )}
                    </div>
                </div>

                <div className="md:col-span-2">
                    <label className="block text-sm font-medium text-slate-700 mb-1">Deskripsi</label>
                    <textarea
                        {...register('description', { required: 'Deskripsi wajib diisi' })}
                        rows={4}
                        className="w-full rounded-md border border-slate-200 p-3 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600"
                        placeholder="Sinopsis buku..."
                    />
                    {errors.description && <span className="text-red-500 text-xs">{errors.description.message}</span>}
                </div>

                {/* Additional fields */}
                <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Penerbit</label>
                    <Input {...register('publisher')} placeholder="Nama Penerbit" />
                </div>
                <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Tanggal Terbit</label>
                    <Input type="date" {...register('publishedDate')} />
                </div>
                <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Jumlah Halaman</label>
                    <Input type="number" {...register('pages')} />
                </div>
                <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Bahasa</label>
                    <Input {...register('language')} defaultValue="Indonesia" />
                </div>

                <div className="md:col-span-2">
                    <label className="block text-sm font-medium text-slate-700 mb-1">Kategori</label>
                    <Select
                        onValueChange={(value) => setValue('categoryId', value)}
                        defaultValue={initialData?.categoryId || undefined}
                    >
                        <SelectTrigger>
                            <SelectValue placeholder="Pilih Kategori" />
                        </SelectTrigger>
                        <SelectContent>
                            {categories.map((category) => (
                                <SelectItem key={category.id} value={category.id}>
                                    {category.name}
                                </SelectItem>
                            ))}
                        </SelectContent>
                    </Select>
                    {/* Hidden input to register with hook form if needed, but setValue handles it. 
                        However, we need validaton. */}
                    <input type="hidden" {...register('categoryId', { required: 'Kategori wajib dipilih' })} />
                    {errors.categoryId && <span className="text-red-500 text-xs">{errors.categoryId.message}</span>}
                </div>
            </div>

            <div className="flex justify-end space-x-4 pt-4 border-t">
                <Button type="button" variant="outline" onClick={() => router.back()}>
                    Batal
                </Button>
                <Button type="submit" disabled={loading} className="bg-emerald-600 hover:bg-emerald-700">
                    {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
                    {isEdit ? 'Simpan Perubahan' : 'Tambah Buku'}
                </Button>
            </div>
        </form>
    );
}
