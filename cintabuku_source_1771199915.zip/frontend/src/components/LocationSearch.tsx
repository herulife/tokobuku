import React, { useState, useEffect, useRef } from 'react';
import { Search, MapPin, Loader2, X } from 'lucide-react';
import { apiClient } from '@/lib/api-client';

interface Location {
    id: string; // Destination ID
    label: string; // Helper property if backend returns 'name' or similar, we map it
    // Actual fields from API might be:
    // destination_name: "Kecamatan Gambir",
    // city_name: "Jakarta Pusat",
    // province_name: "DKI Jakarta"
    // subdistrict_name?
    // We will inspect exact response structure from service. 
    // Service returns whatever Komerce returns. Komerce returns:
    // { id: 2095, destination_name: "Gambir, Gambir, Jakarta Pusat, DKI Jakarta", ... }
    // Let's assume Komerce returns a 'label' or we construct it.

    // Based on my service code: `return response.data?.data || []`
    // Komerce usually returns objects with `id`, `name` (or similar).
    // Let's type as any for now to be safe, or generic.
    [key: string]: any;
}

interface LocationSearchProps {
    onSelect: (location: Location) => void;
    initialValue?: string; // Initial label to display
    placeholder?: string;
    label?: string;
}

export default function LocationSearch({ onSelect, initialValue = '', placeholder = 'Cari Kecamatan / Kota...', label }: LocationSearchProps) {
    const [query, setQuery] = useState(initialValue);
    const [results, setResults] = useState<Location[]>([]);
    const [loading, setLoading] = useState(false);
    const [isOpen, setIsOpen] = useState(false);
    const wrapperRef = useRef<HTMLDivElement>(null);

    // Debounce query
    useEffect(() => {
        const timer = setTimeout(() => {
            if (query && query.length >= 3 && isOpen) {
                searchLocations(query);
            }
        }, 500);

        return () => clearTimeout(timer);
    }, [query, isOpen]);

    // Handle clicks outside to close dropdown
    useEffect(() => {
        function handleClickOutside(event: MouseEvent) {
            if (wrapperRef.current && !wrapperRef.current.contains(event.target as Node)) {
                setIsOpen(false);
            }
        }
        document.addEventListener("mousedown", handleClickOutside);
        return () => document.removeEventListener("mousedown", handleClickOutside);
    }, [wrapperRef]);

    // Sync initial value if it changes
    useEffect(() => {
        if (initialValue && query !== initialValue) {
            setQuery(initialValue);
        }
    }, [initialValue]);

    const searchLocations = async (keyword: string) => {
        setLoading(true);
        try {
            // Note: If backend API fails, it now returns local fallback cities (e.g. Jakarta, Bandung, etc.)
            const response = await apiClient.get<Location[]>(`/shipping/search?keyword=${encodeURIComponent(keyword)}`);

            // Handle array response directly or object with data property
            const data = Array.isArray(response) ? response : (response as any).data || [];
            setResults(data);
        } catch (error) {
            console.error('Failed to search locations:', error);
            setResults([]);
        } finally {
            setLoading(false);
        }
    };

    const handleSelect = (location: Location) => {
        // Construct a display label if not present
        // Komerce might return 'subdistrict_name', 'city_name', 'province_name'
        // Or just 'name' if Komerce's unified search is used.
        // Let's assume the backend passes through Komerce data.

        // Common Komerce structure:
        // { id: 123, label: "Gambir, Jakarta Pusat" } -> if backend formats it.
        // If pure raw: we might need to format it here.
        // Let's rely on `location.destination_name` or `location.name` or `location.label`.

        const displayLabel = location.label || location.destination_name || location.name || `${location.subdistrict_name}, ${location.city_name}`;

        setQuery(displayLabel);
        setIsOpen(false);
        onSelect(location);
    };

    const handleClear = () => {
        setQuery('');
        setResults([]);
        onSelect({ id: '', label: '' }); // Clear parent
    };

    return (
        <div className="relative w-full" ref={wrapperRef}>
            {label && <label className="block text-sm font-medium text-slate-700 mb-1">{label}</label>}
            <div className="relative">
                <input
                    type="text"
                    className="w-full pl-10 pr-10 py-2 border rounded-lg focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                    placeholder={placeholder}
                    value={query}
                    onChange={(e) => {
                        setQuery(e.target.value);
                        setIsOpen(true);
                    }}
                    onFocus={() => setIsOpen(true)}
                />
                <Search className="absolute left-3 top-2.5 h-5 w-5 text-slate-400" />

                {loading && (
                    <Loader2 className="absolute right-3 top-2.5 h-5 w-5 text-slate-400 animate-spin" />
                )}

                {!loading && query && (
                    <button
                        onClick={handleClear}
                        className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-600"
                    >
                        <X className="h-5 w-5" />
                    </button>
                )}
            </div>

            {isOpen && results.length > 0 && (
                <ul className="absolute z-50 w-full mt-1 bg-white border rounded-lg shadow-lg max-h-60 overflow-y-auto">
                    {results.map((location, index) => (
                        <li
                            key={location.id || index}
                            className="px-4 py-2 hover:bg-slate-100 cursor-pointer flex items-center gap-2"
                            onClick={() => handleSelect(location)}
                        >
                            <MapPin className="h-4 w-4 text-slate-400 flex-shrink-0" />
                            <span className="text-sm text-slate-700">
                                {location.label || location.destination_name || location.name || `${location.subdistrict_name}, ${location.city_name}, ${location.province_name}`}
                            </span>
                        </li>
                    ))}
                </ul>
            )}

            {isOpen && query.length >= 3 && !loading && results.length === 0 && (
                <div className="absolute z-50 w-full mt-1 bg-white border rounded-lg shadow-lg p-4 text-center text-sm text-slate-500">
                    Tidak ditemukan. Coba kata kunci lain.
                </div>
            )}
        </div>
    );
}
