'use client';

import Link from 'next/link';
import { ShoppingCart, Heart } from 'lucide-react';
import { Button } from '@/components/ui/button';
import RatingStars from '@/components/ui/RatingStars';
import { formatCurrency } from '@/lib/utils';
import { useCartStore } from '@/store/useCartStore';
import { useWishlistStore } from '@/store/useWishlistStore';
import { useAuthStore } from '@/store/useAuthStore';
import { useRouter } from 'next/navigation';
import { toast } from 'sonner';

interface Book {
    id: string;
    title: string;
    slug: string;
    author: string;
    price: number;
    discountPrice?: number | null;
    coverImage: string;
    rating?: number | null;
    category?: {
        name: string;
    },
    stock: number;
}

interface BookCardProps {
    book: Book;
}

const BookCard = ({ book }: BookCardProps) => {
    const router = useRouter();
    const { isAuthenticated } = useAuthStore();
    const addItem = useCartStore(state => state.addItem);
    const addToWishlist = useWishlistStore(state => state.addToWishlist);
    const removeFromWishlist = useWishlistStore(state => state.removeFromWishlist);
    const isInWishlist = useWishlistStore(state => state.isInWishlist(book.id));

    const handleAddToCart = async (e: React.MouseEvent) => {
        e.preventDefault();
        if (book.stock <= 0) {
            toast.error('Maaf, stok habis');
            return;
        }
        if (!isAuthenticated) {
            router.push('/auth/login');
            return;
        }
        await addItem(book as any); // Cast because Book interface might be slightly different in types
        toast.success('Berhasil ditambahkan ke keranjang');
    };

    const handleAddToWishlist = async (e: React.MouseEvent) => {
        e.preventDefault();
        if (!isAuthenticated) {
            router.push('/auth/login');
            return;
        }

        if (isInWishlist) {
            await removeFromWishlist(book.id);
            toast.success('Dihapus dari wishlist');
        } else {
            await addToWishlist(book as any);
            toast.success('Ditambahkan ke wishlist');
        }
    }

    return (
        <div className="group relative bg-white rounded-xl shadow-sm hover:shadow-xl transition-all duration-300 border border-slate-100 overflow-hidden flex flex-col h-full">
            {/* Discount Badge */}
            {book.stock <= 0 && (
                <span className="absolute top-3 left-3 bg-slate-500 text-white text-xs font-bold px-2 py-1 rounded-full z-10">
                    Stok Habis
                </span>
            )}
            {book.stock > 0 && book.discountPrice && (
                <span className="absolute top-3 left-3 bg-red-500 text-white text-xs font-bold px-2 py-1 rounded-full z-10">
                    Hemat {Math.round(((book.price - book.discountPrice) / book.price) * 100)}%
                </span>
            )}

            {/* Wishlist Button (Visible on Hover) */}
            <button
                onClick={handleAddToWishlist}
                className={`absolute top-3 right-3 p-2 bg-white/90 backdrop-blur-sm rounded-full shadow-sm transition-all duration-300 z-10 transform ${isInWishlist ? 'text-red-500 opacity-100' : 'text-slate-400 opacity-0 group-hover:opacity-100 translate-y-2 group-hover:translate-y-0 hover:text-red-500 hover:bg-red-50'}`}
            >
                <Heart size={18} fill={isInWishlist ? "currentColor" : "none"} />
            </button>

            {/* Cover Image */}
            <Link href={`/books/${book.slug}`} className="relative aspect-[2/3] overflow-hidden bg-slate-50">
                <img
                    src={book.coverImage}
                    alt={book.title}
                    className="object-cover w-full h-full group-hover:scale-110 transition-transform duration-500"
                />
                {/* Overlay on hover */}
                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/5 transition-colors duration-300" />
            </Link>

            {/* Content */}
            <div className="p-4 flex flex-col flex-grow">
                <div className="text-xs text-emerald-600 font-medium mb-1 uppercase tracking-wider">
                    {book.category?.name || 'Umum'}
                </div>

                <Link href={`/books/${book.slug}`} className="block">
                    <h3 className="text-base font-bold text-slate-800 line-clamp-2 mb-1 group-hover:text-emerald-600 transition-colors">
                        {book.title}
                    </h3>
                </Link>

                <p className="text-sm text-slate-500 mb-2 truncate">{book.author}</p>

                <div className="mb-3">
                    <RatingStars rating={book.rating || 0} />
                </div>

                <div className="mt-auto flex items-end justify-between">
                    <div>
                        {book.discountPrice ? (
                            <div className="flex flex-col">
                                <span className="text-xs text-slate-400 line-through">
                                    {formatCurrency(book.price)}
                                </span>
                                <span className="text-lg font-bold text-slate-900">
                                    {formatCurrency(book.discountPrice)}
                                </span>
                            </div>
                        ) : (
                            <span className="text-lg font-bold text-slate-900">
                                {formatCurrency(book.price)}
                            </span>
                        )}
                    </div>

                    <Button
                        size="icon"
                        className={`h-8 w-8 rounded-full transition-colors shadow-none hover:shadow-md ${book.stock > 0 ? 'bg-emerald-50 text-emerald-600 hover:bg-emerald-600 hover:text-white' : 'bg-slate-100 text-slate-400 cursor-not-allowed'}`}
                        onClick={handleAddToCart}
                        disabled={book.stock <= 0}
                    >
                        <ShoppingCart size={16} />
                    </Button>
                </div>
            </div>
        </div>
    );
};

export default BookCard;
