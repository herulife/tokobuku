'use client';

import { Heart, Instagram, Facebook, Twitter, Youtube } from 'lucide-react';
import Link from 'next/link';

export default function Footer() {
    return (
        <footer className="bg-[#FDFBF7] border-t border-stone-200 pt-16 pb-8">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
                    {/* Brand */}
                    <div className="col-span-1 md:col-span-1">
                        <div className="flex items-center space-x-2 mb-6">
                            <Heart className="w-6 h-6 text-emerald-800 fill-emerald-800/20" />
                            <span className="font-serif font-bold text-xl text-emerald-950">Koalisi Cinta Buku</span>
                        </div>
                        <p className="text-stone-500 text-sm leading-relaxed mb-6">
                            Toko buku online dengan hati. Menyediakan bacaan berkualitas untuk membangun peradaban yang lebih baik.
                        </p>
                        <div className="flex space-x-4">
                            {[Instagram, Facebook, Twitter, Youtube].map((Icon, i) => (
                                <Link key={i} href="#" className="w-10 h-10 rounded-full bg-stone-100 flex items-center justify-center text-stone-500 hover:bg-emerald-900 hover:text-white transition-all">
                                    <Icon className="w-5 h-5" />
                                </Link>
                            ))}
                        </div>
                    </div>

                    {/* Links */}
                    <div>
                        <h4 className="font-bold text-stone-900 mb-6">Katalog</h4>
                        <ul className="space-y-3 text-sm text-stone-500">
                            <li><Link href="#" className="hover:text-emerald-700 transition-colors">Semua Buku</Link></li>
                            <li><Link href="#" className="hover:text-emerald-700 transition-colors">Best Seller</Link></li>
                            <li><Link href="#" className="hover:text-emerald-700 transition-colors">Buku Anak</Link></li>
                            <li><Link href="#" className="hover:text-emerald-700 transition-colors">Parenting</Link></li>
                        </ul>
                    </div>

                    <div>
                        <h4 className="font-bold text-stone-900 mb-6">Bantuan</h4>
                        <ul className="space-y-3 text-sm text-stone-500">
                            <li><Link href="#" className="hover:text-emerald-700 transition-colors">Cara Belanja</Link></li>
                            <li><Link href="/profile" className="hover:text-emerald-700 transition-colors">Konfirmasi Pembayaran</Link></li>
                            <li><Link href="#" className="hover:text-emerald-700 transition-colors">Pengiriman</Link></li>
                            <li><Link href="#" className="hover:text-emerald-700 transition-colors">Hubungi Kami</Link></li>
                        </ul>
                    </div>

                    <div>
                        <h4 className="font-bold text-stone-900 mb-6">Tentang</h4>
                        <ul className="space-y-3 text-sm text-stone-500">
                            <li><Link href="#" className="hover:text-emerald-700 transition-colors">Tentang Kami</Link></li>
                            <li><Link href="#" className="hover:text-emerald-700 transition-colors">Visi & Misi</Link></li>
                            <li><Link href="#" className="hover:text-emerald-700 transition-colors">Karir</Link></li>
                            <li><Link href="#" className="hover:text-emerald-700 transition-colors">Blog</Link></li>
                        </ul>
                    </div>
                </div>

                <div className="border-t border-stone-200 pt-8 flex flex-col md:flex-row justify-between items-center text-sm text-stone-400">
                    <p>© 2026 Koalisi Cinta Buku. All rights reserved.</p>
                    <div className="flex space-x-6 mt-4 md:mt-0">
                        <Link href="#" className="hover:text-stone-600">Privacy Policy</Link>
                        <Link href="#" className="hover:text-stone-600">Terms of Service</Link>
                    </div>
                </div>
            </div>
        </footer>
    );
}
