'use client';

import Link from 'next/link';
import Image from 'next/image';
import { Search, Heart, ShoppingCart, User, Menu, X, LogOut, Settings } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useState, useEffect } from 'react';
import { cn } from '@/lib/utils';
import { useAuthStore } from '@/store/useAuthStore';
import {
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuItem,
    DropdownMenuLabel,
    DropdownMenuSeparator,
    DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

import { useCartStore } from '@/store/useCartStore';
import { useWishlistStore } from '@/store/useWishlistStore';

export default function Navbar() {
    const [isScrolled, setIsScrolled] = useState(false);
    const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
    const { user, isAuthenticated, logout } = useAuthStore();

    // Get store values (automatically reactive)
    const cartItems = useCartStore((state) => state.items);
    const wishlistItems = useWishlistStore((state) => state.items);

    // Calculate counts
    const cartCount = cartItems.reduce((acc, item) => acc + item.quantity, 0);
    const wishlistCount = wishlistItems.length;

    // Optional: Hydration safety if needed, but zustand/persist usually handles it.
    // However, to avoid hydration mismatch on server vs client initially:
    const [mounted, setMounted] = useState(false);
    useEffect(() => {
        setMounted(true);
    }, []);

    // If not mounted yet, we might want to hide badges or show 0 to avoid mismatch
    // But since this is a client component, it's safer to just rely on mounted check for the numbers if using persist
    // or just let it re-render.

    useEffect(() => {
        const handleScroll = () => {
            setIsScrolled(window.scrollY > 10);
        };
        window.addEventListener('scroll', handleScroll);
        return () => window.removeEventListener('scroll', handleScroll);
    }, []);

    const handleLogout = async () => {
        await logout();
    };

    return (
        <nav className={cn(
            "fixed top-0 left-0 right-0 z-50 transition-all duration-300 border-b border-transparent",
            isScrolled ? "bg-[#FDFBF7]/80 backdrop-blur-md border-emerald-100/50 shadow-sm py-2" : "bg-[#FDFBF7] py-4"
        )}>
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="flex justify-between items-center h-16">

                    {/* Logo */}
                    <Link href="/" className="flex items-center space-x-3 group">
                        <div className="bg-emerald-900/5 p-2 rounded-xl group-hover:bg-emerald-900/10 transition-colors">
                            <Heart className="w-6 h-6 text-emerald-800 fill-emerald-800/10" />
                        </div>
                        <div className="flex flex-col">
                            <span className="font-serif font-bold text-xl text-emerald-950 tracking-tight">
                                Koalisi Cinta Buku
                            </span>
                            <span className="text-[10px] text-emerald-800/60 font-medium tracking-widest uppercase">cintabuku.com</span>
                        </div>
                    </Link>

                    {/* Desktop Search - Pill Shape */}
                    <div className="hidden md:flex flex-1 max-w-md mx-8">
                        <div className="relative w-full group">
                            <div className="absolute inset-y-0 left-3 flex items-center pointer-events-none">
                                <Search className="h-4 w-4 text-emerald-800/40 group-focus-within:text-emerald-800 transition-colors" />
                            </div>
                            <input
                                type="text"
                                placeholder="Cari judul buku, penulis..."
                                className="w-full bg-emerald-900/5 border-none rounded-full py-2.5 pl-10 pr-4 text-sm text-emerald-900 placeholder:text-emerald-800/40 focus:ring-2 focus:ring-emerald-100 focus:bg-white transition-all outline-none"
                            />
                        </div>
                    </div>

                    {/* Desktop Actions */}
                    <div className="hidden md:flex items-center space-x-2">
                        <Link href="/wishlist">
                            <Button variant="ghost" size="icon" className="rounded-full text-emerald-800 hover:text-emerald-950 hover:bg-emerald-900/5 relative">
                                <Heart className="w-5 h-5" />
                                {mounted && wishlistCount > 0 && (
                                    <span className="absolute top-1 right-1 w-2.5 h-2.5 bg-rose-500 rounded-full border-2 border-[#FDFBF7] flex items-center justify-center text-[8px] text-white font-bold">
                                    </span>
                                )}
                            </Button>
                        </Link>
                        <Link href="/cart">
                            <Button variant="ghost" size="icon" className="rounded-full text-emerald-800 hover:text-emerald-950 hover:bg-emerald-900/5 relative">
                                <ShoppingCart className="w-5 h-5" />
                                {mounted && cartCount > 0 && (
                                    <span className="absolute -top-1 -right-1 w-4 h-4 bg-emerald-600 rounded-full border-2 border-[#FDFBF7] flex items-center justify-center text-[10px] text-white font-bold">
                                        {cartCount}
                                    </span>
                                )}
                            </Button>
                        </Link>

                        <div className="h-6 w-px bg-emerald-900/10 mx-2"></div>

                        {isAuthenticated && user ? (
                            <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                    <div className="flex items-center space-x-2 pl-2 cursor-pointer hover:opacity-80 transition-opacity outline-none">
                                        <Avatar className="h-8 w-8 border border-emerald-200">
                                            {/* Only show image if it's not the default pravatar */}
                                            {user.avatar && !user.avatar.includes('pravatar.cc') && (
                                                <AvatarImage src={user.avatar} alt={user.name} />
                                            )}
                                            <AvatarFallback className="bg-emerald-100 text-emerald-800">{user.name.charAt(0)}</AvatarFallback>
                                        </Avatar>
                                        <span className="text-sm font-medium text-emerald-900 max-w-[100px] truncate">{user.name}</span>
                                    </div>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end" className="w-56">
                                    <DropdownMenuLabel>Akun Saya</DropdownMenuLabel>
                                    <DropdownMenuSeparator />
                                    {(user.role === 'ADMIN' || user.role === 'SUPER_ADMIN') && (
                                        <DropdownMenuItem asChild>
                                            <Link href="/admin">
                                                <Settings className="mr-2 h-4 w-4" />
                                                <span>Dashboard Admin</span>
                                            </Link>
                                        </DropdownMenuItem>
                                    )}
                                    <DropdownMenuItem asChild>
                                        <Link href="/profile">
                                            <User className="mr-2 h-4 w-4" />
                                            <span>Profil</span>
                                        </Link>
                                    </DropdownMenuItem>
                                    <DropdownMenuItem onClick={handleLogout} className="text-red-600 focus:text-red-600">
                                        <LogOut className="mr-2 h-4 w-4" />
                                        <span>Keluar</span>
                                    </DropdownMenuItem>
                                </DropdownMenuContent>
                            </DropdownMenu>
                        ) : (
                            <div className="flex items-center space-x-2">
                                <Link href="/auth/login">
                                    <Button variant="ghost" className="text-emerald-900 hover:bg-emerald-50 hover:text-emerald-950">
                                        Masuk
                                    </Button>
                                </Link>
                                <Link href="/auth/register">
                                    <Button className="bg-emerald-900 hover:bg-emerald-800 text-white rounded-full">
                                        Daftar
                                    </Button>
                                </Link>
                            </div>
                        )}
                    </div>

                    {/* Mobile Menu Button */}
                    <div className="md:hidden flex items-center gap-2">
                        {isAuthenticated && user && (
                            <div className="w-8 h-8 rounded-full bg-emerald-100 border border-emerald-200 overflow-hidden relative flex items-center justify-center">
                                <span className="text-emerald-800 font-bold text-sm">{user.name.charAt(0)}</span>
                            </div>
                        )}
                        <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                            className="text-emerald-900"
                        >
                            {isMobileMenuOpen ? <X /> : <Menu />}
                        </Button>
                    </div>
                </div>
            </div>

            {/* Mobile Menu */}
            {
                isMobileMenuOpen && (
                    <div className="md:hidden border-t border-emerald-100 bg-[#FDFBF7]">
                        <div className="px-4 py-4 space-y-4">
                            <input
                                type="text"
                                placeholder="Cari buku..."
                                className="w-full bg-emerald-900/5 border-none rounded-xl py-3 px-4 text-sm text-emerald-900 placeholder:text-emerald-800/40 outline-none"
                            />
                            {isAuthenticated ? (
                                <div className="space-y-2">
                                    <div className="flex items-center gap-3 p-2 bg-emerald-50 rounded-lg">
                                        <User className="w-5 h-5 text-emerald-800" />
                                        <span className="font-medium text-emerald-900">{user?.name}</span>
                                    </div>
                                    <Link href="/wishlist">
                                        <Button variant="ghost" className="w-full justify-start text-emerald-800">
                                            <Heart className="mr-2 w-4 h-4" /> Wishlist ({wishlistCount})
                                        </Button>
                                    </Link>
                                    <Button variant="ghost" onClick={handleLogout} className="w-full justify-start text-red-600 hover:text-red-700 hover:bg-red-50">
                                        <LogOut className="mr-2 w-4 h-4" /> Keluar
                                    </Button>
                                </div>
                            ) : (
                                <div className="flex flex-col gap-2">
                                    <Link href="/auth/login">
                                        <Button variant="outline" className="w-full border-emerald-200 text-emerald-900">Masuk</Button>
                                    </Link>
                                    <Link href="/auth/register">
                                        <Button className="w-full bg-emerald-900 text-white">Daftar</Button>
                                    </Link>
                                </div>
                            )}
                        </div>
                    </div>
                )
            }
        </nav >
    );
}
