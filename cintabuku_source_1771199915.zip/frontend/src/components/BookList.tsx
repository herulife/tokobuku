'use client';

import Image from 'next/image';
import { Star, ShoppingCart, Heart, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import Link from 'next/link';
import { getImageUrl } from '@/lib/image-utils';
import AddToCartButton from '@/components/AddToCartButton';

interface Book {
    id: string;
    title: string;
    author: string;
    price: number;
    rating?: number;
    coverImage: string;
    slug: string;
    stock: number;
    discountPrice?: number | null;
    category?: { name: string };
}

export default function BookList({ books, title, subtitle }: { books: Book[], title: string, subtitle?: string }) {
    if (!books || books.length === 0) return null;

    return (
        <section className="py-16 px-4 sm:px-6 lg:px-8 bg-[#FDFBF7]">
            <div className="max-w-7xl mx-auto">
                {/* Header */}
                <div className="flex justify-between items-end mb-10">
                    <div>
                        <h2 className="text-3xl font-serif font-bold text-stone-800">{title}</h2>
                        {subtitle && <p className="text-stone-500 mt-2">{subtitle}</p>}
                    </div>
                    <Link href="/books">
                        <Button variant="link" className="text-emerald-700 hover:text-emerald-900 group">
                            Lihat Semua <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
                        </Button>
                    </Link>
                </div>

                {/* Grid */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-8">
                    {books.map((book) => (
                        <div key={book.id} className="group bg-white rounded-2xl p-4 transition-all duration-300 hover:shadow-xl hover:-translate-y-1 border border-stone-100/50 hover:border-emerald-100 flex flex-col">
                            {/* Cover */}
                            <div className="relative aspect-[2/3] w-full mb-4 rounded-xl overflow-hidden shadow-sm group-hover:shadow-md transition-shadow bg-stone-100">
                                <Link href={`/books/${book.slug}`} className="block w-full h-full">
                                    <Image
                                        src={getImageUrl(book.coverImage)}
                                        alt={book.title}
                                        fill
                                        className="object-cover transition-transform duration-500 group-hover:scale-105"
                                        sizes="(max-width: 768px) 50vw, 25vw"
                                    />
                                </Link>

                                {/* Badges */}
                                {/* Simple logic for demo, real app might use a field */}
                                {book.stock < 5 && book.stock > 0 && (
                                    <div className="absolute top-3 left-3 pointer-events-none">
                                        <Badge className="bg-orange-500 hover:bg-orange-600 text-white border-none shadow-sm">Terbatas</Badge>
                                    </div>
                                )}

                                {book.discountPrice && (
                                    <div className="absolute top-3 left-3 pointer-events-none">
                                        <Badge className="bg-red-500 hover:bg-red-600 text-white border-none shadow-sm">Promo</Badge>
                                    </div>
                                )}

                                {/* Quick Actions Overlay */}
                                <div className="absolute top-3 right-3 flex flex-col gap-2 opacity-0 group-hover:opacity-100 transition-opacity translate-x-2 group-hover:translate-x-0 duration-300 z-10 w-auto">
                                    <Button size="icon" className="h-8 w-8 rounded-full bg-white/90 backdrop-blur text-rose-500 hover:bg-rose-50 shadow-sm">
                                        <Heart className="w-4 h-4 fill-current" />
                                    </Button>
                                </div>
                            </div>

                            {/* Info */}
                            <div className="flex flex-col flex-1">
                                <div className="text-xs text-emerald-700 font-medium mb-1 uppercase tracking-wider">{book.category?.name || 'Umum'}</div>
                                <h3 className="font-serif font-bold text-stone-800 text-lg leading-tight mb-1 line-clamp-2 group-hover:text-emerald-800 transition-colors">
                                    <Link href={`/books/${book.slug}`}>
                                        {book.title}
                                    </Link>
                                </h3>
                                <p className="text-sm text-stone-500 mb-3">{book.author}</p>

                                <div className="mt-auto pt-3 border-t border-stone-100 flex items-center justify-between">
                                    <div>
                                        <p className="font-bold text-stone-900">
                                            {new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0 }).format(book.discountPrice || book.price)}
                                        </p>
                                        <div className="flex items-center gap-1 mt-0.5">
                                            <Star className="w-3 h-3 text-amber-400 fill-current" />
                                            <span className="text-xs text-stone-400 font-medium">{book.rating || 4.8}</span>
                                        </div>
                                    </div>
                                    <AddToCartButton
                                        book={book}
                                        variant="ghost"
                                        size="icon"
                                        showText={false}
                                        className="rounded-xl bg-emerald-50 text-emerald-700 hover:bg-emerald-600 hover:text-white transition-colors"
                                    />
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </section>
    );
}
