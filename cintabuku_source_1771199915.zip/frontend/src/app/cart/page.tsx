'use client';

import Link from 'next/link';
import { useCartStore } from '@/store/useCartStore';
import { Button } from '@/components/ui/button';
import { formatCurrency } from '@/lib/utils';
import { Trash2, Minus, Plus, ArrowRight, ShoppingBag } from 'lucide-react';
import { useAuthStore } from '@/store/useAuthStore';
import { useEffect, useState } from 'react';
import { getImageUrl } from '@/lib/image-utils';

export default function CartPage() {
    const { items, removeItem, updateQuantity, totalPrice, clearCart } = useCartStore();
    const { isAuthenticated } = useAuthStore();
    const [mounted, setMounted] = useState(false);

    useEffect(() => {
        setMounted(true);
    }, []);

    if (!mounted) return null;

    if (items.length === 0) {
        return (
            <div className="flex flex-col items-center justify-center min-h-[60vh] space-y-6 text-center">
                <div className="bg-emerald-50 p-6 rounded-full text-emerald-600">
                    <ShoppingBag size={64} />
                </div>
                <div>
                    <h2 className="text-2xl font-bold text-slate-900">Keranjang Belanja Kosong</h2>
                    <p className="text-slate-500 mt-2">Wah, keranjangmu masih kosong nih. Yuk cari buku favoritmu!</p>
                </div>
                <Link href="/books">
                    <Button size="lg" className="bg-emerald-600 hover:bg-emerald-700">
                        Mulai Belanja <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                </Link>
            </div>
        );
    }

    return (
        <div className="space-y-8">
            <h1 className="text-3xl font-bold text-slate-900">Keranjang Belanja ({items.length} Item)</h1>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                {/* Cart Items List */}
                <div className="lg:col-span-2 space-y-4">
                    {items.map((item) => (
                        <div key={item.bookId} className="bg-white p-4 rounded-xl border border-slate-100 flex gap-4 shadow-sm">
                            <div className="w-24 h-32 flex-shrink-0 bg-slate-100 rounded-md overflow-hidden">
                                <img src={getImageUrl(item.book.coverImage)} alt={item.book.title} className="w-full h-full object-cover" />
                            </div>

                            <div className="flex-1 flex flex-col justify-between">
                                <div>
                                    <Link href={`/books/${item.book.slug}`} className="font-bold text-slate-900 line-clamp-2 hover:text-emerald-600">
                                        {item.book.title}
                                    </Link>
                                    <p className="text-sm text-slate-500">{item.book.author}</p>
                                </div>

                                <div className="flex justify-between items-end">
                                    <div className="font-bold text-slate-900">
                                        {formatCurrency(item.book.discountPrice || item.book.price)}
                                    </div>

                                    <div className="flex items-center space-x-3 bg-slate-50 rounded-lg p-1 border border-slate-200">
                                        <button
                                            onClick={() => updateQuantity(item.bookId, item.quantity - 1)}
                                            className="p-1 hover:bg-white rounded-md transition-colors disabled:opacity-50"
                                            disabled={item.quantity <= 1}
                                        >
                                            <Minus size={14} />
                                        </button>
                                        <span className="text-sm font-medium w-4 text-center">{item.quantity}</span>
                                        <button
                                            onClick={() => updateQuantity(item.bookId, item.quantity + 1)}
                                            className="p-1 hover:bg-white rounded-md transition-colors"
                                        >
                                            <Plus size={14} />
                                        </button>
                                    </div>
                                </div>
                            </div>

                            <button
                                onClick={() => removeItem(item.bookId)}
                                className="text-slate-400 hover:text-red-500 self-start p-1"
                            >
                                <Trash2 size={18} />
                            </button>
                        </div>
                    ))}

                    <Button variant="outline" className="text-red-500 hover:bg-red-50 border-red-200" onClick={clearCart}>
                        Kosongkan Keranjang
                    </Button>
                </div>

                {/* Order Summary */}
                <div className="lg:col-span-1">
                    <div className="bg-white p-6 rounded-xl border border-slate-100 shadow-lg sticky top-24">
                        <h3 className="font-bold text-slate-900 mb-6">Ringkasan Belanja</h3>

                        <div className="space-y-3 mb-6">
                            <div className="flex justify-between text-slate-600">
                                <span>Total Harga ({items.reduce((acc, item) => acc + item.quantity, 0)} barang)</span>
                                <span>{formatCurrency(totalPrice())}</span>
                            </div>
                            <div className="flex justify-between text-slate-600">
                                <span>Diskon</span>
                                <span className="text-green-600">-Rp 0</span>
                            </div>
                        </div>

                        <div className="border-t border-slate-100 pt-4 mb-6">
                            <div className="flex justify-between font-bold text-lg text-slate-900">
                                <span>Total Belanja</span>
                                <span>{formatCurrency(totalPrice())}</span>
                            </div>
                        </div>

                        {isAuthenticated ? (
                            <Link href="/checkout">
                                <Button className="w-full bg-emerald-600 hover:bg-emerald-700 py-6 text-lg font-bold shadow-emerald-200 shadow-lg">
                                    Beli Sekarang
                                </Button>
                            </Link>
                        ) : (
                            <Link href="/auth/login">
                                <Button className="w-full bg-slate-900 hover:bg-slate-800 py-6">
                                    Masuk untuk Membeli
                                </Button>
                            </Link>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
}
