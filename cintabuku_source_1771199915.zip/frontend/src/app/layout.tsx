import type { Metadata } from 'next';
import { Inter, Playfair_Display } from 'next/font/google';
import './globals.css';
import { cn } from '@/lib/utils';
import "@fortawesome/fontawesome-svg-core/styles.css";
import { config } from "@fortawesome/fontawesome-svg-core";

config.autoAddCss = false;

const inter = Inter({ subsets: ['latin'] });
const playfair = Playfair_Display({ subsets: ['latin'], variable: '--font-playfair' });

export const metadata: Metadata = {
  title: 'Koalisi Cinta Buku',
  description: 'Toko buku online terpercaya dengan koleksi terbaik.',
};

import ClientToaster from '@/components/ClientToaster';

import ClientLayout from './ClientLayout';

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="id">
      <body className={cn(inter.className, playfair.variable, "min-h-screen flex flex-col bg-slate-50 relative")}>
        <ClientLayout>
          {children}
        </ClientLayout>
        <ClientToaster />
      </body>
    </html>
  );
}
