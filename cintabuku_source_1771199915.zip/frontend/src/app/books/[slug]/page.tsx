import { notFound } from 'next/navigation';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import RatingStars from '@/components/ui/RatingStars';
import { formatCurrency } from '@/lib/utils';
import { Check, Heart, Share2, Twitter, Facebook, Instagram, Linkedin } from 'lucide-react';
import BookCard from '@/components/BookCard';
import { getImageUrl } from '@/lib/image-utils';
import AddToCartButton from '@/components/AddToCartButton';
import ShareButtons from '@/components/ShareButtons';
import ProductTabs from './ProductTabs';

async function getBook(slug: string) {
    const apiUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000/api/v1';
    try {
        const res = await fetch(`${apiUrl}/books/slug/${slug}`, {
            cache: 'no-store',
        });
        if (!res.ok) return null;
        return res.json();
    } catch (error) {
        return null;
    }
}

async function getRelatedBooks(categoryId: string) {
    const apiUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000/api/v1';
    try {
        const res = await fetch(`${apiUrl}/books?category=${categoryId}&limit=4`, {
            cache: 'no-store',
        });
        if (!res.ok) return { data: { books: [] } };
        return res.json();
    } catch (error) {
        return { data: { books: [] } };
    }
}

export default async function BookDetail(props: { params: Promise<{ slug: string }> }) {
    const params = await props.params;
    const { slug } = params;
    const bookData = await getBook(slug);

    if (!bookData || !bookData.data || !bookData.data.book) {
        notFound();
    }

    const book = bookData.data.book;
    const relatedBooksData = await getRelatedBooks(book.category.id);
    const relatedBooks = relatedBooksData.data?.books?.filter((b: any) => b.id !== book.id) || [];

    return (
        <div className="min-h-screen bg-[#FDFBF7]">
            <div className="container mx-auto px-4 py-12 space-y-16">
                {/* Breadcrumb */}
                <div className="flex items-center space-x-2 text-sm text-slate-500">
                    <Link href="/" className="hover:text-emerald-700 transition-colors">Home</Link>
                    <span>/</span>
                    <Link href="/books" className="hover:text-emerald-700 transition-colors">Books</Link>
                    <span>/</span>
                    <span className="text-slate-900 font-medium truncate max-w-[200px]">{book.title}</span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-12 gap-12 lg:gap-16">
                    {/* Gallery - 5 Columns */}
                    <div className="md:col-span-5 space-y-6">
                        <div className="aspect-[4/5] rounded-xl overflow-hidden bg-white shadow-sm border border-slate-100 relative">
                            {book.discountPrice && (
                                <span className="absolute top-4 left-4 bg-rose-500 text-white text-xs font-bold px-3 py-1.5 rounded-full z-10 tracking-wide shadow-sm">
                                    {Math.round(((book.price - book.discountPrice) / book.price) * 100)}% OFF
                                </span>
                            )}
                            <img
                                src={getImageUrl(book.coverImage)}
                                alt={book.title}
                                className="w-full h-full object-cover transform hover:scale-105 transition-transform duration-700 ease-out"
                            />
                        </div>
                        {/* Thumbnails placeholder */}
                        <div className="grid grid-cols-4 gap-4">
                            <div className="aspect-square rounded-lg border-2 border-emerald-600/20 p-1 cursor-pointer bg-white">
                                <img src={getImageUrl(book.coverImage)} className="w-full h-full object-cover rounded-md" />
                            </div>
                        </div>
                    </div>

                    {/* Info - 7 Columns */}
                    <div className="md:col-span-7 space-y-8">
                        <div>
                            <div className="flex items-center space-x-3 mb-4">
                                <Link href={`/books?category=${book.category.id}`} className="px-3 py-1 bg-emerald-50 text-emerald-700 rounded-full text-xs font-bold uppercase tracking-wider hover:bg-emerald-100 transition-colors">
                                    {book.category.name}
                                </Link>
                                <div className="flex items-center text-yellow-500 space-x-1 bg-yellow-50 px-2 py-0.5 rounded-full">
                                    <RatingStars rating={book.rating || 4.5} size={14} />
                                    <span className="text-slate-900 text-xs font-bold ml-1">{book.rating || 4.5}</span>
                                </div>
                            </div>

                            <h1 className="text-4xl md:text-5xl font-serif font-bold text-slate-900 leading-tight mb-4">
                                {book.title}
                            </h1>

                            <p className="text-lg text-slate-600 font-medium flex items-center">
                                Penulis: <span className="text-slate-900 ml-2 font-serif">{book.author}</span>
                            </p>
                        </div>

                        <div className="border-t border-slate-200/60 pt-6 pb-6 border-b">
                            <div className="flex items-baseline space-x-4 mb-6">
                                {book.discountPrice ? (
                                    <>
                                        <span className="text-4xl font-bold text-slate-900 font-serif">
                                            {formatCurrency(book.discountPrice)}
                                        </span>
                                        <span className="text-xl text-slate-400 line-through font-serif decoration-slate-300">
                                            {formatCurrency(book.price)}
                                        </span>
                                    </>
                                ) : (
                                    <span className="text-4xl font-bold text-slate-900 font-serif">
                                        {formatCurrency(book.price)}
                                    </span>
                                )}
                            </div>

                            <p className="text-slate-600 leading-relaxed text-lg font-light">
                                {book.description ? book.description.substring(0, 200) + '...' : 'Deskripsi buku belum tersedia.'}
                            </p>
                        </div>

                        {/* Actions */}
                        <div className="space-y-6 max-w-lg">
                            <div className="flex items-center space-x-3">
                                <span className="font-medium text-slate-900">Ketersediaan:</span>
                                {book.stock > 0 ? (
                                    <span className="bg-emerald-100 text-emerald-800 text-xs px-2.5 py-0.5 rounded-full font-bold flex items-center">
                                        <Check size={12} className="mr-1" /> Stok Tersedia ({book.stock})
                                    </span>
                                ) : (
                                    <span className="bg-red-100 text-red-800 text-xs px-2.5 py-0.5 rounded-full font-bold">
                                        Stok Habis
                                    </span>
                                )}
                            </div>

                            <div className="grid grid-cols-1 gap-4">
                                <AddToCartButton
                                    book={book}
                                    className="w-full shadow-lg shadow-emerald-900/10"
                                    size="lg"
                                    variant="full"
                                />
                            </div>

                            <div className="flex items-center justify-between pt-4">
                                <Button variant="ghost" size="sm" className="text-slate-500 hover:text-rose-600 hover:bg-rose-50 transition-colors">
                                    <Heart className="h-4 w-4 mr-2" /> Wishlist
                                </Button>
                                <ShareButtons
                                    url={`${process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000'}/books/${book.slug}`}
                                    title={`Jual Buku ${book.title} - Koalisi Cinta Buku`}
                                    description={`Dapatkan buku ${book.title} karya ${book.author} di Koalisi Cinta Buku.`}
                                />
                            </div>
                        </div>
                    </div>
                </div>

                {/* Product Tabs (Description, details, reviews) */}
                <div className="bg-white rounded-2xl shadow-sm border border-slate-100 p-8 md:p-12">
                    <ProductTabs book={book} />
                </div>

                {/* Related Books */}
                {relatedBooks.length > 0 && (
                    <div className="pt-8">
                        <div className="flex items-center justify-between mb-8">
                            <h2 className="text-3xl font-serif font-bold text-slate-900">Buku Sejenis</h2>
                            <Link href={`/books?category=${book.category.id}`} className="text-emerald-700 font-medium hover:underline decoration-2 underline-offset-4">
                                Lihat Semua
                            </Link>
                        </div>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
                            {relatedBooks.map((b: any) => (
                                <BookCard key={b.id} book={b} />
                            ))}
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
}
