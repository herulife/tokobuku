'use client';

import { useState } from 'react';
import { ReviewList } from '@/components/reviews/ReviewList';
import { cn } from '@/lib/utils';

interface ProductTabsProps {
    book: any;
}

export default function ProductTabs({ book }: ProductTabsProps) {
    const [activeTab, setActiveTab] = useState<'deskripsi' | 'informasi' | 'ulasan'>('deskripsi');

    return (
        <div className="mt-8">
            <div className="border-b border-slate-100 mb-8">
                <div className="flex space-x-12">
                    <button
                        onClick={() => setActiveTab('deskripsi')}
                        className={cn(
                            "pb-4 text-base font-serif font-medium transition-all duration-300 relative",
                            activeTab === 'deskripsi'
                                ? "text-slate-900"
                                : "text-slate-400 hover:text-slate-600"
                        )}
                    >
                        Deskripsi
                        {activeTab === 'deskripsi' && (
                            <span className="absolute bottom-0 left-0 w-full h-0.5 bg-slate-900 rounded-full" />
                        )}
                    </button>
                    <button
                        onClick={() => setActiveTab('informasi')}
                        className={cn(
                            "pb-4 text-base font-serif font-medium transition-all duration-300 relative",
                            activeTab === 'informasi'
                                ? "text-slate-900"
                                : "text-slate-400 hover:text-slate-600"
                        )}
                    >
                        Informasi Tambahan
                        {activeTab === 'informasi' && (
                            <span className="absolute bottom-0 left-0 w-full h-0.5 bg-slate-900 rounded-full" />
                        )}
                    </button>
                    <button
                        onClick={() => setActiveTab('ulasan')}
                        className={cn(
                            "pb-4 text-base font-serif font-medium transition-all duration-300 relative",
                            activeTab === 'ulasan'
                                ? "text-slate-900"
                                : "text-slate-400 hover:text-slate-600"
                        )}
                    >
                        Ulasan ({book.totalRating || 0})
                        {activeTab === 'ulasan' && (
                            <span className="absolute bottom-0 left-0 w-full h-0.5 bg-slate-900 rounded-full" />
                        )}
                    </button>
                </div>
            </div>

            <div className="py-2 animate-in fade-in slide-in-from-bottom-2 duration-500">
                {activeTab === 'deskripsi' && (
                    <div className="prose prose-slate max-w-none">
                        <p className="text-slate-600 leading-relaxed whitespace-pre-line text-lg font-light">
                            {book.description}
                        </p>
                    </div>
                )}

                {activeTab === 'informasi' && (
                    <div className="overflow-x-auto">
                        <table className="w-full text-sm text-left">
                            <tbody>
                                <tr className="border-b border-slate-100/50">
                                    <td className="py-4 font-bold text-slate-900 w-1/3">Penulis</td>
                                    <td className="py-4 text-slate-600 font-serif text-lg">{book.author}</td>
                                </tr>
                                <tr className="border-b border-slate-100/50">
                                    <td className="py-4 font-bold text-slate-900">Penerbit</td>
                                    <td className="py-4 text-slate-600">{book.publisher || '-'}</td>
                                </tr>
                                <tr className="border-b border-slate-100/50">
                                    <td className="py-4 font-bold text-slate-900">ISBN</td>
                                    <td className="py-4 text-slate-600 font-mono text-xs">{book.isbn || '-'}</td>
                                </tr>
                                <tr className="border-b border-slate-100/50">
                                    <td className="py-4 font-bold text-slate-900">Halaman</td>
                                    <td className="py-4 text-slate-600">300+ (Estimasi)</td>
                                </tr>
                                <tr className="border-b border-slate-100/50">
                                    <td className="py-4 font-bold text-slate-900">Bahasa</td>
                                    <td className="py-4 text-slate-600">Indonesia</td>
                                </tr>
                                <tr className="border-b border-slate-100/50">
                                    <td className="py-4 font-bold text-slate-900">Kategori</td>
                                    <td className="py-4 text-slate-600">{book.category?.name || '-'}</td>
                                </tr>
                                <tr>
                                    <td className="py-4 font-bold text-slate-900">Stok</td>
                                    <td className="py-4 text-slate-600">{book.stock} unit</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                )}

                {activeTab === 'ulasan' && (
                    <ReviewList bookId={book.id} />
                )}
            </div>
        </div>
    );
}
