import { Suspense } from 'react';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import BookCard from '@/components/BookCard';
import { Search, Filter, SlidersHorizontal } from 'lucide-react';

async function getBooks(searchParams: { [key: string]: string | string[] | undefined }) {
    try {
        const params = new URLSearchParams();
        if (searchParams.search) params.append('search', searchParams.search as string);
        if (searchParams.category) params.append('category', searchParams.category as string);
        if (searchParams.sort) params.append('sort', searchParams.sort as string);
        if (searchParams.minPrice) params.append('minPrice', searchParams.minPrice as string);
        if (searchParams.maxPrice) params.append('maxPrice', searchParams.maxPrice as string);
        params.append('limit', '12');
        params.append('inStock', 'true');

        const apiUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000/api/v1';
        const res = await fetch(`${apiUrl}/books?${params.toString()}`, {
            cache: 'no-store',
        });

        if (!res.ok) return { data: { books: [], total: 0 } };
        return res.json();
    } catch (error) {
        return { data: { books: [], total: 0 } };
    }
}

async function getCategories() {
    // This should fetch categories from API, for now hardcode or use existing
    // Since we didn't explicitly make a category API, we'll use hardcoded for filters or fetch if available
    // Assuming backend has categories, but let's hardcode for simplicity of this artifact if API endpoint not ready
    // Actually we do have categories in DB.
    // Let's assume we can filter by these slugs
    return [
        { name: 'Semua', slug: '' },
        { name: 'Fiksi', slug: 'fiksi' },
        { name: 'Nonfiksi', slug: 'nonfiksi' },
        { name: 'Anak', slug: 'anak' },
        { name: 'Bisnis', slug: 'bisnis' },
        { name: 'Self Improvement', slug: 'self-improvement' },
        { name: 'Komik', slug: 'komik' },
    ];
}

export default async function CatalogPage(props: {
    searchParams: Promise<{ [key: string]: string | string[] | undefined }>;
}) {
    const searchParams = await props.searchParams;
    const booksData = await getBooks(searchParams);
    const categories = await getCategories();

    const books = booksData.data?.books || [];
    const total = booksData.data?.total || 0;

    return (
        <div className="space-y-8">
            {/* Header & Filter */}
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <div>
                    <h1 className="text-3xl font-bold text-slate-900">Katalog Buku</h1>
                    <p className="text-slate-500">Menampilkan {books.length} dari {total} buku</p>
                </div>

                <div className="flex items-center space-x-2 w-full md:w-auto">
                    <form className="relative flex-1 md:w-80">
                        <Input
                            name="search"
                            placeholder="Cari judul, penulis..."
                            defaultValue={searchParams.search as string}
                            className="pl-10"
                        />
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                    </form>
                    {/* Simple sort dropdown could go here */}
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
                {/* Sidebar Filters */}
                <div className="hidden lg:block space-y-8">
                    <div className="bg-white p-6 rounded-xl border border-slate-100 shadow-sm">
                        <h3 className="font-bold text-slate-900 mb-4 flex items-center">
                            <Filter className="mr-2 h-4 w-4" /> Kategori
                        </h3>
                        <div className="space-y-2">
                            {categories.map((cat) => (
                                <Link
                                    key={cat.slug}
                                    href={cat.slug ? `/books?category=${cat.slug}` : '/books'}
                                    className={`block text-sm px-3 py-2 rounded-md transition-colors ${(searchParams.category === cat.slug || (!searchParams.category && !cat.slug))
                                        ? 'bg-emerald-50 text-emerald-600 font-medium'
                                        : 'text-slate-600 hover:bg-slate-50'
                                        }`}
                                >
                                    {cat.name}
                                </Link>
                            ))}
                        </div>
                    </div>

                    <div className="bg-white p-6 rounded-xl border border-slate-100 shadow-sm">
                        <h3 className="font-bold text-slate-900 mb-4">Urutkan</h3>
                        <div className="space-y-2">
                            {[
                                { label: 'Paling Baru', value: 'newest' },
                                { label: 'Terlaris', value: 'best-seller' },
                                { label: 'Harga Terendah', value: 'price:asc' },
                                { label: 'Harga Tertinggi', value: 'price:desc' },
                                { label: 'Rating Tertinggi', value: 'rating:desc' },
                            ].map((sort) => (
                                <Link
                                    key={sort.value}
                                    href={`?${new URLSearchParams({ ...searchParams as any, sort: sort.value }).toString()}`}
                                    className={`block text-sm px-3 py-2 rounded-md transition-colors ${searchParams.sort === sort.value
                                        ? 'bg-emerald-50 text-emerald-600 font-medium'
                                        : 'text-slate-600 hover:bg-slate-50'
                                        }`}
                                >
                                    {sort.label}
                                </Link>
                            ))}
                        </div>
                    </div>
                </div>

                {/* Book Grid */}
                <div className="lg:col-span-3">
                    {books.length > 0 ? (
                        <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
                            {books.map((book: any) => (
                                <BookCard key={book.id} book={book} />
                            ))}
                        </div>
                    ) : (
                        <div className="text-center py-20 bg-slate-50 rounded-xl border border-dashed border-slate-200">
                            <BookOpen size={48} className="mx-auto text-slate-300 mb-4" />
                            <h3 className="text-lg font-bold text-slate-900">Tidak ada buku ditemukan</h3>
                            <p className="text-slate-500">Coba ganti kata kunci atau filter pencarian Anda.</p>
                            <Link href="/books">
                                <Button variant="link" className="mt-2 text-emerald-600">Reset Filter</Button>
                            </Link>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
}

function BookOpen({ size, className }: { size?: number, className?: string }) {
    return (
        <svg xmlns="http://www.w3.org/2000/svg" width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={className}>
            <path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z" /><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z" />
        </svg>
    )
}
