'use client';

import { useEffect, useState, use } from 'react';
import { BookForm } from '@/components/admin/BookForm';
import { apiClient } from '@/lib/api-client';
import { Loader2, ArrowLeft } from 'lucide-react';
import Link from 'next/link';
import { Button } from '@/components/ui/button';

export default function BookEditorPage(props: { params: Promise<{ id: string }> }) {
    // Unwrap params using React.use() or await in async component
    // Since this is a client component, we use `use` or just treat it as a promise if Next 15
    // But `use` hook is preferred for unwrapping promises in render.
    // However, to be safe and compatible, let's use the standard `use` from react if available or `useEffect` unwrapping.
    const params = use(props.params);
    const { id } = params;

    const isNew = id === 'new';
    const [loading, setLoading] = useState(!isNew);
    const [book, setBook] = useState<any>(null);

    useEffect(() => {
        if (!isNew) {
            const fetchBook = async () => {
                try {
                    const res: any = await apiClient.get(`/books/${id}`);
                    setBook(res.data.book);
                } catch (error) {
                    console.error('Failed to fetch book', error);
                } finally {
                    setLoading(false);
                }
            };
            fetchBook();
        }
    }, [id, isNew]);

    if (loading) {
        return (
            <div className="flex justify-center items-center h-64">
                <Loader2 className="h-8 w-8 animate-spin text-emerald-600" />
            </div>
        );
    }

    return (
        <div className="space-y-6">
            <div className="flex items-center space-x-4">
                <Link href="/admin/books">
                    <Button variant="ghost" size="icon">
                        <ArrowLeft size={20} />
                    </Button>
                </Link>
                <h1 className="text-2xl font-bold text-slate-900">
                    {isNew ? 'Tambah Buku Baru' : 'Edit Buku'}
                </h1>
            </div>

            <BookForm isEdit={!isNew} initialData={book} />
        </div>
    );
}
