'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { apiClient } from '@/lib/api-client';
import { Plus, Pencil, Trash2, Search, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { formatCurrency } from '@/lib/utils';
import { getImageUrl } from '@/lib/image-utils';
import { toast } from 'sonner';

export default function AdminBooksPage() {
    const [books, setBooks] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);
    const [search, setSearch] = useState('');

    // Filter State
    const [categories, setCategories] = useState<any[]>([]);
    const [selectedCategory, setSelectedCategory] = useState('');

    // Pagination State
    const [page, setPage] = useState(1);
    const [totalPages, setTotalPages] = useState(1);
    const [totalBooks, setTotalBooks] = useState(0);
    const [limit, setLimit] = useState(10);

    // Selection State
    const [selectedIds, setSelectedIds] = useState<string[]>([]);
    const [isDeleting, setIsDeleting] = useState(false);

    const fetchCategories = async () => {
        try {
            const res: any = await apiClient.get('/categories');
            setCategories(res.data.categories);
        } catch (error) {
            console.error('Failed to fetch categories');
        }
    };

    const fetchBooks = async () => {
        setLoading(true);
        try {
            const queryParams = new URLSearchParams({
                page: page.toString(),
                limit: limit.toString(),
                search: search
            });

            if (selectedCategory) {
                queryParams.append('category', selectedCategory);
            }

            const res: any = await apiClient.get(`/books?${queryParams}`);

            setBooks(res.data.books);
            setTotalPages(res.totalPages);
            setTotalBooks(res.total);
            setPage(res.currentPage);
        } catch (error) {
            toast.error('Gagal memuat data buku');
            console.error(error);
        } finally {
            setLoading(false);
        }
    };

    // Initial load
    useEffect(() => {
        fetchCategories();
    }, []);

    // Initial fetch and updates
    useEffect(() => {
        fetchBooks();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [page, search, limit, selectedCategory]);

    // Reset page when filtering or searching
    useEffect(() => {
        setPage(1);
    }, [search, selectedCategory]);

    const handleDelete = async (id: string) => {
        if (!confirm('Apakah Anda yakin ingin menghapus buku ini?')) return;

        try {
            await apiClient.delete(`/books/${id}`);
            fetchBooks();
            toast.success('Buku berhasil dihapus');
        } catch (error) {
            toast.error('Gagal menghapus buku');
        }
    };

    const handleBulkDelete = async () => {
        if (selectedIds.length === 0) return;
        if (!confirm(`Hapus ${selectedIds.length} buku terpilih?`)) return;

        setIsDeleting(true);
        try {
            await apiClient.post('/books/bulk-delete', { ids: selectedIds });
            toast.success(`${selectedIds.length} buku berhasil dihapus`);
            setSelectedIds([]);
            fetchBooks();
        } catch (error: any) {
            toast.error(error.message || 'Gagal menghapus buku terpilih');
        } finally {
            setIsDeleting(false);
        }
    };

    const toggleSelectAll = () => {
        if (selectedIds.length === books.length) {
            setSelectedIds([]);
        } else {
            setSelectedIds(books.map(b => b.id));
        }
    };

    const toggleSelectOne = (id: string) => {
        if (selectedIds.includes(id)) {
            setSelectedIds(selectedIds.filter(selectedId => selectedId !== id));
        } else {
            setSelectedIds([...selectedIds, id]);
        }
    };

    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                <h1 className="text-2xl font-bold text-slate-900 flex items-center">
                    Manajemen Buku
                    {totalBooks > 0 && (
                        <span className="ml-3 text-sm font-normal text-emerald-700 bg-emerald-100 px-3 py-1 rounded-full">
                            Total: {totalBooks}
                        </span>
                    )}
                </h1>

                <div className="flex gap-2">
                    {selectedIds.length > 0 && (
                        <Button
                            variant="destructive"
                            onClick={handleBulkDelete}
                            disabled={isDeleting}
                        >
                            {isDeleting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Trash2 className="mr-2 h-4 w-4" />}
                            Hapus ({selectedIds.length})
                        </Button>
                    )}
                    <Link href="/admin/books/new">
                        <Button className="bg-emerald-600 hover:bg-emerald-700">
                            <Plus className="mr-2 h-4 w-4" /> Tambah Buku
                        </Button>
                    </Link>
                </div>
            </div>

            <div className="flex flex-col md:flex-row justify-between items-center bg-white p-2 rounded-lg border border-slate-200 shadow-sm gap-2">
                <div className="flex items-center gap-2 flex-1 w-full">
                    <div className="flex items-center space-x-2 flex-1 relative max-w-md">
                        <Search className="h-5 w-5 text-slate-400 ml-2 absolute pointer-events-none" />
                        <Input
                            placeholder="Cari buku..."
                            className="pl-9 border-none focus-visible:ring-0 shadow-none bg-slate-50"
                            value={search}
                            onChange={(e) => setSearch(e.target.value)}
                        />
                    </div>

                    <div className="h-8 w-[1px] bg-slate-200 hidden md:block"></div>

                    <select
                        className="bg-transparent text-sm font-medium text-slate-700 p-2 border-none focus:ring-0 outline-none cursor-pointer max-w-[200px]"
                        value={selectedCategory}
                        onChange={(e) => setSelectedCategory(e.target.value)}
                    >
                        <option value="">Semua Kategori</option>
                        {categories.map((cat) => (
                            <option key={cat.id} value={cat.slug}>{cat.name}</option>
                        ))}
                    </select>
                </div>

                <div className="flex items-center px-4 border-l border-slate-100 w-full md:w-auto mt-2 md:mt-0 justify-end">
                    <span className="text-sm text-slate-500 mr-2 whitespace-nowrap">Baris per halaman:</span>
                    <select
                        className="text-sm border-none focus:ring-0 bg-transparent text-slate-700 font-medium cursor-pointer outline-none"
                        value={limit}
                        onChange={(e) => {
                            setLimit(Number(e.target.value));
                        }}
                    >
                        <option value="10">10</option>
                        <option value="25">25</option>
                        <option value="50">50</option>
                        <option value="100">100</option>
                    </select>
                </div>
            </div>

            <div className="bg-white rounded-xl border border-slate-100 shadow-sm overflow-hidden">
                <table className="w-full text-left text-sm">
                    <thead className="bg-slate-50 border-b border-slate-100">
                        <tr>
                            <th className="px-6 py-4 w-10">
                                <input
                                    type="checkbox"
                                    className="rounded border-slate-300 text-emerald-600 focus:ring-emerald-500"
                                    checked={books.length > 0 && selectedIds.length === books.length}
                                    onChange={toggleSelectAll}
                                />
                            </th>
                            <th className="px-6 py-4 font-semibold text-slate-700">Cover</th>
                            <th className="px-6 py-4 font-semibold text-slate-700">Judul</th>
                            <th className="px-6 py-4 font-semibold text-slate-700">Kategori</th>
                            <th className="px-6 py-4 font-semibold text-slate-700">Harga</th>
                            <th className="px-6 py-4 font-semibold text-slate-700">Stok</th>
                            <th className="px-6 py-4 font-semibold text-slate-700">Aksi</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                        {loading ? (
                            <tr>
                                <td colSpan={7} className="px-6 py-12 text-center text-slate-500">
                                    <Loader2 className="mx-auto h-6 w-6 animate-spin text-emerald-600 mb-2" />
                                    Loading...
                                </td>
                            </tr>
                        ) : books.length === 0 ? (
                            <tr>
                                <td colSpan={7} className="px-6 py-12 text-center text-slate-500">
                                    Tidak ada buku ditemukan.
                                </td>
                            </tr>
                        ) : (
                            books.map((book) => (
                                <tr key={book.id} className={`hover:bg-slate-50 transition-colors ${selectedIds.includes(book.id) ? 'bg-emerald-50/50' : ''}`}>
                                    <td className="px-6 py-3">
                                        <input
                                            type="checkbox"
                                            className="rounded border-slate-300 text-emerald-600 focus:ring-emerald-500"
                                            checked={selectedIds.includes(book.id)}
                                            onChange={() => toggleSelectOne(book.id)}
                                        />
                                    </td>
                                    <td className="px-6 py-3">
                                        {/* eslint-disable-next-line @next/next/no-img-element */}
                                        <img src={getImageUrl(book.coverImage)} alt={book.title} className="h-12 w-8 object-cover rounded bg-slate-200" />
                                    </td>
                                    <td className="px-6 py-3 font-medium text-slate-900 max-w-[200px] truncate" title={book.title}>
                                        {book.title}
                                    </td>
                                    <td className="px-6 py-3 text-slate-600">
                                        <span className="bg-slate-100 text-slate-600 px-2 py-1 rounded text-xs">
                                            {book.category?.name || 'Uncategorized'}
                                        </span>
                                    </td>
                                    <td className="px-6 py-3 text-slate-600">{formatCurrency(book.price)}</td>
                                    <td className="px-6 py-3 text-slate-600">
                                        <span className={`px-2 py-1 rounded-full text-xs font-bold ${book.stock > 10 ? 'bg-green-100 text-green-700' : book.stock > 0 ? 'bg-yellow-100 text-yellow-700' : 'bg-red-100 text-red-700'}`}>
                                            {book.stock}
                                        </span>
                                    </td>
                                    <td className="px-6 py-3">
                                        <div className="flex items-center space-x-2">
                                            <Link href={`/admin/books/${book.id}`}>
                                                <Button variant="ghost" size="icon" className="h-8 w-8 text-emerald-600 hover:text-emerald-700 hover:bg-emerald-50">
                                                    <Pencil size={16} />
                                                </Button>
                                            </Link>
                                            <Button
                                                variant="ghost"
                                                size="icon"
                                                className="h-8 w-8 text-red-600 hover:text-red-700 hover:bg-red-50"
                                                onClick={() => handleDelete(book.id)}
                                            >
                                                <Trash2 size={16} />
                                            </Button>
                                        </div>
                                    </td>
                                </tr>
                            ))
                        )}
                    </tbody>
                </table>
            </div>

            {/* Pagination Controls */}
            {!loading && totalPages > 1 && (
                <div className="flex justify-between items-center bg-white p-4 rounded-lg border border-slate-200">
                    <p className="text-sm text-slate-500">
                        Menampilkan {books.length > 0 ? (page - 1) * limit + 1 : 0} - {Math.min(page * limit, totalBooks)} dari {totalBooks} buku
                    </p>
                    <div className="flex space-x-2">
                        <Button
                            variant="outline"
                            size="sm"
                            onClick={() => setPage(p => Math.max(1, p - 1))}
                            disabled={page === 1}
                        >
                            Sebelumnya
                        </Button>
                        <span className="flex items-center px-4 text-sm font-medium text-slate-700">
                            Halaman {page} dari {totalPages}
                        </span>
                        <Button
                            variant="outline"
                            size="sm"
                            onClick={() => setPage(p => Math.min(totalPages, p + 1))}
                            disabled={page === totalPages}
                        >
                            Selanjutnya
                        </Button>
                    </div>
                </div>
            )}
        </div>
    );
}
