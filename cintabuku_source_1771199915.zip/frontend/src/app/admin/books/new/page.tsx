'use client';

import { BookForm } from '@/components/admin/BookForm';
import { ArrowLeft } from 'lucide-react';
import Link from 'next/link';
import { Button } from '@/components/ui/button';

export default function NewBookPage() {
    return (
        <div className="space-y-6">
            <div className="flex items-center space-x-4">
                <Link href="/admin/books">
                    <Button variant="ghost" size="icon">
                        <ArrowLeft size={20} />
                    </Button>
                </Link>
                <h1 className="text-2xl font-bold text-slate-900">
                    Tambah Buku Baru
                </h1>
            </div>

            <BookForm isEdit={false} />
        </div>
    );
}
