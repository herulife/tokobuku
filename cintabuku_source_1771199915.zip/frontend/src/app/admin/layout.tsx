'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { useAuthStore } from '@/store/useAuthStore';
import { AdminSidebar } from '@/components/admin/Sidebar';
import { Loader2 } from 'lucide-react';

export default function AdminLayout({
    children,
}: {
    children: React.ReactNode;
}) {
    const { user, isAuthenticated, checkAuth } = useAuthStore();
    const router = useRouter();
    const [checking, setChecking] = useState(true);

    useEffect(() => {
        const verifyAdmin = async () => {
            await checkAuth();
            setChecking(false);
        };
        verifyAdmin();
    }, [checkAuth]);

    useEffect(() => {
        if (!checking) {
            if (!isAuthenticated) {
                router.push('/auth/login?redirect=/admin');
            } else if (user?.role !== 'ADMIN' && user?.role !== 'SUPER_ADMIN') {
                router.push('/'); // Redirect non-admins to home
            }
        }
    }, [isAuthenticated, user, checking, router]);

    if (checking) {
        return (
            <div className="min-h-screen flex items-center justify-center bg-slate-50">
                <Loader2 className="h-8 w-8 animate-spin text-emerald-600" />
            </div>
        );
    }

    if (!user || (user.role !== 'ADMIN' && user.role !== 'SUPER_ADMIN')) return null;

    return (
        <div className="min-h-screen bg-slate-50">
            <AdminSidebar />
            <div className="pl-64">
                <main className="p-8">
                    {children}
                </main>
            </div>
        </div>
    );
}
