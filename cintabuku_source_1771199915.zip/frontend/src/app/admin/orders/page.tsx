'use client';

import { useEffect, useState } from 'react';
import { useAuthStore } from '@/store/useAuthStore';
import { apiClient } from '@/lib/api-client';
import { Loader2, Search, Filter, Eye, Truck, FileText, X, Download, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { formatDate, formatCurrency } from '@/lib/utils';
import { toast } from 'sonner';
import { getImageUrl } from '@/lib/image-utils';

const ORDER_STATUSES = ['PENDING', 'PAID', 'PROCESSING', 'SHIPPED', 'DELIVERED', 'CANCELLED'];

export default function AdminOrdersPage() {
    const { user } = useAuthStore();
    const [orders, setOrders] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);
    const [search, setSearch] = useState('');
    const [statusFilter, setStatusFilter] = useState('ALL');

    // Tracking Modal State
    const [trackingModalOpen, setTrackingModalOpen] = useState(false);
    const [selectedOrder, setSelectedOrder] = useState<any>(null);
    const [trackingNumber, setTrackingNumber] = useState('');
    const [updating, setUpdating] = useState(false);

    // Detail Modal State
    const [detailModalOpen, setDetailModalOpen] = useState(false);
    const [detailOrder, setDetailOrder] = useState<any>(null);

    const fetchOrders = async () => {
        try {
            const res: any = await apiClient.get('/orders/admin/all');
            setOrders(res.data.orders);
        } catch (error) {
            toast.error('Gagal memuat data pesanan');
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchOrders();
    }, []);

    const handleStatusChange = async (orderId: string, newStatus: string) => {
        // If changing to SHIPPED, open modal to input tracking number
        if (newStatus === 'SHIPPED') {
            const order = orders.find(o => o.id === orderId);
            setSelectedOrder(order);
            setTrackingNumber(order.resi || '');
            setTrackingModalOpen(true);
            return;
        }

        // For other statuses, update immediately
        try {
            await apiClient.put(`/orders/admin/${orderId}/status`, { status: newStatus });
            setOrders(prev => prev.map(o => o.id === orderId ? { ...o, status: newStatus } : o));
            toast.success(`Status pesanan diperbarui menjadi ${newStatus}`);
        } catch (error: any) {
            toast.error(error.message || 'Gagal memperbarui status');
        }
    };

    const handleSaveTracking = async () => {
        if (!trackingNumber) {
            toast.error('Mohon isi nomor resi');
            return;
        }

        setUpdating(true);
        try {
            await apiClient.put(`/orders/admin/${selectedOrder.id}/status`, {
                status: 'SHIPPED',
                resi: trackingNumber
            });

            setOrders(prev => prev.map(o => o.id === selectedOrder.id ? { ...o, status: 'SHIPPED', resi: trackingNumber } : o));
            toast.success('Status diperbarui dan resi disimpan');
            setTrackingModalOpen(false);
            setSelectedOrder(null);
            setTrackingNumber('');
        } catch (error: any) {
            toast.error(error.message || 'Gagal menyimpan resi');
        } finally {
            setUpdating(false);
        }
    };

    const handleDeleteOrder = async (orderId: string) => {
        if (!confirm('Apakah Anda yakin ingin MENGHAPUS pesanan ini secara permanen? Stok akan dikembalikan (jika bukan CANCELLED).')) return;

        try {
            await apiClient.delete(`/orders/admin/${orderId}`);
            setOrders(prev => prev.filter(o => o.id !== orderId));
            toast.success('Pesanan berhasil dihapus');
            if (detailModalOpen && detailOrder?.id === orderId) {
                setDetailModalOpen(false);
            }
        } catch (error: any) {
            toast.error(error.message || 'Gagal menghapus pesanan');
        }
    };



    const handleExportCSV = () => {
        if (orders.length === 0) {
            toast.error('Tidak ada data untuk diekspor');
            return;
        }

        const headers = ['Invoice', 'User Name', 'User Email', 'Date', 'Total', 'Status', 'Payment Method', 'Courier', 'Resi', 'Address'];
        const rows = orders.map(o => [
            o.invoiceNumber,
            o.user.name,
            o.user.email,
            new Date(o.createdAt).toLocaleDateString('id-ID'),
            o.total,
            o.status,
            o.paymentMethod,
            o.courier || '-',
            o.resi || '-',
            `"${(o.shippingAddress || '').replace(/"/g, '""')}"` // Escape quotes
        ]);

        const csvContent = [
            headers.join(','),
            ...rows.map(row => row.join(','))
        ].join('\n');

        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.setAttribute('href', url);
        link.setAttribute('download', `orders_export_${new Date().toISOString().slice(0, 10)}.csv`);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    const openDetailModal = (order: any) => {
        setDetailOrder(order);
        setDetailModalOpen(true);
    };

    const filteredOrders = orders.filter(order => {
        const matchesSearch =
            order.invoiceNumber.toLowerCase().includes(search.toLowerCase()) ||
            order.user.name.toLowerCase().includes(search.toLowerCase());
        const matchesStatus = statusFilter === 'ALL' || order.status === statusFilter;
        return matchesSearch && matchesStatus;
    });

    const getStatusColor = (status: string) => {
        switch (status) {
            case 'PENDING': return 'bg-yellow-100 text-yellow-700';
            case 'PAID': return 'bg-emerald-100 text-emerald-700';
            case 'PROCESSING': return 'bg-teal-100 text-teal-700';
            case 'SHIPPED': return 'bg-purple-100 text-purple-700';
            case 'DELIVERED': return 'bg-green-100 text-green-700';
            case 'CANCELLED': return 'bg-red-100 text-red-700';
            default: return 'bg-gray-100 text-gray-700';
        }
    };

    if (loading) {
        return (
            <div className="flex justify-center items-center h-64">
                <Loader2 className="h-8 w-8 animate-spin text-emerald-600" />
            </div>
        );
    }

    return (
        <div className="space-y-6">
            <h1 className="text-2xl font-bold text-slate-900">Manajemen Pesanan</h1>

            <div className="flex flex-col md:flex-row gap-4 justify-between">
                <div className="flex items-center space-x-2 w-full md:w-96 bg-white p-2 rounded-lg border border-slate-200">
                    <Search className="h-5 w-5 text-slate-400 ml-2" />
                    <Input
                        placeholder="Cari Invoice atau Nama User..."
                        className="border-none focus-visible:ring-0"
                        value={search}
                        onChange={(e) => setSearch(e.target.value)}
                    />
                </div>

                <div className="flex gap-2">
                    <Button variant="outline" onClick={handleExportCSV} className="bg-white hover:bg-slate-50 border-slate-200 text-slate-700">
                        <Download className="mr-2 h-4 w-4" />
                        Export CSV
                    </Button>
                    <select
                        className="p-2 border border-slate-200 rounded-lg bg-white"
                        value={statusFilter}
                        onChange={(e) => setStatusFilter(e.target.value)}
                    >
                        <option value="ALL">Semua Status</option>
                        {ORDER_STATUSES.map(status => (
                            <option key={status} value={status}>{status}</option>
                        ))}
                    </select>
                </div>
            </div>

            <div className="bg-white rounded-xl border border-slate-100 shadow-sm overflow-hidden">
                <table className="w-full text-left text-sm">
                    <thead className="bg-slate-50 border-b border-slate-100">
                        <tr>
                            <th className="px-6 py-4 font-semibold text-slate-700">Invoice</th>
                            <th className="px-6 py-4 font-semibold text-slate-700">User</th>
                            <th className="px-6 py-4 font-semibold text-slate-700">Tanggal</th>
                            <th className="px-6 py-4 font-semibold text-slate-700">Total</th>
                            <th className="px-6 py-4 font-semibold text-slate-700">Status & Resi</th>
                            <th className="px-6 py-4 font-semibold text-slate-700">Aksi</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                        {filteredOrders.map((order) => (
                            <tr key={order.id} className="hover:bg-slate-50 transition-colors">
                                <td className="px-6 py-3 font-medium font-mono text-slate-900">
                                    {order.invoiceNumber}
                                </td>
                                <td className="px-6 py-3">
                                    <div className="text-slate-900 font-medium">{order.user.name}</div>
                                    <div className="text-slate-500 text-xs">{order.user.email}</div>
                                </td>
                                <td className="px-6 py-3 text-slate-600">
                                    {formatDate(order.createdAt)}
                                </td>
                                <td className="px-6 py-3 font-bold text-slate-900">
                                    {formatCurrency(order.total)}
                                </td>
                                <td className="px-6 py-3">
                                    <div className="flex flex-col gap-1">
                                        <select
                                            value={order.status}
                                            onChange={(e) => handleStatusChange(order.id, e.target.value)}
                                            className={`px-2 py-1 rounded-md text-xs font-bold border-none focus:ring-2 focus:ring-emerald-500 cursor-pointer w-fit ${getStatusColor(order.status)}`}
                                        >
                                            {ORDER_STATUSES.map(s => (
                                                <option key={s} value={s} className="bg-white text-slate-900">
                                                    {s}
                                                </option>
                                            ))}
                                        </select>
                                        {order.resi && (
                                            <div className="flex items-center text-xs text-slate-500 mt-1">
                                                <Truck size={12} className="mr-1" />
                                                <span className="font-mono">{order.resi}</span>
                                                <button
                                                    onClick={() => {
                                                        setSelectedOrder(order);
                                                        setTrackingNumber(order.resi);
                                                        setTrackingModalOpen(true);
                                                    }}
                                                    className="ml-2 text-emerald-600 hover:underline"
                                                >
                                                    Edit
                                                </button>
                                            </div>
                                        )}
                                    </div>
                                </td>

                                <td className="px-6 py-3">
                                    <div className="flex items-center space-x-2">
                                        <Button
                                            variant="ghost"
                                            size="sm"
                                            onClick={() => openDetailModal(order)}
                                        >
                                            <FileText size={16} className="mr-1 text-slate-500" />
                                            Detail
                                        </Button>
                                        <a href={`/invoice/${order.id}`} target="_blank" rel="noopener noreferrer">
                                            <Button variant="ghost" size="sm" className="text-emerald-600 hover:text-emerald-800">
                                                <Eye size={16} />
                                            </Button>
                                        </a>

                                        {/* Only show Delete for SUPER_ADMIN */}
                                        {user?.role === 'SUPER_ADMIN' && (
                                            <Button
                                                variant="ghost"
                                                size="sm"
                                                className="text-red-400 hover:text-red-600"
                                                onClick={() => handleDeleteOrder(order.id)}
                                            >
                                                <Trash2 size={16} />
                                            </Button>
                                        )}
                                    </div>
                                </td>
                            </tr>
                        ))}
                        {filteredOrders.length === 0 && (
                            <tr>
                                <td colSpan={6} className="px-6 py-12 text-center text-slate-500">
                                    Tidak ada pesanan ditemukan.
                                </td>
                            </tr>
                        )}
                    </tbody>
                </table>
            </div>

            {/* Tracking Number Modal */}
            {
                trackingModalOpen && (
                    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
                        <div className="bg-white rounded-xl shadow-xl w-full max-w-md p-6">
                            <h2 className="text-xl font-bold mb-4">Input Nomor Resi</h2>
                            <p className="text-sm text-slate-500 mb-4">
                                Masukkan nomor resi pengiriman untuk pesanan <span className="font-mono font-medium">{selectedOrder?.invoiceNumber}</span>.
                            </p>

                            <div className="space-y-4">
                                <div>
                                    <label className="block text-sm font-medium text-slate-700 mb-1">Nomor Resi</label>
                                    <Input
                                        value={trackingNumber}
                                        onChange={(e) => setTrackingNumber(e.target.value)}
                                        placeholder="Contoh: JNE123456789"
                                    />
                                </div>

                                <div className="flex justify-end gap-2">
                                    <Button variant="outline" onClick={() => setTrackingModalOpen(false)}>Batal</Button>
                                    <Button onClick={handleSaveTracking} disabled={updating} className="bg-emerald-600 hover:bg-emerald-700">
                                        {updating ? <Loader2 className="animate-spin h-4 w-4 mr-2" /> : null}
                                        Simpan
                                    </Button>
                                </div>
                            </div>
                        </div>
                    </div>
                )
            }

            {/* Order Detail Modal */}
            {
                detailModalOpen && detailOrder && (
                    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
                        <div className="bg-white rounded-xl shadow-xl w-full max-w-lg max-h-[90vh] overflow-y-auto">
                            <div className="p-6 border-b border-slate-100 flex justify-between items-center bg-slate-50 rounded-t-xl">
                                <h2 className="text-lg font-bold">Detail Pesanan</h2>
                                <button onClick={() => setDetailModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                                    <X size={20} />
                                </button>
                            </div>

                            <div className="p-6 space-y-6">
                                {/* Shipping Info */}
                                <div>
                                    <h3 className="text-sm font-semibold text-slate-900 mb-2 flex items-center">
                                        <Truck size={16} className="mr-2 text-emerald-600" />
                                        Info Pengiriman
                                    </h3>
                                    <div className="bg-slate-50 p-4 rounded-lg text-sm space-y-2">
                                        <div>
                                            <p className="text-slate-500 text-xs">Penerima & Alamat</p>
                                            <p className="text-slate-800 font-medium whitespace-pre-wrap">{detailOrder.shippingAddress}</p>
                                        </div>
                                        <div className="grid grid-cols-2 gap-4 pt-2 border-t border-slate-200 mt-2">
                                            <div>
                                                <p className="text-slate-500 text-xs">Kurir</p>
                                                <p className="text-slate-800 font-medium">{detailOrder.courier || '-'}</p>
                                            </div>
                                            <div>
                                                <p className="text-slate-500 text-xs">Biaya Ongkir</p>
                                                <p className="text-slate-800 font-medium">{formatCurrency(detailOrder.shippingCost || 0)}</p>
                                            </div>
                                        </div>
                                        {detailOrder.resi && (
                                            <div className="pt-2 border-t border-slate-200 mt-2">
                                                <p className="text-slate-500 text-xs">Nomor Resi</p>
                                                <p className="text-emerald-700 font-mono font-bold">{detailOrder.resi}</p>
                                            </div>
                                        )}
                                    </div>
                                </div>

                                {/* Payment Info */}
                                <div>
                                    <h3 className="text-sm font-semibold text-slate-900 mb-2 flex items-center">
                                        <FileText size={16} className="mr-2 text-emerald-600" />
                                        Info Pembayaran
                                    </h3>
                                    <div className="bg-slate-50 p-4 rounded-lg text-sm space-y-2">
                                        <div className="grid grid-cols-2 gap-4">
                                            <div>
                                                <p className="text-slate-500 text-xs">Metode Pembayaran</p>
                                                <p className="text-slate-800 font-medium">{detailOrder.paymentMethod}</p>
                                            </div>
                                            <div>
                                                <p className="text-slate-500 text-xs">Total Bayar</p>
                                                <p className="text-slate-800 font-bold text-lg">{formatCurrency(detailOrder.total)}</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                {detailOrder.paymentProof && (
                                    <div className="bg-slate-50 p-4 rounded-lg mt-4">
                                        <h3 className="text-sm font-semibold text-slate-900 mb-2 flex items-center">
                                            <FileText size={16} className="mr-2 text-emerald-600" />
                                            Bukti Pembayaran
                                        </h3>
                                        <div className="relative w-full h-48 bg-white rounded border border-slate-200 overflow-hidden flex items-center justify-center">
                                            <img
                                                src={getImageUrl(detailOrder.paymentProof)}
                                                alt="Bukti Transfer"
                                                className="max-w-full max-h-full object-contain"
                                            />
                                        </div>
                                        <div className="mt-2 text-right">
                                            <a
                                                href={getImageUrl(detailOrder.paymentProof)}
                                                target="_blank"
                                                rel="noopener noreferrer"
                                                className="text-xs text-emerald-600 hover:text-emerald-800 font-medium underline"
                                            >
                                                Lihat Ukuran Penuh
                                            </a>
                                        </div>
                                    </div>
                                )}

                                {/* Items */}
                                <div>
                                    <h3 className="text-sm font-semibold text-slate-900 mb-2">Item Pesanan</h3>
                                    <div className="border border-slate-200 rounded-lg divide-y divide-slate-100">
                                        {detailOrder.items.map((item: any) => (
                                            <div key={item.id} className="p-3 flex justify-between items-center">
                                                <div>
                                                    <p className="text-sm font-medium text-slate-800">{item.book.title}</p>
                                                    <p className="text-xs text-slate-500">{item.quantity} x {formatCurrency(item.price)}</p>
                                                </div>
                                                <p className="text-sm font-semibold text-slate-900">{formatCurrency(item.quantity * item.price)}</p>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            </div>

                            <div className="p-6 border-t border-slate-100 bg-slate-50 rounded-b-xl flex justify-end">
                                <Button onClick={() => setDetailModalOpen(false)}>Tutup</Button>
                            </div>
                        </div>
                    </div>
                )
            }
        </div >
    );
}
