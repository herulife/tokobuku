'use client';

import { useState, useEffect } from 'react';
import { apiClient } from '@/lib/api-client';
import { Button } from '@/components/ui/button';
import { Plus, Edit, Trash2, Search, Loader2 } from 'lucide-react';
import { toast } from 'sonner';

interface Category {
    id: string;
    name: string;
    slug: string;
    _count: {
        books: number;
    };
}

export default function AdminCategories() {
    const [categories, setCategories] = useState<Category[]>([]);
    const [loading, setLoading] = useState(true);
    const [searchTerm, setSearchTerm] = useState('');
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editingCategory, setEditingCategory] = useState<Category | null>(null);
    const [formData, setFormData] = useState({ name: '' });
    const [submitting, setSubmitting] = useState(false);

    const fetchCategories = async () => {
        try {
            const res: any = await apiClient.get('/categories');
            setCategories(res.data.categories);
        } catch (error) {
            toast.error('Gagal mengambil data kategori');
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchCategories();
    }, []);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setSubmitting(true);
        try {
            if (editingCategory) {
                await apiClient.put(`/categories/${editingCategory.id}`, formData);
                toast.success('Kategori diperbarui');
            } else {
                await apiClient.post('/categories', formData);
                toast.success('Kategori ditambahkan');
            }
            await fetchCategories();
            handleCloseModal();
        } catch (error: any) {
            toast.error(error.message || 'Terjadi kesalahan');
        } finally {
            setSubmitting(false);
        }
    };

    const handleDelete = async (id: string, bookCount: number) => {
        if (bookCount > 0) {
            toast.error('Tidak bisa menghapus kategori yang memiliki buku');
            return;
        }
        if (!confirm('Apakah Anda yakin ingin menghapus kategori ini?')) return;

        try {
            await apiClient.delete(`/categories/${id}`);
            toast.success('Kategori dihapus');
            fetchCategories();
        } catch (error: any) {
            toast.error(error.message || 'Gagal menghapus kategori');
        }
    };

    const handleOpenModal = (category?: Category) => {
        if (category) {
            setEditingCategory(category);
            setFormData({ name: category.name });
        } else {
            setEditingCategory(null);
            setFormData({ name: '' });
        }
        setIsModalOpen(true);
    };

    const handleCloseModal = () => {
        setIsModalOpen(false);
        setEditingCategory(null);
        setFormData({ name: '' });
    };

    const filteredCategories = categories.filter(cat =>
        cat.name.toLowerCase().includes(searchTerm.toLowerCase())
    );

    if (loading) {
        return (
            <div className="flex justify-center items-center h-64">
                <Loader2 className="animate-spin text-emerald-600" />
            </div>
        );
    }

    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                <h1 className="text-2xl font-bold text-slate-900">Manajemen Kategori</h1>
                <Button onClick={() => handleOpenModal()} className="bg-emerald-600 hover:bg-emerald-700">
                    <Plus size={18} className="mr-2" />
                    Tambah Kategori
                </Button>
            </div>

            <div className="bg-white p-4 rounded-xl shadow-sm border border-slate-100 flex items-center space-x-4">
                <Search className="text-slate-400" size={20} />
                <input
                    type="text"
                    placeholder="Cari kategori..."
                    className="flex-1 outline-none text-slate-600"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                />
            </div>

            <div className="bg-white rounded-xl shadow-sm border border-slate-100 overflow-hidden">
                <table className="w-full text-left">
                    <thead className="bg-slate-50 border-b border-slate-100">
                        <tr>
                            <th className="p-4 font-semibold text-slate-600">Nama Kategori</th>
                            <th className="p-4 font-semibold text-slate-600">Slug</th>
                            <th className="p-4 font-semibold text-slate-600">Jumlah Buku</th>
                            <th className="p-4 font-semibold text-slate-600 text-right">Aksi</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-50">
                        {filteredCategories.map((category) => (
                            <tr key={category.id} className="hover:bg-slate-50 transition-colors">
                                <td className="p-4 font-medium text-slate-900">{category.name}</td>
                                <td className="p-4 text-slate-500 font-mono text-sm">{category.slug}</td>
                                <td className="p-4 text-slate-500">
                                    <span className="bg-emerald-50 text-emerald-700 px-2 py-1 rounded-md text-xs font-bold">
                                        {category._count.books} Buku
                                    </span>
                                </td>
                                <td className="p-4 text-right space-x-2">
                                    <button
                                        onClick={() => handleOpenModal(category)}
                                        className="p-2 text-slate-400 hover:text-emerald-600 hover:bg-emerald-50 rounded-lg transition-colors"
                                    >
                                        <Edit size={18} />
                                    </button>
                                    <button
                                        onClick={() => handleDelete(category.id, category._count.books)}
                                        className="p-2 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                                    >
                                        <Trash2 size={18} />
                                    </button>
                                </td>
                            </tr>
                        ))}
                        {filteredCategories.length === 0 && (
                            <tr>
                                <td colSpan={4} className="p-8 text-center text-slate-500">
                                    Tidak ada kategori ditemukan.
                                </td>
                            </tr>
                        )}
                    </tbody>
                </table>
            </div>

            {/* Modal Form */}
            {isModalOpen && (
                <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
                    <div className="bg-white rounded-2xl w-full max-w-md p-6 shadow-xl">
                        <h2 className="text-xl font-bold text-slate-900 mb-6">
                            {editingCategory ? 'Edit Kategori' : 'Tambah Kategori'}
                        </h2>
                        <form onSubmit={handleSubmit} className="space-y-4">
                            <div>
                                <label className="block text-sm font-medium text-slate-700 mb-1">Nama Kategori</label>
                                <input
                                    type="text"
                                    value={formData.name}
                                    onChange={(e) => setFormData({ name: e.target.value })}
                                    className="w-full rounded-lg border border-slate-300 p-2.5 focus:ring-2 focus:ring-emerald-500 outline-none"
                                    placeholder="Contoh: Fiksi, Komputer, Sejarah"
                                    required
                                />
                            </div>
                            <div className="flex justify-end space-x-3 mt-6">
                                <button
                                    type="button"
                                    onClick={handleCloseModal}
                                    className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg font-medium"
                                >
                                    Batal
                                </button>
                                <Button type="submit" disabled={submitting} className="bg-emerald-600 hover:bg-emerald-700">
                                    {submitting ? 'Menyimpan...' : 'Simpan'}
                                </Button>
                            </div>
                        </form>
                    </div>
                </div>
            )}
        </div>
    );
}
