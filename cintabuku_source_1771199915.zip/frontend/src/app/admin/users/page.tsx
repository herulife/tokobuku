'use client';

import { useEffect, useState } from 'react';
import { apiClient } from '@/lib/api-client';
import { Loader2, Search, Trash2, Shield, User } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';
import { formatDate } from '@/lib/utils';
import { CreateUserDialog } from './CreateUserDialog';

export default function AdminUsersPage() {
    const [users, setUsers] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);
    const [search, setSearch] = useState('');

    // Pagination
    const [page, setPage] = useState(1);
    const [totalPages, setTotalPages] = useState(1);
    const [totalUsers, setTotalUsers] = useState(0);
    const [limit, setLimit] = useState(10);

    const fetchUsers = async () => {
        setLoading(true);
        try {
            const queryParams = new URLSearchParams({
                page: page.toString(),
                limit: limit.toString(),
                search: search
            });
            const res: any = await apiClient.get(`/users?${queryParams}`);

            // Backend sends { status: 'success', results, total, totalPages, currentPage, data: { users } }
            // OR checks userController response structure.
            // userController: res.status(200).json({ status, results, total, totalPages, currentPage, data: { users } })

            setUsers(res.data.users);
            setTotalPages(res.totalPages);
            setTotalUsers(res.total);
            setPage(res.currentPage);
        } catch (error) {
            toast.error('Gagal memuat data pengguna');
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchUsers();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [page, limit]); // search handled separately with debounce or effect?

    // Handle search with effect
    useEffect(() => {
        setPage(1);
        fetchUsers();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [search]);

    const handleRoleChange = async (userId: string, newRole: string) => {
        try {
            await apiClient.put(`/users/${userId}/role`, { role: newRole });
            setUsers(prev => prev.map(u => u.id === userId ? { ...u, role: newRole } : u));
            toast.success(`Role pengguna diubah menjadi ${newRole}`);
        } catch (error: any) {
            toast.error(error.message || 'Gagal mengubah role');
        }
    };

    const handleDelete = async (userId: string) => {
        if (!confirm('Apakah Anda yakin ingin melihat pengguna ini? Tindakan ini tidak dapat dibatalkan.')) return;

        try {
            await apiClient.delete(`/users/${userId}`);
            toast.success('Pengguna berhasil dihapus');
            fetchUsers();
        } catch (error: any) {
            toast.error(error.message || 'Gagal menghapus pengguna');
        }
    };

    return (
        <div className="space-y-6">
            <h1 className="text-2xl font-bold text-slate-900 flex items-center">
                Manajemen Pengguna
                {totalUsers > 0 && (
                    <span className="ml-3 text-sm font-normal text-emerald-700 bg-emerald-100 px-3 py-1 rounded-full">
                        Total: {totalUsers}
                    </span>
                )}
            </h1>

            <div className="flex justify-end">
                <CreateUserDialog onUserCreated={fetchUsers} />
            </div>

            <div className="flex flex-col md:flex-row justify-between items-center bg-white p-2 rounded-lg border border-slate-200 shadow-sm gap-2">
                <div className="flex items-center space-x-2 flex-1 relative w-full md:max-w-md">
                    <Search className="h-5 w-5 text-slate-400 ml-2 absolute pointer-events-none" />
                    <Input
                        placeholder="Cari nama atau email..."
                        className="pl-9 border-none focus-visible:ring-0 shadow-none bg-slate-50"
                        value={search}
                        onChange={(e) => setSearch(e.target.value)}
                    />
                </div>
                <div className="flex items-center px-4 md:border-l md:border-slate-100 w-full md:w-auto justify-end">
                    <span className="text-sm text-slate-500 mr-2 whitespace-nowrap">Baris per halaman:</span>
                    <select
                        className="text-sm border-none focus:ring-0 bg-transparent text-slate-700 font-medium cursor-pointer outline-none"
                        value={limit}
                        onChange={(e) => setLimit(Number(e.target.value))}
                    >
                        <option value="10">10</option>
                        <option value="25">25</option>
                        <option value="50">50</option>
                        <option value="100">100</option>
                    </select>
                </div>
            </div>

            <div className="bg-white rounded-xl border border-slate-100 shadow-sm overflow-hidden">
                <table className="w-full text-left text-sm">
                    <thead className="bg-slate-50 border-b border-slate-100">
                        <tr>
                            <th className="px-6 py-4 font-semibold text-slate-700">Nama</th>
                            <th className="px-6 py-4 font-semibold text-slate-700">Email</th>
                            <th className="px-6 py-4 font-semibold text-slate-700">Role</th>
                            <th className="px-6 py-4 font-semibold text-slate-700">Tanggal Daftar</th>
                            <th className="px-6 py-4 font-semibold text-slate-700">Pesanan</th>
                            <th className="px-6 py-4 font-semibold text-slate-700 text-right">Aksi</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                        {loading ? (
                            <tr>
                                <td colSpan={6} className="px-6 py-12 text-center text-slate-500">
                                    <Loader2 className="mx-auto h-6 w-6 animate-spin text-emerald-600 mb-2" />
                                    Loading...
                                </td>
                            </tr>
                        ) : users.length === 0 ? (
                            <tr>
                                <td colSpan={6} className="px-6 py-12 text-center text-slate-500">
                                    Tidak ada pengguna ditemukan.
                                </td>
                            </tr>
                        ) : (
                            users.map((u) => (
                                <tr key={u.id} className="hover:bg-slate-50 transition-colors">
                                    <td className="px-6 py-3 font-medium text-slate-900">
                                        <div className="flex items-center space-x-2">
                                            <div className="h-8 w-8 rounded-full bg-slate-200 flex items-center justify-center text-slate-500">
                                                <User size={16} />
                                            </div>
                                            <span>{u.name}</span>
                                        </div>
                                    </td>
                                    <td className="px-6 py-3 text-slate-600">{u.email}</td>
                                    <td className="px-6 py-3">
                                        <div className="flex items-center space-x-2">
                                            {u.role === 'SUPER_ADMIN' && <Shield size={14} className="text-purple-600" />}
                                            {u.role === 'ADMIN' && <Shield size={14} className="text-emerald-600" />}
                                            <select
                                                value={u.role}
                                                onChange={(e) => handleRoleChange(u.id, e.target.value)}
                                                className={`text-xs font-bold px-2 py-1 rounded-full border-none focus:ring-0 cursor-pointer ${u.role === 'SUPER_ADMIN' ? 'bg-purple-100 text-purple-700' :
                                                    u.role === 'ADMIN' ? 'bg-emerald-100 text-emerald-700' :
                                                        'bg-slate-100 text-slate-700'
                                                    }`}
                                            >
                                                <option value="USER">USER</option>
                                                <option value="ADMIN">ADMIN</option>
                                                <option value="SUPER_ADMIN">SUPER_ADMIN</option>
                                            </select>
                                        </div>
                                    </td>
                                    <td className="px-6 py-3 text-slate-600">
                                        {formatDate ? formatDate(u.createdAt) : new Date(u.createdAt).toLocaleDateString()}
                                    </td>
                                    <td className="px-6 py-3 text-slate-600">
                                        {u._count?.orders || 0}
                                    </td>
                                    <td className="px-6 py-3 text-right">
                                        <Button
                                            variant="ghost"
                                            size="icon"
                                            className="h-8 w-8 text-red-600 hover:text-red-700 hover:bg-red-50"
                                            onClick={() => handleDelete(u.id)}
                                        >
                                            <Trash2 size={16} />
                                        </Button>
                                    </td>
                                </tr>
                            ))
                        )}
                    </tbody>
                </table>
            </div>

            {/* Pagination Controls */}
            {!loading && totalPages > 1 && (
                <div className="flex justify-between items-center bg-white p-4 rounded-lg border border-slate-200">
                    <p className="text-sm text-slate-500">
                        Halaman {page} dari {totalPages}
                    </p>
                    <div className="flex space-x-2">
                        <Button
                            variant="outline"
                            size="sm"
                            onClick={() => setPage(p => Math.max(1, p - 1))}
                            disabled={page === 1}
                        >
                            Sebelumnya
                        </Button>
                        <Button
                            variant="outline"
                            size="sm"
                            onClick={() => setPage(p => Math.min(totalPages, p + 1))}
                            disabled={page === totalPages}
                        >
                            Selanjutnya
                        </Button>
                    </div>
                </div>
            )}
        </div>
    );
}
