'use client';

import { useEffect, useState } from 'react';
import { apiClient } from '@/lib/api-client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';
import { Loader2, Save, CreditCard, QrCode, Building2 } from 'lucide-react';

export default function AdminSettingsPage() {
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);
    const [activeTab, setActiveTab] = useState('bca');

    // BCA State
    const [bcaAccountNumber, setBcaAccountNumber] = useState('');
    const [bcaAccountHolder, setBcaAccountHolder] = useState('');

    // BRI State
    const [briAccountNumber, setBriAccountNumber] = useState('');
    const [briAccountHolder, setBriAccountHolder] = useState('');

    // QRIS State
    const [qrisImageUrl, setQrisImageUrl] = useState('');
    const [qrisMerchantName, setQrisMerchantName] = useState('');

    // WhatsApp
    const [whatsappNumber, setWhatsappNumber] = useState('');

    useEffect(() => {
        fetchSettings();
    }, []);

    const fetchSettings = async () => {
        try {
            const res: any = await apiClient.get('/settings');
            const data = res.data.settings || {};

            setBcaAccountNumber(data.bca_account_number || '');
            setBcaAccountHolder(data.bca_account_holder || '');
            setBriAccountNumber(data.bri_account_number || '');
            setBriAccountHolder(data.bri_account_holder || '');
            setQrisImageUrl(data.qris_image_url || '');
            setQrisMerchantName(data.qris_merchant_name || '');
            setWhatsappNumber(data.whatsapp_number || '');
        } catch (error) {
            toast.error('Gagal memuat pengaturan');
        } finally {
            setLoading(false);
        }
    };

    const handleSave = async () => {
        setSaving(true);
        try {
            await apiClient.put('/settings', {
                settings: {
                    bca_account_number: bcaAccountNumber,
                    bca_account_holder: bcaAccountHolder,
                    bri_account_number: briAccountNumber,
                    bri_account_holder: briAccountHolder,
                    qris_image_url: qrisImageUrl,
                    qris_merchant_name: qrisMerchantName,
                    whatsapp_number: whatsappNumber
                }
            });
            toast.success('Pengaturan berhasil disimpan');
        } catch (error) {
            toast.error('Gagal menyimpan pengaturan');
        } finally {
            setSaving(false);
        }
    };

    if (loading) {
        return (
            <div className="flex justify-center items-center h-64">
                <Loader2 className="h-8 w-8 animate-spin text-emerald-600" />
            </div>
        );
    }

    return (
        <div className="max-w-4xl mx-auto space-y-6">
            <div>
                <h1 className="text-2xl font-bold text-slate-900">Pengaturan Pembayaran</h1>
                <p className="text-slate-500">Kelola metode pembayaran yang tersedia untuk pelanggan.</p>
            </div>

            {/* Tabs */}
            <div className="flex gap-2 border-b border-slate-200">
                <button
                    onClick={() => setActiveTab('bca')}
                    className={`px-4 py-2 font-medium text-sm transition-colors border-b-2 ${activeTab === 'bca'
                            ? 'border-emerald-600 text-emerald-600'
                            : 'border-transparent text-slate-500 hover:text-slate-700'
                        }`}
                >
                    <Building2 className="inline-block w-4 h-4 mr-2" />
                    Transfer BCA
                </button>
                <button
                    onClick={() => setActiveTab('bri')}
                    className={`px-4 py-2 font-medium text-sm transition-colors border-b-2 ${activeTab === 'bri'
                            ? 'border-emerald-600 text-emerald-600'
                            : 'border-transparent text-slate-500 hover:text-slate-700'
                        }`}
                >
                    <Building2 className="inline-block w-4 h-4 mr-2" />
                    Transfer BRI
                </button>
                <button
                    onClick={() => setActiveTab('qris')}
                    className={`px-4 py-2 font-medium text-sm transition-colors border-b-2 ${activeTab === 'qris'
                            ? 'border-emerald-600 text-emerald-600'
                            : 'border-transparent text-slate-500 hover:text-slate-700'
                        }`}
                >
                    <QrCode className="inline-block w-4 h-4 mr-2" />
                    QRIS
                </button>
                <button
                    onClick={() => setActiveTab('general')}
                    className={`px-4 py-2 font-medium text-sm transition-colors border-b-2 ${activeTab === 'general'
                            ? 'border-emerald-600 text-emerald-600'
                            : 'border-transparent text-slate-500 hover:text-slate-700'
                        }`}
                >
                    <CreditCard className="inline-block w-4 h-4 mr-2" />
                    Umum
                </button>
            </div>

            {/* Tab Content */}
            <div className="bg-white p-6 rounded-xl border border-slate-100 shadow-sm">
                {activeTab === 'bca' && (
                    <div className="space-y-4">
                        <h2 className="text-lg font-bold text-slate-900 mb-4">Transfer Bank BCA</h2>
                        <div>
                            <label className="block text-sm font-medium text-slate-700 mb-1">Nomor Rekening BCA</label>
                            <Input
                                value={bcaAccountNumber}
                                onChange={(e) => setBcaAccountNumber(e.target.value)}
                                placeholder="Contoh: 1234567890"
                            />
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-slate-700 mb-1">Atas Nama (BCA)</label>
                            <Input
                                value={bcaAccountHolder}
                                onChange={(e) => setBcaAccountHolder(e.target.value)}
                                placeholder="Contoh: CV. Cinta Buku Sejahtera"
                            />
                        </div>
                    </div>
                )}

                {activeTab === 'bri' && (
                    <div className="space-y-4">
                        <h2 className="text-lg font-bold text-slate-900 mb-4">Transfer Bank BRI</h2>
                        <div>
                            <label className="block text-sm font-medium text-slate-700 mb-1">Nomor Rekening BRI</label>
                            <Input
                                value={briAccountNumber}
                                onChange={(e) => setBriAccountNumber(e.target.value)}
                                placeholder="Contoh: 0987654321"
                            />
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-slate-700 mb-1">Atas Nama (BRI)</label>
                            <Input
                                value={briAccountHolder}
                                onChange={(e) => setBriAccountHolder(e.target.value)}
                                placeholder="Contoh: CV. Cinta Buku Sejahtera"
                            />
                        </div>
                    </div>
                )}

                {activeTab === 'qris' && (
                    <div className="space-y-4">
                        <h2 className="text-lg font-bold text-slate-900 mb-4">QRIS (Quick Response Code Indonesian Standard)</h2>
                        <div>
                            <label className="block text-sm font-medium text-slate-700 mb-1">Nama Merchant</label>
                            <Input
                                value={qrisMerchantName}
                                onChange={(e) => setQrisMerchantName(e.target.value)}
                                placeholder="Contoh: Toko Cinta Buku"
                            />
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-slate-700 mb-1">URL Gambar QR Code</label>
                            <Input
                                value={qrisImageUrl}
                                onChange={(e) => setQrisImageUrl(e.target.value)}
                                placeholder="Contoh: https://example.com/qr-code.png atau /uploads/qris.png"
                            />
                            <p className="text-xs text-slate-500 mt-1">Upload gambar QR code Anda dan masukkan URL-nya di sini.</p>
                        </div>
                        {qrisImageUrl && (
                            <div className="mt-4">
                                <p className="text-sm font-medium text-slate-700 mb-2">Preview:</p>
                                <div className="border border-slate-200 rounded p-4 inline-block bg-white">
                                    <img src={qrisImageUrl} alt="QRIS Preview" className="w-48 h-48 object-contain" />
                                </div>
                            </div>
                        )}
                    </div>
                )}

                {activeTab === 'general' && (
                    <div className="space-y-4">
                        <h2 className="text-lg font-bold text-slate-900 mb-4">Pengaturan Umum</h2>
                        <div>
                            <label className="block text-sm font-medium text-slate-700 mb-1">Nomor WhatsApp</label>
                            <Input
                                value={whatsappNumber}
                                onChange={(e) => setWhatsappNumber(e.target.value)}
                                placeholder="Contoh: 628123456789 (tanpa +)"
                            />
                            <p className="text-xs text-slate-500 mt-1">Digunakan untuk konfirmasi pembayaran via WhatsApp.</p>
                        </div>
                    </div>
                )}

                <div className="mt-6 flex justify-end">
                    <Button onClick={handleSave} disabled={saving} className="bg-emerald-600 hover:bg-emerald-700">
                        {saving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
                        Simpan Semua Perubahan
                    </Button>
                </div>
            </div>
        </div>
    );
}
