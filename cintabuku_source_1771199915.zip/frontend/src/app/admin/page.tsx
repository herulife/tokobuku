'use client';

import { useEffect, useState } from 'react';
import { apiClient } from '@/lib/api-client';
import { Book, ShoppingBag, Users, DollarSign, TrendingUp, Calendar } from 'lucide-react';
import { formatCurrency, formatDate } from '@/lib/utils';
import { Loader2 } from 'lucide-react';
import Link from 'next/link';
import { Button } from '@/components/ui/button';

export default function AdminDashboard() {
    const [stats, setStats] = useState<any>(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchStats = async () => {
            try {
                const res: any = await apiClient.get('/admin/stats');
                setStats(res.data.stats);
            } catch (error) {
                console.error("Failed to fetch admin stats", error);
            } finally {
                setLoading(false);
            }
        };

        fetchStats();
    }, []);

    if (loading) return (
        <div className="flex items-center justify-center h-96">
            <Loader2 className="h-8 w-8 animate-spin text-emerald-600" />
        </div>
    );

    if (!stats) return <div className="text-center p-8">Gagal memuat statistik.</div>;

    const cards = [
        {
            title: 'Total Pendapatan',
            value: formatCurrency(stats.totalRevenue),
            icon: DollarSign,
            color: 'text-green-600',
            bg: 'bg-green-100',
            desc: 'Semua pesanan lunas'
        },
        {
            title: 'Total Pesanan',
            value: stats.totalOrders.toString(),
            icon: ShoppingBag,
            color: 'text-emerald-600',
            bg: 'bg-emerald-100',
            desc: `+${stats.pendingOrders} pending`
        },
        {
            title: 'Total Pengguna',
            value: stats.totalUsers.toString(),
            icon: Users,
            color: 'text-blue-600',
            bg: 'bg-blue-100',
            desc: 'Pelanggan terdaftar'
        },
        {
            title: 'Total Buku',
            value: stats.totalBooks.toString(),
            icon: Book,
            color: 'text-purple-600',
            bg: 'bg-purple-100',
            desc: 'Item tersedia'
        }
    ];

    // Find max value for chart scaling
    const maxChartValue = Math.max(...stats.salesChart.map((d: any) => d.total), 1);

    return (
        <div className="space-y-8">
            <h1 className="text-3xl font-bold text-slate-900">Dashboard Overview</h1>

            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {cards.map((card, index) => {
                    const Icon = card.icon;
                    return (
                        <div key={index} className="bg-white p-6 rounded-xl border border-slate-100 shadow-sm transition-all hover:shadow-md">
                            <div className="flex items-center justify-between mb-4">
                                <div className={`p-3 rounded-full ${card.bg} ${card.color}`}>
                                    <Icon size={24} />
                                </div>
                                <span className="text-xs font-medium text-slate-400 bg-slate-50 px-2 py-1 rounded-full">
                                    Total
                                </span>
                            </div>
                            <div>
                                <h3 className="text-2xl font-bold text-slate-900 mb-1">{card.value}</h3>
                                <p className="text-sm font-medium text-slate-500">{card.title}</p>
                                <p className="text-xs text-slate-400 mt-2">{card.desc}</p>
                            </div>
                        </div>
                    );
                })}
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                {/* Sales Chart */}
                <div className="lg:col-span-2 bg-white p-6 rounded-xl border border-slate-100 shadow-sm">
                    <div className="flex items-center justify-between mb-6">
                        <div>
                            <h2 className="text-lg font-bold text-slate-900 flex items-center">
                                <TrendingUp className="mr-2 text-emerald-600" size={20} />
                                Grafik Penjualan
                            </h2>
                            <p className="text-sm text-slate-500">Pendapatan 7 hari terakhir</p>
                        </div>
                    </div>

                    <div className="h-64 flex items-end justify-between gap-2 pt-4 border-b border-l border-slate-100 pl-2 pb-2">
                        {stats.salesChart.map((item: any, idx: number) => {
                            const heightPercentage = (item.total / maxChartValue) * 100;
                            // Format date: 2023-10-27 -> 27 Oct
                            const dateObj = new Date(item.date);
                            const day = dateObj.toLocaleDateString('id-ID', { day: 'numeric', month: 'short' });

                            return (
                                <div key={idx} className="flex-1 flex flex-col items-center group">
                                    <div className="w-full relative flex-1 flex items-end justify-center">
                                        <div
                                            className="w-full max-w-[40px] bg-emerald-500 rounded-t-sm transition-all duration-500 group-hover:bg-emerald-600 relative"
                                            style={{ height: `${Math.max(heightPercentage, 2)}%` }} // Minimum 2% height for visibility
                                        >
                                            <div className="absolute -top-8 left-1/2 -translate-x-1/2 bg-slate-900 text-white text-[10px] px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap z-10 pointer-events-none">
                                                {formatCurrency(item.total)}
                                            </div>
                                        </div>
                                    </div>
                                    <div className="mt-2 text-xs text-slate-500 font-medium rotate-0 whitespace-nowrap overflow-hidden text-ellipsis w-full text-center">
                                        {day}
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                </div>

                {/* Recent Orders */}
                <div className="bg-white p-6 rounded-xl border border-slate-100 shadow-sm">
                    <div className="flex items-center justify-between mb-6">
                        <h2 className="text-lg font-bold text-slate-900 flex items-center">
                            <Calendar className="mr-2 text-blue-600" size={20} />
                            Pesanan Terbaru
                        </h2>
                        <Link href="/admin/orders">
                            <Button variant="ghost" size="sm" className="text-xs">Lihat Semua</Button>
                        </Link>
                    </div>

                    <div className="space-y-4">
                        {stats.recentOrders.length === 0 ? (
                            <p className="text-sm text-slate-500 text-center py-8">Belum ada pesanan.</p>
                        ) : (
                            stats.recentOrders.map((order: any) => (
                                <div key={order.id} className="flex items-center justify-between p-3 rounded-lg hover:bg-slate-50 transition-colors border border-slate-50">
                                    <div>
                                        <p className="font-bold text-sm text-slate-900">{order.user.name}</p>
                                        <p className="text-xs text-slate-500">{formatDate(order.createdAt)}</p>
                                    </div>
                                    <div className="text-right">
                                        <p className="font-bold text-sm text-emerald-600">{formatCurrency(order.total)}</p>
                                        <span className={`text-[10px] px-2 py-0.5 rounded-full font-medium 
                                            ${order.status === 'PENDING' ? 'bg-yellow-100 text-yellow-700' :
                                                order.status === 'PAID' ? 'bg-emerald-100 text-emerald-700' :
                                                    order.status === 'SHIPPED' ? 'bg-purple-100 text-purple-700' : 'bg-slate-100 text-slate-600'}`}>
                                            {order.status}
                                        </span>
                                    </div>
                                </div>
                            ))
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
}
