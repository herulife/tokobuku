'use client';

import { useEffect } from 'react';
import { usePathname } from 'next/navigation';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import ScrollToTopButton from '@/components/ui/ScrollToTopButton';
import { useAuthStore } from '@/store/useAuthStore';

export default function ClientLayout({ children }: { children: React.ReactNode }) {
    const pathname = usePathname();
    const isAuthPage = pathname?.startsWith('/auth');
    const isAdminPage = pathname?.startsWith('/admin');

    const shouldShowNavbar = !isAuthPage && !isAdminPage;
    const shouldShowFooter = !isAuthPage && !isAdminPage;

    const isHomePage = pathname === '/';

    // Check auth on mount
    const checkAuth = useAuthStore((state) => state.checkAuth);

    useEffect(() => {
        checkAuth();
    }, [checkAuth]);

    return (
        <>
            {shouldShowNavbar && <Navbar />}
            <main className={`flex-grow ${shouldShowNavbar && !isHomePage ? 'container mx-auto px-4 py-8' : ''}`}>
                {children}
            </main>
            {shouldShowFooter && <Footer />}
            <ScrollToTopButton />
        </>
    );
}
