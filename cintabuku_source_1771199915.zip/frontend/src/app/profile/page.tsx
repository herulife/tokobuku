'use client';

import { useAuthStore } from '@/store/useAuthStore';
import { useRouter } from 'next/navigation';
import { useEffect, useState, useRef } from 'react';
import { apiClient } from '@/lib/api-client';
import { Button } from '@/components/ui/button';
import { formatCurrency, formatDate } from '@/lib/utils';
import { Package, User, Clock, CheckCircle, XCircle, Truck, Edit, Upload, Eye } from 'lucide-react';
import { toast } from 'sonner';
import Link from 'next/link';
import { getImageUrl } from '@/lib/image-utils';
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

interface Order {
    id: string;
    invoiceNumber: string;
    total: number;
    status: string;
    createdAt: string;
    items: {
        id: string;
        book: {
            title: string;
            coverImage: string;
        };
        quantity: number;
        price: number;
    }[];
    paymentProof?: string;
}

export default function ProfilePage() {
    const { user, isAuthenticated, logout } = useAuthStore();
    const router = useRouter();
    const [orders, setOrders] = useState<Order[]>([]);
    const [loadingOrders, setLoadingOrders] = useState(true);
    const [settings, setSettings] = useState<any>({});

    // Upload state
    const [uploadingId, setUploadingId] = useState<string | null>(null);
    const fileInputRef = useRef<HTMLInputElement>(null);
    const [selectedOrderId, setSelectedOrderId] = useState<string | null>(null);

    const handleUploadClick = (orderId: string) => {
        setSelectedOrderId(orderId);
        // Reset file input
        if (fileInputRef.current) fileInputRef.current.value = '';
        fileInputRef.current?.click();
    };

    const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (!file || !selectedOrderId) return;

        if (file.size > 5 * 1024 * 1024) {
            toast.error('Ukuran file maksimal 5MB');
            return;
        }

        setUploadingId(selectedOrderId);
        const formData = new FormData();
        formData.append('paymentProof', file);

        try {
            const res = await apiClient.post(`/orders/${selectedOrderId}/proof`, formData, {
                headers: { 'Content-Type': 'multipart/form-data' }
            });

            toast.success('Bukti pembayaran berhasil diupload!');

            // apiClient already unwraps response.data
            // Response structure: { status: 'success', data: { order: ... } }
            const updatedOrder = (res as any).data.order;
            setOrders(prev => prev.map(o => o.id === selectedOrderId ? { ...o, paymentProof: updatedOrder.paymentProof } : o));

        } catch (error: any) {
            toast.error(error.message || 'Gagal upload bukti');
        } finally {
            setUploadingId(null);
            setSelectedOrderId(null);
        }
    };

    useEffect(() => {
        if (!isAuthenticated) {
            router.push('/auth/login');
            return;
        }

        const fetchData = async () => {
            try {
                const [ordersRes, settingsRes] = await Promise.all([
                    apiClient.get('/orders'),
                    apiClient.get('/settings')
                ]);

                // Handle orders response
                const ordersData = ordersRes as any;
                setOrders(ordersData.data.orders);

                // Handle settings response
                const settingsData = settingsRes as any;
                if (settingsData.data.status === 'success') {
                    setSettings(settingsData.data.data.settings);
                }
            } catch (error) {
                console.error('Failed to fetch data', error);
            } finally {
                setLoadingOrders(false);
            }
        };

        fetchData();
    }, [isAuthenticated, router]);

    if (!user) return null;

    const getStatusColor = (status: string) => {
        switch (status) {
            case 'PENDING': return 'bg-yellow-100 text-yellow-700';
            case 'PAID': return 'bg-emerald-100 text-emerald-700';
            case 'PROCESSING': return 'bg-teal-100 text-teal-700';
            case 'SHIPPED': return 'bg-purple-100 text-purple-700';
            case 'DELIVERED': return 'bg-green-100 text-green-700';
            case 'CANCELLED': return 'bg-red-100 text-red-700';
            default: return 'bg-gray-100 text-gray-700';
        }
    };

    const getStatusIcon = (status: string) => {
        switch (status) {
            case 'PENDING': return <Clock size={16} className="mr-1" />;
            case 'DELIVERED': return <CheckCircle size={16} className="mr-1" />;
            case 'CANCELLED': return <XCircle size={16} className="mr-1" />;
            case 'SHIPPED': return <Truck size={16} className="mr-1" />;
            default: return <Package size={16} className="mr-1" />;
        }
    };

    return (
        <div className="max-w-5xl mx-auto py-8 px-4">
            <input
                type="file"
                ref={fileInputRef}
                className="hidden"
                accept="image/*"
                onChange={handleFileChange}
            />
            <div className="flex flex-col md:flex-row gap-8">
                {/* Sidebar / User Info */}
                <div className="w-full md:w-1/3 space-y-6">
                    <div className="bg-white p-6 rounded-xl border border-slate-100 shadow-sm text-center">
                        <div className="w-24 h-24 mx-auto mb-4 flex items-center justify-center">
                            <Avatar className="w-24 h-24 border-4 border-emerald-50">
                                {user.avatar && !user.avatar.includes('pravatar.cc') && (
                                    <AvatarImage src={user.avatar} alt={user.name} />
                                )}
                                <AvatarFallback className="bg-emerald-100 text-emerald-600 text-3xl font-bold">
                                    {user.name.charAt(0).toUpperCase()}
                                </AvatarFallback>
                            </Avatar>
                        </div>
                        <h2 className="text-xl font-bold text-slate-900">{user.name}</h2>
                        <p className="text-slate-500 text-sm mb-4">{user.email}</p>
                        <div className="inline-block bg-emerald-50 text-emerald-700 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider mb-4">
                            {user.role}
                        </div>

                        <div>
                            <Link href="/profile/edit" className="inline-flex items-center text-sm font-medium text-emerald-600 hover:text-emerald-800 transition-colors">
                                <Edit size={16} className="mr-2" />
                                Edit Profil
                            </Link>
                        </div>

                        <div className="mt-6 border-t pt-4">
                            <Button variant="outline" className="w-full text-red-600 hover:text-red-700 hover:bg-red-50" onClick={logout}>
                                Keluar
                            </Button>
                        </div>
                    </div>
                </div>

                {/* Main Content */}
                <div className="w-full md:w-2/3">
                    <div className="bg-white rounded-xl border border-slate-100 shadow-sm overflow-hidden min-h-[500px]">
                        <div className="p-6 border-b border-slate-100">
                            <h2 className="text-lg font-bold text-slate-900">Pesanan Saya</h2>
                        </div>

                        <div className="p-6">
                            <div className="space-y-4">
                                {loadingOrders ? (
                                    <div className="text-center py-10 text-slate-500">Memuat pesanan...</div>
                                ) : orders.length === 0 ? (
                                    <div className="text-center py-10">
                                        <Package size={48} className="mx-auto text-slate-300 mb-3" />
                                        <p className="text-slate-500">Belum ada pesanan.</p>
                                        <Link href="/books">
                                            <Button variant="link" className="text-emerald-600">Mulai Belanja</Button>
                                        </Link>
                                    </div>
                                ) : (
                                    orders.map(order => (
                                        <div key={order.id} className="border rounded-lg p-4 hover:border-emerald-200 transition-colors">
                                            <div className="flex justify-between items-start mb-4">
                                                <div>
                                                    <p className="font-bold text-slate-800">{order.invoiceNumber}</p>
                                                    <p className="text-xs text-slate-500">{formatDate(order.createdAt)}</p>
                                                </div>
                                                <span className={`px-2 py-1 rounded text-xs font-bold flex items-center ${getStatusColor(order.status)}`}>
                                                    {getStatusIcon(order.status)}
                                                    {order.status}
                                                </span>
                                            </div>

                                            <div className="space-y-2 mb-4">
                                                {order.items.map(item => (
                                                    <div key={item.id} className="flex gap-3">
                                                        <div className="w-10 h-14 bg-slate-100 rounded overflow-hidden relative border border-slate-200">
                                                            <img
                                                                src={getImageUrl(item.book.coverImage)}
                                                                className="w-full h-full object-cover"
                                                                alt={item.book.title}
                                                            />
                                                        </div>
                                                        <div className="flex-1">
                                                            <p className="text-sm font-medium line-clamp-1">{item.book.title}</p>
                                                            <p className="text-xs text-slate-500">{item.quantity} x {formatCurrency(item.price)}</p>
                                                        </div>
                                                    </div>
                                                ))}
                                            </div>

                                            <div className="flex justify-between items-center border-t pt-3">
                                                <div>
                                                    <p className="text-xs text-slate-500">Total Belanja</p>
                                                    <p className="font-bold text-slate-900">{formatCurrency(order.total)}</p>
                                                </div>
                                                <div className="flex flex-col sm:flex-row gap-2 items-center">
                                                    {order.status === 'PENDING' && (
                                                        <>
                                                            {order.paymentProof ? (
                                                                <div className="flex items-center gap-2">
                                                                    <span className="text-xs text-emerald-600 font-medium flex items-center bg-emerald-50 px-2 py-1 rounded border border-emerald-100">
                                                                        <CheckCircle size={12} className="mr-1" /> Bukti Terkirim
                                                                    </span>
                                                                    <a href={getImageUrl(order.paymentProof)} target="_blank" rel="noopener noreferrer">
                                                                        <Button variant="ghost" size="sm" className="h-8 w-8 p-0 text-slate-500 hover:text-emerald-600">
                                                                            <Eye size={16} />
                                                                        </Button>
                                                                    </a>
                                                                    <Button
                                                                        variant="outline"
                                                                        size="sm"
                                                                        onClick={() => handleUploadClick(order.id)}
                                                                        disabled={uploadingId === order.id}
                                                                        className="text-xs h-8"
                                                                    >
                                                                        {uploadingId === order.id ? '...' : 'Ganti'}
                                                                    </Button>
                                                                </div>
                                                            ) : (
                                                                <Button
                                                                    variant="default"
                                                                    size="sm"
                                                                    className="bg-emerald-600 hover:bg-emerald-700 w-full sm:w-auto"
                                                                    onClick={() => handleUploadClick(order.id)}
                                                                    disabled={uploadingId === order.id}
                                                                >
                                                                    <Upload size={14} className="mr-2" />
                                                                    {uploadingId === order.id ? 'Mengupload...' : 'Upload Bukti'}
                                                                </Button>
                                                            )}

                                                            {/* Vertical separator or just gap */}
                                                        </>
                                                    )}

                                                    {order.status === 'PENDING' && settings.whatsapp_number && (
                                                        <a
                                                            href={`https://wa.me/${settings.whatsapp_number}?text=${encodeURIComponent(`Halo Admin, saya ingin konfirmasi pembayaran untuk pesanan ${order.invoiceNumber} sebesar Rp ${order.total.toLocaleString('id-ID')}`)}`}
                                                            target="_blank"
                                                            rel="noopener noreferrer"
                                                        >
                                                            <Button variant="outline" size="sm" className="w-full sm:w-auto text-emerald-600 border-emerald-600 hover:bg-emerald-50">
                                                                Konfirmasi WA
                                                            </Button>
                                                        </a>
                                                    )}
                                                    <Link href={`/invoice/${order.id}`}>
                                                        <Button variant="outline" size="sm" className="w-full sm:w-auto">
                                                            Invoice
                                                        </Button>
                                                    </Link>
                                                </div>
                                            </div>
                                        </div>
                                    ))
                                )}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}
