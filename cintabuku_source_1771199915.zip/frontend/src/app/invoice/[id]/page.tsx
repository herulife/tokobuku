'use client';

import { useEffect, useState } from 'react';
import { useParams } from 'next/navigation';
import { apiClient } from '@/lib/api-client';
import { Loader2, Printer, ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import Link from 'next/link';
import { toast } from 'sonner';

interface OrderItem {
    id: string;
    quantity: number;
    price: number;
    book: {
        title: string;
        author: string;
    };
}

interface Order {
    id: string;
    invoiceNumber: string;
    createdAt: string;
    status: string;
    total: number;
    shippingCost: number;
    shippingAddress: string;
    courier: string;
    items: OrderItem[];
    user: {
        name: string;
        email: string;
    };
}

export default function InvoicePage() {
    const params = useParams();
    const [order, setOrder] = useState<Order | null>(null);
    const [loading, setLoading] = useState(true);
    const [settings, setSettings] = useState({
        bank_name: '',
        account_number: '',
        account_holder: '',
        whatsapp_number: ''
    });

    useEffect(() => {
        loadOrder();
        loadSettings();
    }, [params.id]);

    const loadOrder = async () => {
        try {
            const res: any = await apiClient.get(`/orders/${params.id}`);
            setOrder(res.data.order);
        } catch (error: any) {
            toast.error('Gagal memuat invoice');
        } finally {
            setLoading(false);
        }
    };

    const loadSettings = async () => {
        try {
            const res: any = await apiClient.get('/settings');
            // Handle various response structures (due to interceptos or controller format)
            // Expected: { status: 'success', data: { settings: ... } }
            // With interceptor: res is body. So res.data -> { settings }
            const s = res.data?.settings || res.data?.data?.settings || res.settings || {};

            setSettings({
                bank_name: s.bank_name || '',
                account_number: s.account_number || '',
                account_holder: s.account_holder || '',
                whatsapp_number: s.whatsapp_number || ''
            });
        } catch (error) {
            console.error('Failed to load settings');
        }
    };

    const handlePrint = () => {
        window.print();
    };

    if (loading) {
        return (
            <div className="flex items-center justify-center min-h-screen">
                <Loader2 className="h-8 w-8 animate-spin text-emerald-600" />
            </div>
        );
    }

    if (!order) {
        return (
            <div className="flex flex-col items-center justify-center min-h-screen">
                <p className="text-slate-600">Invoice tidak ditemukan</p>
                <Link href="/profile" className="mt-4 text-emerald-600 hover:underline">
                    Kembali ke Profile
                </Link>
            </div>
        );
    }

    const subtotal = order.total - (order.shippingCost || 0);

    return (
        <>
            <style jsx global>{`
                @media print {
                    body * {
                        visibility: hidden;
                    }
                    #invoice-content, #invoice-content * {
                        visibility: visible;
                    }
                    #invoice-content {
                        position: absolute;
                        left: 0;
                        top: 0;
                        width: 100%;
                    }
                    .no-print {
                        display: none !important;
                    }
                }
            `}</style>

            <div className="min-h-screen bg-slate-50 py-8 px-4">
                <div className="max-w-4xl mx-auto">
                    <div className="flex justify-between items-center mb-6 no-print">
                        <Link href="/profile">
                            <Button variant="outline" size="sm">
                                <ArrowLeft className="mr-2 h-4 w-4" />
                                Kembali
                            </Button>
                        </Link>
                        <Button onClick={handlePrint} variant="outline" size="sm">
                            <Printer className="mr-2 h-4 w-4" />
                            Print
                        </Button>
                    </div>

                    <div id="invoice-content" className="bg-white shadow-lg rounded-lg overflow-hidden">
                        <div className="bg-gradient-to-r from-emerald-600 to-teal-600 px-8 py-6 text-white">
                            <div className="flex justify-between items-start">
                                <div>
                                    <h1 className="text-3xl font-bold mb-1">INVOICE</h1>
                                    <p className="text-emerald-100">{order.invoiceNumber}</p>
                                </div>
                                <div className="text-right">
                                    <h2 className="text-2xl font-bold mb-1">Koalisi Cinta Buku</h2>
                                    <p className="text-sm text-emerald-100">Toko Buku Online</p>
                                </div>
                            </div>
                        </div>

                        <div className="px-8 py-6 grid grid-cols-2 gap-8 border-b">
                            <div>
                                <h3 className="text-sm font-semibold text-slate-500 uppercase mb-3">Dari:</h3>
                                <div className="space-y-1">
                                    <p className="font-bold text-slate-900">Koalisi Cinta Buku</p>
                                    <p className="text-sm text-slate-600">Klender, Jakarta Timur</p>
                                    <p className="text-sm text-slate-600">DKI Jakarta, Indonesia</p>
                                </div>
                            </div>
                            <div>
                                <h3 className="text-sm font-semibold text-slate-500 uppercase mb-3">Kepada:</h3>
                                <div className="space-y-1">
                                    <p className="font-bold text-slate-900">{order.user.name}</p>
                                    <p className="text-sm text-slate-600">{order.user.email}</p>
                                    <p className="text-sm text-slate-600 whitespace-pre-line">{order.shippingAddress}</p>
                                </div>
                            </div>
                        </div>

                        <div className="px-8 py-4 grid grid-cols-3 gap-4 bg-slate-50 border-b text-sm">
                            <div>
                                <p className="text-slate-500 mb-1">Tanggal Order</p>
                                <p className="font-semibold text-slate-900">
                                    {new Date(order.createdAt).toLocaleDateString('id-ID', {
                                        year: 'numeric',
                                        month: 'long',
                                        day: 'numeric'
                                    })}
                                </p>
                            </div>
                            <div>
                                <p className="text-slate-500 mb-1">Kurir</p>
                                <p className="font-semibold text-slate-900 uppercase">{order.courier || '-'}</p>
                            </div>
                            <div>
                                <p className="text-slate-500 mb-1">Status</p>
                                <span className={`inline-block px-2 py-1 rounded text-xs font-semibold ${order.status === 'PENDING' ? 'bg-yellow-100 text-yellow-800' :
                                    order.status === 'PAID' ? 'bg-emerald-100 text-emerald-800' :
                                        order.status === 'SHIPPED' ? 'bg-purple-100 text-purple-800' :
                                            order.status === 'DELIVERED' ? 'bg-emerald-100 text-emerald-800' :
                                                'bg-gray-100 text-gray-800'
                                    }`}>
                                    {order.status}
                                </span>
                            </div>
                        </div>

                        <div className="px-8 py-6">
                            <table className="w-full">
                                <thead>
                                    <tr className="border-b-2 border-slate-200">
                                        <th className="text-left py-3 text-sm font-semibold text-slate-700">Item</th>
                                        <th className="text-center py-3 text-sm font-semibold text-slate-700 w-20">Qty</th>
                                        <th className="text-right py-3 text-sm font-semibold text-slate-700 w-32">Harga</th>
                                        <th className="text-right py-3 text-sm font-semibold text-slate-700 w-32">Subtotal</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {order.items.map((item, index) => (
                                        <tr key={item.id} className={index !== order.items.length - 1 ? 'border-b border-slate-100' : ''}>
                                            <td className="py-4">
                                                <p className="font-medium text-slate-900">{item.book.title}</p>
                                                <p className="text-sm text-slate-500">oleh {item.book.author}</p>
                                            </td>
                                            <td className="text-center py-4 text-slate-700">{item.quantity}</td>
                                            <td className="text-right py-4 text-slate-700">
                                                Rp {item.price.toLocaleString('id-ID')}
                                            </td>
                                            <td className="text-right py-4 font-medium text-slate-900">
                                                Rp {(item.price * item.quantity).toLocaleString('id-ID')}
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>

                        <div className="px-8 py-6 bg-slate-50">
                            <div className="max-w-sm ml-auto space-y-3">
                                <div className="flex justify-between text-slate-700">
                                    <span>Subtotal Produk</span>
                                    <span className="font-medium">Rp {subtotal.toLocaleString('id-ID')}</span>
                                </div>
                                <div className="flex justify-between text-slate-700">
                                    <span>Ongkos Kirim</span>
                                    <span className="font-medium">Rp {(order.shippingCost || 0).toLocaleString('id-ID')}</span>
                                </div>
                                <div className="flex justify-between text-lg font-bold text-slate-900 pt-3 border-t-2 border-slate-300">
                                    <span>TOTAL</span>
                                    <span>Rp {order.total.toLocaleString('id-ID')}</span>
                                </div>
                            </div>
                        </div>

                        {/* BCA Payment Info */}
                        {order.status === 'PENDING' && order.paymentMethod === 'TRANSFER_BCA' && settings.bca_account_number && (
                            <div className="px-8 py-6 border-t bg-emerald-50">
                                <h3 className="font-semibold text-slate-900 mb-3">Informasi Pembayaran</h3>
                                <div className="bg-white rounded-lg p-4 border border-emerald-200">
                                    <p className="text-sm text-slate-600 mb-2">Transfer ke rekening:</p>
                                    <div className="space-y-1">
                                        <p className="font-bold text-slate-900">Bank BCA</p>
                                        <p className="text-lg font-mono font-bold text-emerald-600">{settings.bca_account_number}</p>
                                        <p className="text-sm text-slate-600">a.n. {settings.bca_account_holder}</p>
                                    </div>
                                    <div className="mt-4 pt-4 border-t border-emerald-200">
                                        <p className="font-semibold mb-2 text-xs text-emerald-800 uppercase tracking-wide">Cara Pembayaran:</p>
                                        <ol className="list-decimal list-inside space-y-1 text-xs text-slate-600">
                                            <li>Transfer sesuai total tagihan.</li>
                                            <li>Simpan bukti transfer.</li>
                                            <li>Konfirmasi via WhatsApp.</li>
                                        </ol>
                                    </div>
                                    {settings.whatsapp_number && (
                                        <div className="mt-3 pt-3 border-t border-emerald-100">
                                            <a
                                                href={`https://wa.me/${settings.whatsapp_number}?text=${encodeURIComponent(`Halo Admin, konfirmasi pembayaran ${order.invoiceNumber} Rp ${order.total.toLocaleString()}`)}`}
                                                target="_blank"
                                                rel="noopener noreferrer"
                                                className="bg-emerald-600 text-white px-4 py-2 rounded-lg hover:bg-emerald-700 transition-colors inline-flex items-center text-sm font-medium"
                                            >
                                                Konfirmasi via WhatsApp
                                            </a>
                                        </div>
                                    )}
                                </div>
                            </div>
                        )}

                        {/* BRI Payment Info */}
                        {order.status === 'PENDING' && order.paymentMethod === 'TRANSFER_BRI' && settings.bri_account_number && (
                            <div className="px-8 py-6 border-t bg-blue-50">
                                <h3 className="font-semibold text-slate-900 mb-3">Informasi Pembayaran</h3>
                                <div className="bg-white rounded-lg p-4 border border-blue-200">
                                    <p className="text-sm text-slate-600 mb-2">Transfer ke rekening:</p>
                                    <div className="space-y-1">
                                        <p className="font-bold text-slate-900">Bank BRI</p>
                                        <p className="text-lg font-mono font-bold text-blue-600">{settings.bri_account_number}</p>
                                        <p className="text-sm text-slate-600">a.n. {settings.bri_account_holder}</p>
                                    </div>
                                    <div className="mt-4 pt-4 border-t border-blue-200">
                                        <p className="font-semibold mb-2 text-xs text-blue-800 uppercase tracking-wide">Cara Pembayaran:</p>
                                        <ol className="list-decimal list-inside space-y-1 text-xs text-slate-600">
                                            <li>Transfer sesuai total tagihan.</li>
                                            <li>Simpan bukti transfer.</li>
                                            <li>Konfirmasi via WhatsApp.</li>
                                        </ol>
                                    </div>
                                    {settings.whatsapp_number && (
                                        <div className="mt-3 pt-3 border-t border-blue-100">
                                            <a
                                                href={`https://wa.me/${settings.whatsapp_number}?text=${encodeURIComponent(`Halo Admin, konfirmasi pembayaran ${order.invoiceNumber} Rp ${order.total.toLocaleString()}`)}`}
                                                target="_blank"
                                                rel="noopener noreferrer"
                                                className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors inline-flex items-center text-sm font-medium"
                                            >
                                                Konfirmasi via WhatsApp
                                            </a>
                                        </div>
                                    )}
                                </div>
                            </div>
                        )}

                        {/* QRIS Payment Info */}
                        {order.status === 'PENDING' && order.paymentMethod === 'TRANSFER_QRIS' && settings.qris_image_url && (
                            <div className="px-8 py-6 border-t bg-purple-50">
                                <h3 className="font-semibold text-slate-900 mb-3">Informasi Pembayaran</h3>
                                <div className="bg-white rounded-lg p-4 border border-purple-200">
                                    <p className="text-sm text-slate-600 mb-3 text-center">Scan QR Code berikut:</p>
                                    <div className="flex justify-center my-4">
                                        <div className="bg-white p-4 rounded-lg border-2 border-purple-200 inline-block">
                                            <img src={settings.qris_image_url} alt="QRIS" className="w-64 h-64 object-contain" />
                                        </div>
                                    </div>
                                    {settings.qris_merchant_name && (
                                        <p className="text-center text-purple-700 font-medium mb-4">{settings.qris_merchant_name}</p>
                                    )}
                                    <div className="mt-4 pt-4 border-t border-purple-200">
                                        <p className="font-semibold mb-2 text-xs text-purple-800 uppercase tracking-wide">Cara Pembayaran:</p>
                                        <ol className="list-decimal list-inside space-y-1 text-xs text-slate-600">
                                            <li>Buka aplikasi mobile banking / e-wallet.</li>
                                            <li>Scan QR code di atas.</li>
                                            <li>Masukkan nominal Rp {order.total.toLocaleString('id-ID')}.</li>
                                            <li>Konfirmasi via WhatsApp.</li>
                                        </ol>
                                    </div>
                                    {settings.whatsapp_number && (
                                        <div className="mt-3 pt-3 border-t border-purple-100">
                                            <a
                                                href={`https://wa.me/${settings.whatsapp_number}?text=${encodeURIComponent(`Halo Admin, konfirmasi pembayaran ${order.invoiceNumber} Rp ${order.total.toLocaleString()}`)}`}
                                                target="_blank"
                                                rel="noopener noreferrer"
                                                className="bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 transition-colors inline-flex items-center text-sm font-medium"
                                            >
                                                Konfirmasi via WhatsApp
                                            </a>
                                        </div>
                                    )}
                                </div>
                            </div>
                        )}

                        <div className="px-8 py-6 border-t text-center">
                            <p className="text-slate-600 text-sm mb-2">Terima kasih atas pembelian Anda!</p>
                            <p className="text-slate-500 text-xs">
                                Jika ada pertanyaan, hubungi kami di cintabuku@orderonline.id
                            </p>
                        </div>
                    </div>

                    <div className="mt-6 p-4 bg-emerald-50 rounded-lg border border-emerald-200 no-print">
                        <p className="text-sm text-emerald-900">
                            💡 <strong>Tips:</strong> Klik tombol "Print" untuk mencetak atau menyimpan invoice sebagai PDF
                        </p>
                    </div>
                </div>
            </div>
        </>
    );
}
