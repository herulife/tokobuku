import HeroSection from '@/components/HeroSection';
import BookList from '@/components/BookList';

async function getBooks() {
  const apiUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000/api/v1';
  try {
    const res = await fetch(`${apiUrl}/books?limit=8&sort=rating:desc`, {
      cache: 'no-store', // dynamic data
    });

    if (!res.ok) {
      return { data: { books: [] } };
    }

    return res.json();
  } catch (error) {
    console.error("Failed to fetch books:", error);
    return { data: { books: [] } };
  }
}

async function getNewestBooks() {
  const apiUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000/api/v1';
  try {
    const res = await fetch(`${apiUrl}/books?limit=4&sort=newest`, {
      cache: 'no-store',
    });
    if (!res.ok) return { data: { books: [] } };
    return res.json();
  } catch (error) {
    return { data: { books: [] } };
  }
}

export default async function Home() {
  const popularBooksData = await getBooks();
  const newestBooksData = await getNewestBooks();

  const popularBooks = popularBooksData.data?.books || [];
  const newestBooks = newestBooksData.data?.books || [];

  return (
    <main className="bg-[#FDFBF7] min-h-screen font-sans">
      <div className="pt-16"> {/* Spacer for fixed Navbar */}
        <HeroSection />
        <BookList books={popularBooks} title="Buku Pilihan" subtitle="Koleksi terbaik dengan rating tertinggi minggu ini." />
        <BookList books={newestBooks} title="Buku Terbaru" subtitle="Bacaan segar yang baru saja mendarat di rak kami." />
      </div>
    </main>
  );
}
