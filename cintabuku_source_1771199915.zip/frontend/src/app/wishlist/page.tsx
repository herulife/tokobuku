'use client';

import Link from 'next/link';
import { useWishlistStore } from '@/store/useWishlistStore';
import { useCartStore } from '@/store/useCartStore';
import { Button } from '@/components/ui/button';
import { formatCurrency } from '@/lib/utils';
import { Trash2, ShoppingCart, Heart, ArrowRight } from 'lucide-react';
import { useAuthStore } from '@/store/useAuthStore';
import { useEffect, useState } from 'react';
import { toast } from 'sonner';
import { getImageUrl } from '@/lib/image-utils';

export default function WishlistPage() {
    const { items, removeFromWishlist } = useWishlistStore();
    const addItem = useCartStore(state => state.addItem);
    const { isAuthenticated } = useAuthStore();
    const [mounted, setMounted] = useState(false);

    useEffect(() => {
        setMounted(true);
    }, []);

    if (!mounted) return null;

    if (!isAuthenticated) {
        return (
            <div className="flex flex-col items-center justify-center min-h-[60vh] space-y-6 text-center">
                <div className="bg-red-50 p-6 rounded-full text-red-500">
                    <Heart size={64} />
                </div>
                <div>
                    <h2 className="text-2xl font-bold text-slate-900">Wishlist</h2>
                    <p className="text-slate-500 mt-2">Silakan masuk untuk melihat wishlist Anda.</p>
                </div>
                <Link href="/auth/login">
                    <Button size="lg" className="bg-emerald-600 hover:bg-emerald-700">
                        Masuk Sekarang <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                </Link>
            </div>
        );
    }

    if (items.length === 0) {
        return (
            <div className="flex flex-col items-center justify-center min-h-[60vh] space-y-6 text-center">
                <div className="bg-red-50 p-6 rounded-full text-red-500">
                    <Heart size={64} />
                </div>
                <div>
                    <h2 className="text-2xl font-bold text-slate-900">Wishlist Kosong</h2>
                    <p className="text-slate-500 mt-2">Belum ada buku yang disukai. Yuk cari buku favoritmu!</p>
                </div>
                <Link href="/books">
                    <Button size="lg" className="bg-emerald-600 hover:bg-emerald-700">
                        Mulai Belanja <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                </Link>
            </div>
        );
    }

    const handleAddToCart = async (book: any) => {
        await addItem(book);
        toast.success('Berhasil ditambahkan ke keranjang');
    };

    return (
        <div className="space-y-8">
            <h1 className="text-3xl font-bold text-slate-900">Wishlist Saya ({items.length} Item)</h1>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {items.map((book) => (
                    <div key={book.id} className="bg-white rounded-xl border border-slate-100 shadow-sm hover:shadow-md transition-all overflow-hidden flex flex-col">
                        <div className="aspect-[2/3] relative bg-slate-100">
                            <img src={getImageUrl(book.coverImage)} alt={book.title} className="w-full h-full object-cover" />
                            <button
                                onClick={() => removeFromWishlist(book.id)}
                                className="absolute top-2 right-2 p-1.5 bg-white/90 backdrop-blur-sm rounded-full text-slate-400 hover:text-red-500 hover:bg-red-50 shadow-sm"
                            >
                                <Trash2 size={16} />
                            </button>
                        </div>

                        <div className="p-4 flex flex-col flex-1">
                            <Link href={`/books/${book.slug}`} className="block">
                                <h3 className="font-bold text-slate-900 line-clamp-2 hover:text-emerald-600 mb-1">
                                    {book.title}
                                </h3>
                            </Link>
                            <p className="text-sm text-slate-500 mb-2 truncate">{book.author}</p>

                            <div className="mt-auto pt-3 flex items-center justify-between border-t border-slate-50">
                                <span className="font-bold text-slate-900">
                                    {formatCurrency(book.discountPrice || book.price)}
                                </span>
                                <Button size="sm" variant="ghost" className="text-emerald-600 hover:bg-emerald-50 hover:text-emerald-700 p-0 h-8 w-8 rounded-full" onClick={() => handleAddToCart(book)}>
                                    <ShoppingCart size={18} />
                                </Button>
                            </div>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
}
