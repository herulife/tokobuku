'use client';

import { useCartStore } from '@/store/useCartStore';
import { useAuthStore } from '@/store/useAuthStore';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { formatCurrency } from '@/lib/utils';
import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { apiClient } from '@/lib/api-client';
import { toast } from 'sonner';
import { Loader2, ArrowRight } from 'lucide-react';
import Link from 'next/link';
import BackButton from '@/components/ui/BackButton';
import { shippingService, ShippingCost, Location } from '@/lib/shipping-service';
import LocationSearch from '@/components/LocationSearch';

export default function CheckoutPage() {
    const { items, totalPrice, clearCart } = useCartStore();
    const { isAuthenticated, user, _hasHydrated } = useAuthStore();
    const router = useRouter();

    const [loading, setLoading] = useState(false);
    const [selectedLocation, setSelectedLocation] = useState<Location | null>(null);
    const [shippingCost, setShippingCost] = useState(0);
    const [calculatingShipping, setCalculatingShipping] = useState(false);
    const [bankInfo, setBankInfo] = useState<any>(null);

    useEffect(() => {
        const fetchSettings = async () => {
            try {
                const res: any = await apiClient.get('/settings');
                // Handle both res.data.settings and res.data.data.settings
                const settings = res.data?.settings || res.data?.data?.settings || {};
                setBankInfo(settings);
            } catch (error: any) {
                console.error('Failed to fetch settings:', error.message || error);
                setBankInfo({}); // Set empty object to prevent undefined errors
            }
        };
        fetchSettings();
    }, []);


    const [formData, setFormData] = useState({
        name: user?.name || '',
        shippingAddress: '',
        destinationCityId: '',
        paymentMethod: 'TRANSFER_BCA',
        courier: 'jne'
    });

    useEffect(() => {
        // Only redirect if store has hydrated and user is NOT authenticated
        if (_hasHydrated && !isAuthenticated) {
            router.push('/auth/login?redirect=/checkout');
        }
    }, [_hasHydrated, isAuthenticated, router]);

    const handleLocationSelect = async (location: Location) => {
        setSelectedLocation(location);
        setFormData(prev => ({ ...prev, destinationCityId: location.id }));
        setShippingCost(0);

        if (location.id && formData.courier) {
            await calculateShipping(location.id, formData.courier);
        }
    };

    const handleCourierChange = async (e: React.ChangeEvent<HTMLSelectElement>) => {
        const courier = e.target.value;
        setFormData(prev => ({ ...prev, courier }));

        if (formData.destinationCityId && courier) {
            await calculateShipping(formData.destinationCityId, courier);
        }
    };

    const calculateShipping = async (destinationId: string, courier: string) => {
        setCalculatingShipping(true);
        try {
            // Calculate total weight (300g per book as default)
            const totalWeight = items.reduce((sum, item) => sum + (item.quantity * 300), 0);

            const results = await shippingService.calculateCost(destinationId, totalWeight, courier);

            if (results.length > 0 && results[0].costs.length > 0) {
                const cost = results[0].costs[0].cost[0].value;
                setShippingCost(cost);
            } else {
                setShippingCost(0);
                toast.error('Tidak ada layanan pengiriman tersedia untuk lokasi ini');
            }
        } catch (error) {
            setShippingCost(0);
            toast.error('Gagal menghitung ongkir. Coba kurir lain atau cek alamat.');
        } finally {
            setCalculatingShipping(false);
        }
    };

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setLoading(true);

        if (!formData.destinationCityId) {
            toast.error('Mohon pilih Kecamatan/Kota tujuan');
            setLoading(false);
            return;
        }

        try {
            await apiClient.post('/orders', {
                shippingAddress: formData.shippingAddress,
                destinationCityId: formData.destinationCityId,
                shippingCost: shippingCost,
                paymentMethod: formData.paymentMethod,
                courier: formData.courier
            });

            toast.success('Pesanan berhasil dibuat!');
            await clearCart(); // Clear local and backend cart
            router.push('/profile'); // Redirect to profile to see order history
        } catch (error: any) {
            toast.error(error.message || 'Gagal membuat pesanan');
            console.error(error);
        } finally {
            setLoading(false);
        }
    };

    if (!_hasHydrated) {
        return (
            <div className="flex flex-col items-center justify-center min-h-[60vh]">
                <Loader2 className="h-8 w-8 animate-spin text-emerald-600" />
                <p className="mt-4 text-slate-500">Memuat data...</p>
            </div>
        );
    }

    if (items.length === 0) {
        return (
            <div className="flex flex-col items-center justify-center min-h-[60vh] space-y-6 text-center">
                <h2 className="text-2xl font-bold text-slate-900">Keranjang Kosong</h2>
                <p className="text-slate-500">Anda tidak dapat melakukan checkout dengan keranjang kosong.</p>
                <Link href="/books">
                    <Button>Kembali ke Katalog</Button>
                </Link>
            </div>
        );
    }

    return (
        <div className="max-w-4xl mx-auto py-8 px-4">
            <div className="mb-6">
                <BackButton text="Kembali ke Keranjang" />
            </div>
            <h1 className="text-3xl font-bold text-slate-900 mb-8">Checkout</h1>

            <form onSubmit={handleSubmit}>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    {/* Form Section */}
                    <div className="space-y-6">
                        <div className="bg-white p-6 rounded-xl border border-slate-100 shadow-sm">
                            <h2 className="text-xl font-bold mb-4">Informasi Pengiriman</h2>
                            <div className="space-y-4">
                                <div>
                                    <label className="block text-sm font-medium text-slate-700 mb-1">Nama Penerima</label>
                                    <Input
                                        name="name"
                                        value={formData.name}
                                        onChange={handleInputChange}
                                        placeholder="Nama Lengkap"
                                        required
                                    />
                                </div>
                                <div>
                                    <label className="block text-sm font-medium text-slate-700 mb-1">Alamat Lengkap</label>
                                    <textarea
                                        name="shippingAddress"
                                        value={formData.shippingAddress}
                                        onChange={handleInputChange}
                                        rows={3}
                                        className="w-full rounded-md border border-slate-200 p-3 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600"
                                        placeholder="Jalan, No. Rumah, RT/RW"
                                        required
                                    />
                                </div>

                                {/* Location Search Component */}
                                <div className="z-20 relative">
                                    <LocationSearch
                                        label="Kecamatan / Kota Tujuan"
                                        placeholder="Ketik nama kecamatan..."
                                        onSelect={handleLocationSelect}
                                    />
                                    {selectedLocation && (
                                        <p className="text-xs text-green-600 mt-1">
                                            Lokasi terpilih: {selectedLocation.label || selectedLocation.name || selectedLocation.destination_name}
                                        </p>
                                    )}
                                </div>

                                <div>
                                    <label className="block text-sm font-medium text-slate-700 mb-1">Kurir Pengiriman</label>
                                    <select
                                        value={formData.courier}
                                        onChange={handleCourierChange}
                                        className="w-full rounded-md border border-slate-200 p-2 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600"
                                    >
                                        <option value="wahana">Wahana</option>
                                        <option value="lion">Lion Parcel</option>
                                        <option value="sentral">Sentral Cargo</option>
                                        <option value="indah">Indah Cargo</option>
                                    </select>
                                    <p className="text-xs text-slate-500 mt-1">
                                        Pilih kurir pengiriman untuk pesanan Anda.
                                    </p>
                                    {calculatingShipping && (
                                        <p className="text-xs text-emerald-600 mt-1 flex items-center">
                                            <Loader2 className="h-3 w-3 animate-spin mr-1" />
                                            Menghitung ongkir...
                                        </p>
                                    )}
                                </div>
                            </div>
                        </div>

                        <div className="bg-white p-6 rounded-xl border border-slate-100 shadow-sm">
                            <h2 className="text-xl font-bold mb-4">Metode Pembayaran</h2>
                            <div className="space-y-2">
                                <label className="flex items-center space-x-3 p-3 border rounded-lg cursor-pointer hover:bg-slate-50 transition-colors">
                                    <input
                                        type="radio"
                                        name="paymentMethod"
                                        value="TRANSFER_BCA"
                                        checked={formData.paymentMethod === 'TRANSFER_BCA'}
                                        onChange={handleInputChange}
                                        className="h-4 w-4 text-emerald-600"
                                    />
                                    <span className="font-medium">Transfer Bank BCA</span>
                                </label>
                                <label className="flex items-center space-x-3 p-3 border rounded-lg cursor-pointer hover:bg-slate-50 transition-colors">
                                    <input
                                        type="radio"
                                        name="paymentMethod"
                                        value="TRANSFER_BRI"
                                        checked={formData.paymentMethod === 'TRANSFER_BRI'}
                                        onChange={handleInputChange}
                                        className="h-4 w-4 text-emerald-600"
                                    />
                                    <span className="font-medium">Transfer Bank BRI</span>
                                </label>
                                <label className="flex items-center space-x-3 p-3 border rounded-lg cursor-pointer hover:bg-slate-50 transition-colors">
                                    <input
                                        type="radio"
                                        name="paymentMethod"
                                        value="QRIS"
                                        checked={formData.paymentMethod === 'QRIS'}
                                        onChange={handleInputChange}
                                        className="h-4 w-4 text-emerald-600"
                                    />
                                    <span className="font-medium">QRIS</span>
                                </label>
                            </div>

                            {/* BCA Transfer Details */}
                            {formData.paymentMethod === 'TRANSFER_BCA' && bankInfo?.bca_account_number && (
                                <div className="mt-4 p-4 bg-emerald-50 border border-emerald-100 rounded-lg text-sm text-emerald-900">
                                    <p className="font-bold mb-1">Silakan transfer ke:</p>
                                    <p className="font-mono text-lg">Bank BCA</p>
                                    <p className="font-mono text-xl font-bold tracking-wide">{bankInfo.bca_account_number}</p>
                                    <p className="text-emerald-700">a.n {bankInfo.bca_account_holder}</p>

                                    <div className="mt-4 pt-4 border-t border-emerald-200">
                                        <p className="font-semibold mb-2 text-xs uppercase tracking-wide">Cara Pembayaran:</p>
                                        <ol className="list-decimal list-inside space-y-1 text-xs">
                                            <li>Transfer sesuai total tagihan ke rekening di atas.</li>
                                            <li>Simpan bukti transfer (screenshot/foto).</li>
                                            <li>Konfirmasi pembayaran via WhatsApp (kirim bukti transfer ke admin).</li>
                                        </ol>
                                    </div>

                                    <p className="text-xs text-emerald-600 mt-3 italic">*Pesanan akan diproses setelah pembayaran dikonfirmasi.</p>
                                </div>
                            )}

                            {/* BRI Transfer Details */}
                            {formData.paymentMethod === 'TRANSFER_BRI' && bankInfo?.bri_account_number && (
                                <div className="mt-4 p-4 bg-blue-50 border border-blue-100 rounded-lg text-sm text-blue-900">
                                    <p className="font-bold mb-1">Silakan transfer ke:</p>
                                    <p className="font-mono text-lg">Bank BRI</p>
                                    <p className="font-mono text-xl font-bold tracking-wide">{bankInfo.bri_account_number}</p>
                                    <p className="text-blue-700">a.n {bankInfo.bri_account_holder}</p>

                                    <div className="mt-4 pt-4 border-t border-blue-200">
                                        <p className="font-semibold mb-2 text-xs uppercase tracking-wide">Cara Pembayaran:</p>
                                        <ol className="list-decimal list-inside space-y-1 text-xs">
                                            <li>Transfer sesuai total tagihan ke rekening di atas.</li>
                                            <li>Simpan bukti transfer (screenshot/foto).</li>
                                            <li>Konfirmasi pembayaran via WhatsApp (kirim bukti transfer ke admin).</li>
                                        </ol>
                                    </div>

                                    <p className="text-xs text-blue-600 mt-3 italic">*Pesanan akan diproses setelah pembayaran dikonfirmasi.</p>
                                </div>
                            )}

                            {/* QRIS Details */}
                            {formData.paymentMethod === 'TRANSFER_QRIS' && bankInfo?.qris_image_url && (
                                <div className="mt-4 p-4 bg-purple-50 border border-purple-100 rounded-lg text-sm text-purple-900">
                                    <p className="font-bold mb-2">Scan QR Code berikut:</p>
                                    <div className="flex justify-center my-4">
                                        <div className="bg-white p-4 rounded-lg border-2 border-purple-200 inline-block">
                                            <img
                                                src={bankInfo.qris_image_url}
                                                alt="QRIS Code"
                                                className="w-64 h-64 object-contain"
                                            />
                                        </div>
                                    </div>
                                    {bankInfo.qris_merchant_name && (
                                        <p className="text-center text-purple-700 font-medium mb-4">{bankInfo.qris_merchant_name}</p>
                                    )}

                                    <div className="mt-4 pt-4 border-t border-purple-200">
                                        <p className="font-semibold mb-2 text-xs uppercase tracking-wide">Cara Pembayaran:</p>
                                        <ol className="list-decimal list-inside space-y-1 text-xs">
                                            <li>Buka aplikasi mobile banking / e-wallet Anda.</li>
                                            <li>Scan QR code di atas.</li>
                                            <li>Masukkan nominal sesuai total tagihan.</li>
                                            <li>Simpan bukti pembayaran dan konfirmasi via WhatsApp.</li>
                                        </ol>
                                    </div>

                                    <p className="text-xs text-purple-600 mt-3 italic">*Pesanan akan diproses setelah pembayaran dikonfirmasi.</p>
                                </div>
                            )}
                        </div>
                    </div>

                    {/* Summary Section */}
                    <div>
                        <div className="bg-white p-6 rounded-xl border border-slate-100 shadow-sm sticky top-24">
                            <h3 className="text-lg font-bold mb-4">Ringkasan Pesanan</h3>
                            <div className="space-y-3 mb-6 max-h-[300px] overflow-y-auto pr-2 custom-scrollbar">
                                {items.map(item => (
                                    <div key={item.bookId} className="flex gap-3">
                                        <img src={item.book.coverImage} alt={item.book.title} className="w-12 h-16 object-cover rounded" />
                                        <div className="flex-1 text-sm">
                                            <p className="font-medium line-clamp-1">{item.book.title}</p>
                                            <p className="text-slate-500">{item.quantity} x {formatCurrency(item.book.discountPrice || item.book.price)}</p>
                                        </div>
                                        <div className="font-medium text-sm">
                                            {formatCurrency((item.book.discountPrice || item.book.price) * item.quantity)}
                                        </div>
                                    </div>
                                ))}
                            </div>

                            <div className="border-t pt-4 space-y-2 mb-6">
                                <div className="flex justify-between text-slate-600">
                                    <span>Total Harga</span>
                                    <span>{formatCurrency(totalPrice())}</span>
                                </div>
                                <div className="flex justify-between text-slate-600">
                                    <span>Ongkos Kirim</span>
                                    <span>{shippingCost > 0 ? formatCurrency(shippingCost) : (calculatingShipping ? 'Menghitung...' : (selectedLocation ? 'Gratis / Tidak tersedia' : 'Pilih tujuan'))}</span>
                                </div>
                                <div className="flex justify-between text-lg font-bold text-slate-900 border-t pt-2 mt-2">
                                    <span>Total Bayar</span>
                                    <span>{formatCurrency(totalPrice() + shippingCost)}</span>
                                </div>
                            </div>

                            <Button
                                type="submit"
                                className="w-full bg-emerald-600 hover:bg-emerald-700 py-6 font-bold text-lg"
                                disabled={loading || !formData.destinationCityId}
                            >
                                {loading ? (
                                    <>
                                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                        Memproses...
                                    </>
                                ) : (
                                    <>
                                        Bayar Sekarang <ArrowRight className="ml-2 h-4 w-4" />
                                    </>
                                )}
                            </Button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    );
}
