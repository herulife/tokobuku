import { apiClient } from './api-client';

export interface Location {
    id: string;
    label?: string;
    name?: string;
    destination_name?: string;
    subdistrict_name?: string;
    city_name?: string;
    province_name?: string;
    [key: string]: any; // Allow loose typing check for now
}

export interface ShippingCost {
    code: string;
    name: string;
    costs: Array<{
        service: string;
        description: string;
        cost: Array<{
            value: number;
            etd: string;
            note: string;
        }>;
    }>;
}

export const shippingService = {
    async searchDestination(keyword: string): Promise<Location[]> {
        try {
            // Updated: This will now return local fallback results if API fails
            const res: any = await apiClient.get(`/shipping/search?keyword=${encodeURIComponent(keyword)}`);
            return res.data || [];
        } catch (error: any) {
            console.error('Failed to search locations:', error);
            return [];
        }
    },

    // Legacy support (optional, can remove if we are sure)
    // We remove them to force compile errors where they are used, so we fix them.

    async calculateCost(destination: string, weight: number, courier: string): Promise<ShippingCost[]> {
        try {
            const res: any = await apiClient.post('/shipping/cost', {
                destination,
                weight,
                courier
            });
            return res.data || [];
        } catch (error: any) {
            if (error.message?.includes('not configured')) {
                console.warn('Shipping API key missing. Please configure in Admin Settings.');
                throw new Error('Konfigurasi Pengiriman (BinderByte) belum diatur. Hubungi admin.');
            }
            console.error('Failed to calculate shipping cost:', error);
            throw error;
        }
    }
};
