export function getImageUrl(path: string | null | undefined): string {
    if (!path) return '/images/book-placeholder.jpg';
    if (path.startsWith('http')) return path;

    // Force backend URL for local development to avoid 3000/5000 confusion
    const BACKEND_URL = 'http://localhost:5000';

    const cleanPath = path.startsWith('/') ? path : `/${path}`;
    return `${BACKEND_URL}${cleanPath}`;
}
